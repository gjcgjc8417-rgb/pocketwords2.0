# 持续使用相同的测试签名

0.4.0 沿用本次会话交付的 0.3.0 APK 证书。只要保留此密钥，后续测试包就能满足 Android 覆盖安装的签名要求。旧 GitHub 构建包可能使用其他证书；没有旧私钥时，无法使新包覆盖那些旧包。

测试密钥不在源码仓库和源码 ZIP 内，位于单独交付的私有签名备份包中。请保留备份，避免每次构建重新生成密钥。这是测试证书；正式发布应单独规划发布签名。

证书 SHA-256：

```text
85299b1c46eec642729159bd14310ec65cfc455bece28af72d38b74fc9dc4391
```

## 本地恢复

解压私有备份包，然后运行：

```sh
python3 tools/restore_debug_signing.py --input /private/path/pocketwords-debug.keystore
python3 tools/restore_debug_signing.py --verify
./gradlew assembleDebug
```

脚本验证证书后才替换密钥文件，且不输出密钥内容。测试密钥使用 Android 标准测试别名 `androiddebugkey` 和口令 `android`；密钥文件本身仍应单独保管。Gradle 在打包前再次验证证书，密钥缺失或不匹配时终止打包，不会自动生成另一个签名。

## GitHub Actions

仓库维护者需设置一个 Actions repository secret：`POCKETWORDS_DEBUG_KEYSTORE_BASE64`。值为备份 keystore 的 Base64 内容。可在可信本地 checkout 中写入临时文件，再交给 GitHub CLI；不要把内容粘贴到 issue、PR 或聊天中：

```sh
python3 -c 'import base64,pathlib; pathlib.Path("signing/key.base64").write_bytes(base64.b64encode(pathlib.Path("signing/pocketwords-debug.keystore").read_bytes()))'
gh secret set POCKETWORDS_DEBUG_KEYSTORE_BASE64 < signing/key.base64
rm signing/key.base64
```

推送和手动构建会恢复并验证此密钥，然后构建 APK。PR 检查只运行测试与 lint，不接触签名 secret。没有配置 secret 时，不会发布临时签名的安装包。

当前会话未能修改 GitHub 仓库权限或配置此 secret；工作流需上传源码并完成上述一次性配置后才能在 GitHub 运行。

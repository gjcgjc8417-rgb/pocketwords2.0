import tempfile
import unittest
from pathlib import Path
from unittest import mock
import restore_debug_signing as signing


class SigningTests(unittest.TestCase):
    def test_wrong_key_does_not_replace_existing_key(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "owner.keystore"
            path.write_bytes(b"previous")
            with mock.patch.object(signing, "verify", side_effect=ValueError("wrong certificate")):
                with self.assertRaises(ValueError):
                    signing.restore(b"wrong", path)
            self.assertEqual(b"previous", path.read_bytes())
            self.assertFalse(path.with_suffix(".tmp").exists())

    def test_valid_key_is_published_after_verification(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "owner.keystore"
            with mock.patch.object(signing, "verify") as verify:
                signing.restore(b"verified", path)
                verify.assert_called_once_with(path.with_suffix(".tmp"))
            self.assertEqual(b"verified", path.read_bytes())


if __name__ == "__main__":
    unittest.main()

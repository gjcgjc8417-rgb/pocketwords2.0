#!/usr/bin/env python3
"""Build a compact ECDICT asset with the complete word/translation coverage."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import sqlite3
import tempfile
import urllib.request
import zipfile

SOURCE_URL = "https://github.com/skywind3000/ECDICT/releases/download/1.0.28/ecdict-sqlite-28.zip"
SOURCE_SHA256 = "ea01f76a3b3351021ce47077e89234465cc9441c8793054495320d06c0c3f3f6"
ASSET_VERSION = "ecdict-1.0.28-compact-v1-" + SOURCE_SHA256


def digest(path):
    with path.open("rb") as source:
        return hashlib.file_digest(source, "sha256").hexdigest() if hasattr(hashlib, "file_digest") else digest_legacy(source)


def digest_legacy(source):
    checksum = hashlib.sha256()
    for block in iter(lambda: source.read(1024 * 1024), b""):
        checksum.update(block)
    return checksum.hexdigest()


def download_archive(path):
    if path.exists() and digest(path) == SOURCE_SHA256:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(".part")
    try:
        with urllib.request.urlopen(SOURCE_URL, timeout=60) as source, temporary.open("wb") as output:
            shutil.copyfileobj(source, output)
        if digest(temporary) != SOURCE_SHA256:
            raise ValueError("ECDICT archive checksum mismatch; existing assets were left untouched")
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def compact_database(source, output):
    """Build in a temporary file; publish only a checked and committed database."""
    temporary = output.with_suffix(".tmp")
    temporary.unlink(missing_ok=True)
    output.parent.mkdir(parents=True, exist_ok=True)
    try:
        with sqlite3.connect(temporary) as database:
            database.execute("PRAGMA journal_mode=OFF")
            database.execute("PRAGMA synchronous=OFF")
            database.execute("ATTACH DATABASE ? AS original", (str(source),))
            database.execute("""CREATE TABLE stardict (
                word TEXT PRIMARY KEY COLLATE NOCASE,
                translation TEXT,
                phonetic TEXT
            ) WITHOUT ROWID""")
            database.execute("""INSERT INTO stardict SELECT word, translation, phonetic
                FROM original.stardict ORDER BY word COLLATE NOCASE""")
            expected = database.execute("SELECT COUNT(*) FROM original.stardict").fetchone()[0]
            count = database.execute("SELECT COUNT(*) FROM stardict").fetchone()[0]
            if count != expected or not count:
                raise ValueError("Dictionary row count changed")
            database.execute("PRAGMA user_version=1")
            database.commit()
            if database.execute("PRAGMA quick_check").fetchone()[0] != "ok":
                raise ValueError("Compact dictionary integrity check failed")
        os.replace(temporary, output)
        return count
    finally:
        temporary.unlink(missing_ok=True)


def prepare(archive, output):
    download_archive(archive)
    with tempfile.TemporaryDirectory(prefix="ecdict-", dir=output.parent) as temporary:
        source = Path(temporary) / "source.db"
        with zipfile.ZipFile(archive) as bundle:
            entry = next((info for info in bundle.infolist() if Path(info.filename).name == "stardict.db"), None)
            if entry is None:
                raise ValueError("ECDICT archive contains no stardict.db")
            with bundle.open(entry) as content, source.open("wb") as target:
                shutil.copyfileobj(content, target)
        count = compact_database(source, output)
    # Write the version after the database. A failed build is safe to retry.
    output.with_name("dictionary.version").write_text(ASSET_VERSION + "\n", encoding="utf-8")
    print(json.dumps({"entries": count, "bytes": output.stat().st_size, "version": ASSET_VERSION}))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--archive", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    prepare(args.archive, args.output)


if __name__ == "__main__":
    main()

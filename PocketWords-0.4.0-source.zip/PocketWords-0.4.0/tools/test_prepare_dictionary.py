import sqlite3
import tempfile
import unittest
from pathlib import Path
from unittest import mock
import prepare_dictionary as prepare


class CompactDictionaryTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.root = Path(self.directory.name)
        self.source = self.root / "original.db"
        self.output = self.root / "dictionary.db"
        with sqlite3.connect(self.source) as database:
            database.execute("CREATE TABLE stardict(word TEXT, translation TEXT, phonetic TEXT, definition TEXT)")
            database.executemany("INSERT INTO stardict VALUES(?,?,?,?)", [
                ("Hello", '你好，"世界"\n第二行', "həˈləʊ", "unneeded"),
                ("unknown", None, None, "unneeded"), ("café", "咖啡馆", "kæfeɪ", "unneeded")])

    def test_keeps_all_words_translations_and_phonetics_and_indexes_lookup(self):
        self.assertEqual(3, prepare.compact_database(self.source, self.output))
        with sqlite3.connect(self.output) as database:
            self.assertEqual(("你好，\"世界\"\n第二行", "həˈləʊ"), database.execute(
                "SELECT translation,phonetic FROM stardict WHERE word=? COLLATE NOCASE", ("hello",)).fetchone())
            self.assertEqual((None, None), database.execute("SELECT translation,phonetic FROM stardict WHERE word='unknown'").fetchone())
            self.assertEqual(["word", "translation", "phonetic"], [row[1] for row in database.execute("PRAGMA table_info(stardict)")])
            plan = database.execute("EXPLAIN QUERY PLAN SELECT translation FROM stardict WHERE word=? COLLATE NOCASE", ("hello",)).fetchone()[3]
            self.assertIn("SEARCH", plan)

    def test_failed_rebuild_preserves_previous_asset(self):
        self.output.write_bytes(b"previous")
        with sqlite3.connect(self.source) as database:
            database.execute("DROP TABLE stardict")
        with self.assertRaises(sqlite3.OperationalError):
            prepare.compact_database(self.source, self.output)
        self.assertEqual(b"previous", self.output.read_bytes())
        self.assertFalse(self.output.with_suffix(".tmp").exists())

    def test_failed_download_checksum_does_not_replace_cached_archive(self):
        archive = self.root / "source.zip"
        archive.write_bytes(b"previous")
        import io
        with mock.patch.object(prepare.urllib.request, "urlopen", return_value=io.BytesIO(b"bad download")):
            with self.assertRaises(ValueError):
                prepare.download_archive(archive)
        self.assertEqual(b"previous", archive.read_bytes())
        self.assertFalse(archive.with_suffix(".part").exists())


if __name__ == "__main__":
    unittest.main()

#!/usr/bin/env python3
"""Restore the owner's persistent testing key without printing key material."""
import argparse
import base64
import hashlib
import os
from pathlib import Path
import subprocess

EXPECTED_CERTIFICATE_SHA256 = "85299b1c46eec642729159bd14310ec65cfc455bece28af72d38b74fc9dc4391"
KEYSTORE = Path(__file__).resolve().parent.parent / "signing/pocketwords-debug.keystore"


def verify(path):
    certificate = subprocess.check_output([
        "keytool", "-exportcert", "-keystore", str(path), "-storepass", "android", "-alias", "androiddebugkey"
    ], stderr=subprocess.PIPE)
    if hashlib.sha256(certificate).hexdigest() != EXPECTED_CERTIFICATE_SHA256:
        raise ValueError("Testing certificate does not match the previous PocketWords package")


def restore(content, path=KEYSTORE):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(".tmp")
    try:
        # Restrict permissions before writing the key, including when a retry left a file behind.
        descriptor = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(descriptor, "wb") as output:
            os.chmod(temporary, 0o600)
            output.write(content)
        verify(temporary)
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, help="Private backup keystore path")
    parser.add_argument("--verify", action="store_true", help="Check the installed project key")
    args = parser.parse_args()
    if args.verify:
        verify(KEYSTORE)
    elif args.input:
        restore(args.input.read_bytes())
    else:
        value = os.environ.get("POCKETWORDS_DEBUG_KEYSTORE_BASE64")
        if not value:
            parser.error("Set the POCKETWORDS_DEBUG_KEYSTORE_BASE64 repository secret or restore the private backup with --input")
        restore(base64.b64decode(value, validate=True))
    print("Persistent testing certificate verified (key contents hidden).")


if __name__ == "__main__":
    main()

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    testOptions { unitTests.isIncludeAndroidResources = true }

    namespace = "com.pocketwords.app"
    compileSdk = 35

    signingConfigs.getByName("debug") {
        // Owner-supplied, persistent testing key. Never fall back to a fresh random key.
        storeFile = rootProject.file("signing/pocketwords-debug.keystore")
        storePassword = "android"
        keyAlias = "androiddebugkey"
        keyPassword = "android"
    }

    defaultConfig {
        applicationId = "com.pocketwords.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 4
        versionName = "0.4.0"
    }
}

dependencies {
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.robolectric:robolectric:4.14.1")

    implementation("com.google.mlkit:text-recognition:16.0.1")
    implementation("androidx.core:core-ktx:1.13.1")
}


// Keep every ECDICT word and translation; omit unused definitions and duplicate indexes.
val offlineDictionaryAssets = layout.buildDirectory.dir("generated/offlineDictionaryAssets")
val prepareOfflineDictionary by tasks.registering(Exec::class) {
    val script = rootProject.file("tools/prepare_dictionary.py")
    inputs.file(script)
    outputs.file(offlineDictionaryAssets.map { it.file("dictionary.db") })
    outputs.file(offlineDictionaryAssets.map { it.file("dictionary.version") })
    commandLine(
        providers.environmentVariable("POCKETWORDS_PYTHON").orElse("python3").get(),
        script.absolutePath,
        "--archive", layout.buildDirectory.file("ecdict-sqlite-28.zip").get().asFile.absolutePath,
        "--output", offlineDictionaryAssets.get().file("dictionary.db").asFile.absolutePath
    )
}

android.sourceSets.getByName("main").assets.srcDir(offlineDictionaryAssets)
tasks.named("preBuild").configure { dependsOn(prepareOfflineDictionary) }

val verifyDebugSigning by tasks.registering(Exec::class) {
    inputs.file(rootProject.file("signing/pocketwords-debug.keystore"))
    inputs.file(rootProject.file("tools/restore_debug_signing.py"))
    commandLine(
        providers.environmentVariable("POCKETWORDS_PYTHON").orElse("python3").get(),
        rootProject.file("tools/restore_debug_signing.py").absolutePath, "--verify"
    )
}
tasks.matching { it.name == "validateSigningDebug" }.configureEach { dependsOn(verifyDebugSigning) }

tasks.withType<Test>().configureEach {
    // Robolectric eagerly buffers compressed assets; device installation streams the database.
    maxHeapSize = "1536m"
    maxParallelForks = 1
}

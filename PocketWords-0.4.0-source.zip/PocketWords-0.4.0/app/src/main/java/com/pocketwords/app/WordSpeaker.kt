package com.pocketwords.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast
import java.util.concurrent.Executors

internal object SpeechVoices {
    fun rank(voices: Set<Voice>, network: Boolean, accent: String): List<Voice> = voices.filter {
        it.locale.language == "en" && (network || !it.isNetworkConnectionRequired) &&
            it.features?.contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED) != true
    }.sortedWith(compareByDescending<Voice> { it.quality }
        .thenBy { if (it.locale.country == if (accent == "uk") "GB" else "US") 0 else 1 }
        .thenBy { it.latency }.thenBy { it.name })
}

internal class WordSpeaker(private val activity: Activity) : AutoCloseable {
    private val prefs = activity.getSharedPreferences("pronunciation", Context.MODE_PRIVATE)
    private val io = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private val recordings = PronunciationAudio(activity.applicationContext)
    private val dialogs = mutableSetOf<AlertDialog>()
    private var ready = false
    @Volatile private var closed = false
    @Volatile private var generation = 0L
    private var afterInit: (() -> Unit)? = null
    private var engine: TextToSpeech? = null
    private var player: MediaPlayer? = null
    private var lastClip: AudioClip? = null
    private fun accent() = prefs.getString("accent", "us") ?: "us"
    fun speak(text: String) {
        if (closed || text.isBlank()) return
        val request = ++generation
        releasePlayer(); engine?.stop()
        if (prefs.getBoolean("system_only", false)) { systemSpeak(text, request); return }
        message("正在准备词典发音…")
        io.execute {
            val clip = runCatching { recordings.load(text, accent()) { closed || request != generation } }.getOrNull()
            main.post {
                if (!closed && request == generation) {
                    if (clip == null) { message("词典音频暂不可用，改用系统英文语音"); systemSpeak(text, request) }
                    else play(clip, text, request)
                }
            }
        }
    }
    private fun play(clip: AudioClip, text: String, request: Long) {
        try {
            val current = MediaPlayer(); player = current
            current.setDataSource(clip.file.path)
            current.setOnPreparedListener {
                if (!closed && request == generation && player === it) { lastClip = clip; it.start() }
                else if (player === it) releasePlayer()
            }
            current.setOnCompletionListener { if (player === it) releasePlayer() }
            current.setOnErrorListener { failed, _, _ ->
                if (player === failed) {
                    releasePlayer(); clip.file.delete()
                    if (!closed && request == generation) { message("词典音频未能播放，改用系统英文语音"); systemSpeak(text, request) }
                }
                true
            }
            current.prepareAsync()
        } catch (_: Exception) {
            releasePlayer(); clip.file.delete()
            if (!closed && request == generation) { message("词典音频未能播放，改用系统英文语音"); systemSpeak(text, request) }
        }
    }
    private fun withEngine(action: () -> Unit) {
        if (closed) return
        if (ready) { action(); return }
        afterInit = action
        if (engine != null) return
        engine = TextToSpeech(activity.applicationContext) { status ->
            main.post {
                if (!closed) {
                    ready = status == TextToSpeech.SUCCESS
                    val next = afterInit; afterInit = null
                    if (ready) next?.invoke() else {
                        engine?.shutdown(); engine = null
                        message("系统语音引擎不可用，可在发音与语音包设置中安装或更换。")
                    }
                }
            }
        }
    }
    private fun voices() = SpeechVoices.rank(engine?.voices.orEmpty(), prefs.getBoolean("network", false), accent())
    private fun systemSpeak(text: String, request: Long) = withEngine {
        if (closed || request != generation) return@withEngine
        val voices = voices()
        val preferred = prefs.getString("voice", "")
        val voice = voices.firstOrNull { it.name == preferred } ?: voices.firstOrNull()
        if (voice == null) {
            message("没有可用的英文语音，请在右上角更多的发音设置中安装英文语音包。")
        } else {
            lastClip = null
            engine!!.voice = voice
            engine!!.setSpeechRate(0.95f); engine!!.setPitch(1f)
            if (engine!!.speak(text, TextToSpeech.QUEUE_FLUSH, null, "word-$request") == TextToSpeech.ERROR) message("发音失败，请检查系统语音包。")
        }
    }
    fun showSettings() {
        val body = LinearLayout(activity).apply { orientation = LinearLayout.VERTICAL; setPadding(24,8,24,16) }
        fun add(title: String, action: () -> Unit) {
            body.addView(BrandUi.compactAction(activity, title).apply { setOnClickListener { action() } })
        }
        body.addView(BrandUi.label(activity, "优先播放词典录音；没有录音时尝试词典语音，再使用系统英文声线。首次取音需联网，仅发送要朗读的英文，缓存可再次播放。部分词条和短语可能使用合成语音。", 13f))
        add("发音来源：${if (prefs.getBoolean("system_only", false)) "仅系统英文语音" else "词典音频优先"}") {
            track(AlertDialog.Builder(activity).setTitle("发音来源").setSingleChoiceItems(arrayOf("词典音频优先（推荐）", "仅系统英文语音"), if (prefs.getBoolean("system_only", false)) 1 else 0) { d, which ->
                prefs.edit().putBoolean("system_only", which == 1).apply(); d.dismiss(); refreshSettings()
            }.create())
        }
        add("口音偏好：${if (accent() == "uk") "英式" else "美式"}") {
            track(AlertDialog.Builder(activity).setTitle("口音偏好").setSingleChoiceItems(arrayOf("美式", "英式"), if (accent() == "uk") 1 else 0) { d, which ->
                prefs.edit().putString("accent", if (which == 1) "uk" else "us").apply(); d.dismiss(); refreshSettings()
            }.create())
        }
        body.addView(CheckBox(activity).apply {
            text = "允许系统联网声线（音质取决于语音引擎）"; setTextColor(BrandUi.Forest)
            isChecked = prefs.getBoolean("network", false)
            setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean("network", checked).apply() }
        })
        add("选择系统英文声线") { showVoices() }
        add("安装或更换系统语音包") {
            try { activity.startActivity(Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA).apply { engine?.defaultEngine?.let { setPackage(it) } }) }
            catch (_: android.content.ActivityNotFoundException) { openSystemSettings() }
        }
        add("打开系统语音设置") { openSystemSettings() }
        add("试听：Hello, nice to meet you.") { speak("Hello, nice to meet you.") }
        add("最近发音来源与授权") {
            val clip = lastClip
            val info = if (clip == null) "当前未播放词典录音，或上次使用的是系统英文语音。" else
                listOf(clip.source, clip.sourceUrl, clip.license, clip.licenseUrl).filter { it.isNotBlank() }.joinToString("\n")
            track(AlertDialog.Builder(activity).setTitle("发音来源").setMessage(info).setPositiveButton("关闭", null).create())
        }
        track(AlertDialog.Builder(activity).setTitle("发音与语音包").setView(ScrollView(activity).apply { addView(body) }).setNegativeButton("关闭", null).create())
    }
    private fun refreshSettings() { generation++; releasePlayer(); engine?.stop(); dialogs.toList().forEach { it.dismiss() }; showSettings() }
    private fun showVoices() = withEngine {
        val list = voices()
        if (list.isEmpty()) { message("尚未找到英文声线，请先安装语音包，或允许系统联网声线。") }
        else {
            val titles = arrayOf("自动选择最高音质") + list.map { "${it.name} · ${it.locale.country} · ${if (it.quality >= Voice.QUALITY_HIGH) "高音质" else "标准"} · ${if (it.isNetworkConnectionRequired) "联网" else "本机"}" }
            val selected = list.indexOfFirst { it.name == prefs.getString("voice", "") } + 1
            track(AlertDialog.Builder(activity).setTitle("选择英文声线").setSingleChoiceItems(titles, selected) { d, which ->
                prefs.edit().putString("voice", if (which == 0) "" else list[which-1].name).apply(); d.dismiss()
                val request = ++generation; releasePlayer(); engine?.stop()
                systemSpeak("Hello, nice to meet you.", request)
            }.setNegativeButton("关闭", null).create())
        }
    }
    private fun openSystemSettings() {
        try { activity.startActivity(Intent("com.android.settings.TTS_SETTINGS")) }
        catch (_: android.content.ActivityNotFoundException) {
            try { activity.startActivity(Intent(android.provider.Settings.ACTION_SETTINGS)) }
            catch (_: android.content.ActivityNotFoundException) { message("无法打开系统设置，请在手机设置中搜索文字转语音。") }
        }
    }
    private fun track(dialog: AlertDialog) { dialogs.add(dialog); dialog.setOnDismissListener { dialogs.remove(dialog) }; dialog.show() }
    private fun releasePlayer() { player?.release(); player = null }
    private fun message(text: String) { if (!closed && !activity.isDestroyed) Toast.makeText(activity, text, Toast.LENGTH_LONG).show() }
    override fun close() {
        closed = true; generation++; afterInit = null
        releasePlayer(); engine?.stop(); engine?.shutdown(); engine = null
        dialogs.toList().forEach { it.dismiss() }; io.shutdown()
    }
}

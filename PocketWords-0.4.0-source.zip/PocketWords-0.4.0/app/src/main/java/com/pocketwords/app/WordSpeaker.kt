package com.pocketwords.app

import android.app.Activity
import android.speech.tts.TextToSpeech
import android.widget.Toast

internal class WordSpeaker(private val activity: Activity) : AutoCloseable {
    private var ready = false
    private var pending: String? = null
    private var closed = false
    private var engine: TextToSpeech? = null
    fun speak(word: String) {
        if (closed || word.isBlank()) return
        if (engine == null) {
            pending = word
            engine = TextToSpeech(activity.applicationContext) { status ->
                activity.runOnUiThread {
                    if (!closed) {
                        ready = status == TextToSpeech.SUCCESS
                        val value = pending; pending = null
                        if (ready && value != null) speak(value) else if (!ready) message("手机语音引擎不可用，请在系统设置中检查文字转语音。")
                    }
                }
            }
            return
        }
        if (!ready) { pending = word; return }
        val voice = engine!!.voices?.filter { it.locale.language == "en" && !it.isNetworkConnectionRequired }
            ?.sortedBy { if (it.locale.country == "US") 0 else 1 }?.firstOrNull()
        if (voice == null) { message("未找到离线英文语音，请先在系统文字转语音设置中安装英文语音。") ; return }
        engine!!.voice = voice
        if (engine!!.speak(word, TextToSpeech.QUEUE_FLUSH, null, "word") == TextToSpeech.ERROR) message("发音失败，请检查系统语音设置。")
    }
    private fun message(text: String) { Toast.makeText(activity, text, Toast.LENGTH_LONG).show() }
    override fun close() { closed = true; pending = null; engine?.stop(); engine?.shutdown(); engine = null }
}

package com.pocketwords.app

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.text.Editable
import android.text.InputFilter
import android.text.TextWatcher
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast

internal class SentenceTranslationDialog(
    private val activity: Activity,
    private val translatorFactory: () -> SentenceTranslator = { OfflineSentenceTranslator() }
) {
    private var translator: SentenceTranslator? = null
    private var dialog: AlertDialog? = null

    fun show(initial: String, autoTranslate: Boolean = false, restoredOutput: String = "", onDismiss: () -> Unit = {}) {
        val dp = { n: Int -> BrandUi.dp(activity, n) }
        fun spacing(top: Int) = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(top) }
        var revision = 0
        var automaticPending = autoTranslate && initial.isNotBlank() && restoredOutput.isBlank()
        var requestTranslation: (() -> Unit)? = null
        var busy = false
        var open = true
        var modelReady = false
        var downloading = false
        var checking = false
        var checkFailed = false
        val modelStatus = BrandUi.label(activity, "正在检查离线模型…", 12f, BrandUi.Muted).apply { tag = "model_status" }
        val modelAction = BrandUi.compactAction(activity,"下载离线翻译",BrandUi.SoftGreen).apply {
            tag="model_download"; isEnabled=false
        }
        lateinit var submit: Button
        fun alive() = open && !activity.isDestroyed && !activity.isFinishing
        fun engine() = translator ?: translatorFactory().also { translator = it }
        fun checkModel() {
            checking = true; checkFailed = false; modelAction.isEnabled = false
            modelStatus.text = "正在检查离线模型…"
            submit.isEnabled = false
            fun failed() {
                if (!alive()) return
                checking = false; checkFailed = true; modelReady = false
                modelStatus.text = "暂时无法检查模型，请点击重新检查。"
                modelAction.text = "重新检查"; modelAction.isEnabled = true
            }
            try { engine().checkModel({ ready ->
                if (alive()) {
                    checking = false; modelReady = ready
                    modelStatus.text = if (ready) "可离线使用" else "模型未下载 · 首次联网下载后可离线使用"
                    modelAction.text = if (ready) "离线可用" else "下载离线翻译"
                    modelAction.visibility=if (ready) android.view.View.GONE else android.view.View.VISIBLE
                    modelAction.isEnabled = true; submit.isEnabled = ready && !busy
                    if (ready && automaticPending) { automaticPending = false; requestTranslation?.invoke() }
                }
            }, { failed() }) } catch (_: Exception) { failed() }
        }
        val input = BrandUi.field(activity, "输入或粘贴英文句子，也可以是一小段文字", false).apply {
            tag = "sentence_input"; minLines = 3; maxLines = 8
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE or android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            filters = arrayOf(InputFilter.LengthFilter(MAX_LENGTH))
            setText(initial)
        }
        val status = BrandUi.label(activity, "每次最多 $MAX_LENGTH 字符，可在上方修改原文。", 12f, BrandUi.Muted).apply { tag = "translation_status" }
        if (initial.length > MAX_LENGTH) status.text = "识别文字较长，已载入前 $MAX_LENGTH 字符。可分段粘贴翻译。" + status.text
        val output = BrandUi.label(activity, "译文会显示在这里", 16f).apply {
            tag = "sentence_output"; setTextIsSelectable(true)
            background = BrandUi.shape(activity, BrandUi.Tint, 16)
            setPadding(dp(14), dp(14), dp(14), dp(14))
        }
        val content = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(4), dp(20), dp(12))
            addView(BrandUi.label(activity, "英文原文 · 可以修改", 12f, BrandUi.Muted))
            addView(input, spacing(8)); addView(modelStatus, spacing(10)); addView(modelAction, spacing(4)); addView(status, spacing(10))
            addView(BrandUi.label(activity, "中文译文", 12f, BrandUi.Muted), spacing(18))
            addView(output, spacing(8))
        }
        val sheet = AlertDialog.Builder(activity).setTitle("整句翻译 · 英译中")
            .setView(ScrollView(activity).apply { addView(content) })
            .setNegativeButton("关闭", null).setNeutralButton("复制译文", null)
            .setPositiveButton("翻译为中文", null).create()
        dialog = sheet
        input.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                revision++; automaticPending = false; output.text = "译文会显示在这里"
                sheet.getButton(AlertDialog.BUTTON_NEUTRAL)?.isEnabled = false
                if (!busy) status.text = "原文已修改，点击“翻译为中文”更新译文。"
            }
            override fun afterTextChanged(s: Editable?) {}
        })
        sheet.setOnDismissListener {
            open = false; revision++; translator?.close(); translator = null; dialog = null; onDismiss()
        }
        sheet.show()
        submit = sheet.getButton(AlertDialog.BUTTON_POSITIVE)
        val copy = sheet.getButton(AlertDialog.BUTTON_NEUTRAL).apply { isEnabled = false }
        copy.setOnClickListener {
            (activity.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                .setPrimaryClip(ClipData.newPlainText("中文译文", output.text))
            Toast.makeText(activity, "译文已复制", Toast.LENGTH_SHORT).show()
        }
        modelAction.setOnClickListener {
            if (busy || downloading || checking) return@setOnClickListener
            if (modelReady || checkFailed) { checkModel(); return@setOnClickListener }
            downloading = true; modelAction.isEnabled = false; submit.isEnabled = false
            modelStatus.text = "模型下载中…请保持网络连接，首次下载可能需要几分钟。"
            fun failed() {
                if (!alive()) return
                downloading = false; modelReady = false; modelAction.isEnabled = true
                modelAction.text = "重试下载"
                modelStatus.text = "下载失败 · 请检查网络和手机存储空间，再重试。"
            }
            try { engine().download({
                if (alive()) { downloading = false; checkModel() }
            }, { failed() }) } catch (_: Exception) { failed() }
        }
        requestTranslation = translate@{
            if (busy || !modelReady || checking || downloading) return@translate
            val text = input.text.toString().trim()
            if (text.isBlank()) { input.error = "请先输入英文句子"; return@translate }
            val request = ++revision
            busy = true; submit.text = "翻译中…"; submit.isEnabled = false; copy.isEnabled = false; modelAction.isEnabled = false
            output.text = "正在准备译文…"
            status.text = "正在手机上翻译…"
            fun complete(result: String?, error: Exception?) {
                if (!open || activity.isDestroyed || activity.isFinishing) return
                busy = false; submit.text = if (error == null) "重新翻译" else "重试翻译"; submit.isEnabled = modelReady; modelAction.isEnabled = true
                if (request != revision) {
                    status.text = "原文已修改，请重新翻译。"; output.text = "译文会显示在这里"; return
                }
                if (error != null || result.isNullOrBlank()) {
                    status.text = "翻译未完成，请重试或重新检查离线资源。"
                    modelAction.visibility=android.view.View.VISIBLE;modelAction.text="重新检查";checkFailed=true
                    output.text = "暂时无法翻译，请重试。"
                } else {
                    status.text = "译文由 Google 翻译提供，在手机上完成。机器译文仅供参考。"
                    output.text = result; copy.isEnabled = true
                }
            }
            try {
                val engine = translator ?: translatorFactory().also { translator = it }
                engine.translate(text, { complete(it, null) }, { complete(null, it) })
            } catch (e: Exception) { complete(null, e) }
        }
        submit.setOnClickListener { automaticPending = false; requestTranslation?.invoke() }
        if (restoredOutput.isNotBlank()) { output.text = restoredOutput; copy.isEnabled = true }
        snapshot = { org.json.JSONObject().put("input", input.text.toString())
            .put("output", if (copy.isEnabled) output.text.toString() else "").put("auto", autoTranslate) }
        checkModel()
    }

    private var snapshot: (() -> org.json.JSONObject)? = null
    fun state(): org.json.JSONObject? = snapshot?.invoke()
    fun dismiss() { dialog?.dismiss() }
    companion object { const val MAX_LENGTH = 3000 }
}

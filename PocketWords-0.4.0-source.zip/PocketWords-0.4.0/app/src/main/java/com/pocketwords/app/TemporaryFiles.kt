package com.pocketwords.app

import android.content.Context
import java.io.File

internal object TemporaryFiles {
    private val prefixes = listOf("screen-", "lookup-", "restore-", "lookup-state-")
    fun cleanup(context: Context, now: Long = System.currentTimeMillis()) {
        context.cacheDir.listFiles()?.filter { file ->
            prefixes.any { file.name.startsWith(it) } && now - file.lastModified() > 24 * 60 * 60 * 1000L
        }?.forEach { it.deleteRecursively() }
    }
    fun deletePreview(context: Context, path: String) {
        val file = File(path)
        if (file.parentFile?.canonicalFile == context.cacheDir.canonicalFile &&
            (file.name.startsWith("lookup-") || file.name.startsWith("screen-"))) file.delete()
    }
}

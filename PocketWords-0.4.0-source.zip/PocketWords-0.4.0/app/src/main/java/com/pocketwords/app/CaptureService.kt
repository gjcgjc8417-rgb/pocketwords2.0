package com.pocketwords.app

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.WindowManager
import android.widget.Toast
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

class CaptureService : Service() {
    private var projection: MediaProjection? = null
    private var projectionCallback: MediaProjection.Callback? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private val handler = Handler(Looper.getMainLooper())
    private val frames = CaptureFrameBuffer<Image> { it.close() }
    private var processing = false
    private var captureRequested = false
    private var captureSequence = 0L
    private var captureAfter = 0L
    @Volatile private var generation = 0L
    private val imageIo = java.util.concurrent.Executors.newSingleThreadExecutor()
    private val imageLock = Any()
    private var captureTimeout: Runnable? = null
    private var settle: Runnable? = null
    private var pendingDelivery: Runnable? = null
    private var pendingResultFile: File? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null || intent.action == ACTION_STOP_CAPTURE) {
            stopCapture(); return START_NOT_STICKY
        }
        if (intent.action == ACTION_CAPTURE_ONCE) {
            // An expired session must not try to start a media-projection foreground service
            // without fresh consent on Android 14+. The next bubble tap requests consent again.
            if (sessionActive && projection != null && virtualDisplay != null && imageReader != null) requestCapture()
            else { message("屏幕共享已结束，请再点取词重新授权。"); stopCapture() }
            return START_NOT_STICKY
        }
        val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
            else @Suppress("DEPRECATION") intent.getParcelableExtra(EXTRA_RESULT_DATA)
        if (resultCode != Activity.RESULT_OK || data == null) { stopCapture(); return START_NOT_STICKY }
        if (sessionActive && projection != null) { requestCapture(); return START_NOT_STICKY }
        try {
            createNotificationChannel()
            if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIFICATION_ID, notification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
            else startForeground(NOTIFICATION_ID, notification())
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val session = manager.getMediaProjection(resultCode, data) ?: error("No projection")
            projection = session
            val callback = object : MediaProjection.Callback() {
                override fun onStop() {
                    if (projection === session) {
                        releaseCapture(stopProjection = false)
                        stopForeground(STOP_FOREGROUND_REMOVE); stopSelf()
                    }
                }
                override fun onCapturedContentResize(width: Int, height: Int) {
                    if (projection === session && virtualDisplay != null) resizeCapture(width, height)
                }
            }
            projectionCallback = callback; session.registerCallback(callback, handler)
            if (!startCapture()) error("No virtual display")
            requestCapture()
        } catch (_: Exception) {
            message("屏幕共享未能启动，请再点取词重新授权。")
            stopCapture()
        }
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun metrics() = DisplayMetrics().also { (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(it) }

    private fun reader(width: Int, height: Int): ImageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 3).apply {
        setOnImageAvailableListener({ available ->
            val frame = try { available.acquireLatestImage() } catch (_: RuntimeException) { null }
                ?: return@setOnImageAvailableListener
            if (available !== imageReader) { frame.close(); return@setOnImageAvailableListener }
            frames.offer(frame)
            captureLatest()
        }, handler)
    }

    private fun startCapture(): Boolean {
        val metrics = metrics()
        val reader = reader(metrics.widthPixels.coerceAtLeast(1), metrics.heightPixels.coerceAtLeast(1))
        imageReader = reader
        virtualDisplay = projection?.createVirtualDisplay("PocketWordsCapture", reader.width, reader.height, metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.surface, null, handler)
        sessionActive = virtualDisplay != null
        return sessionActive
    }

    private fun resizeCapture(width: Int, height: Int) {
        val display = virtualDisplay ?: return
        if (width <= 0 || height <= 0 || imageReader?.let { it.width == width && it.height == height } == true) return
        val old = imageReader
        try {
            frames.clear()
            val next = reader(width, height)
            imageReader = next
            // Android 14+ allows one virtual display per grant. Resize it; never reuse the grant.
            display.resize(width, height, metrics().densityDpi)
            display.surface = next.surface
        } catch (_: RuntimeException) {
            message("屏幕尺寸变化后取词未能继续，请重新授权。")
            stopCapture()
        } finally {
            try { synchronized(imageLock) { old?.setOnImageAvailableListener(null, null); old?.close() } } catch (_: RuntimeException) {}
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (Build.VERSION.SDK_INT < 34 && sessionActive) metrics().let { resizeCapture(it.widthPixels, it.heightPixels) }
    }

    private fun requestCapture() {
        if (processing || captureRequested || pendingDelivery != null) { message("正在识别，请稍候。"); return }
        captureRequested = true
        captureSequence = frames.sequence
        captureAfter = SystemClock.uptimeMillis() + SETTLE_DELAY_MS
        OverlayService.setCaptureHidden(this, true)
        settle = Runnable { captureLatest() }.also { handler.postDelayed(it, SETTLE_DELAY_MS) }
        captureTimeout = Runnable {
            if (captureRequested) {
                message("未收到新的屏幕画面，请再点取词重新授权。")
                stopCapture()
            }
        }.also { handler.postDelayed(it, CAPTURE_TIMEOUT_MS) }
    }

    private fun captureLatest() {
        if (!captureRequested || processing || SystemClock.uptimeMillis() < captureAfter) return
        // Take the latest frame even if the source is now static and will produce no further frames.
        val image = frames.takeNewerThan(captureSequence) ?: return
        captureRequested = false; processing = true
        captureTimeout?.let(handler::removeCallbacks); captureTimeout = null
        settle?.let(handler::removeCallbacks); settle = null
        val requestGeneration = generation
        imageIo.execute {
            if (generation != requestGeneration) { image.close(); return@execute }
        val captured = synchronized(imageLock) { try {
            val width = image.width; val height = image.height
            val plane = image.planes[0]
            // Copy only image pixels: some devices omit the last row's stride padding.
            val pixels = java.nio.ByteBuffer.allocateDirect(width * height * 4)
            for (row in 0 until height) {
                val source = plane.buffer.duplicate()
                (source as java.nio.Buffer).position(row * plane.rowStride)
                (source as java.nio.Buffer).limit(row * plane.rowStride + width * 4)
                pixels.put(source)
            }
            (pixels as java.nio.Buffer).flip()
            Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888).apply { copyPixelsFromBuffer(pixels) }
        } catch (_: RuntimeException) { null } finally { image.close() } }

            handler.post {
                OverlayService.setCaptureHidden(this, false)
                if (generation != requestGeneration || projection == null) captured?.recycle()
                else if (captured == null) { processing = false; message("没有取得屏幕画面，请重试。") }
                else recognize(captured, requestGeneration)
            }
        }
    }

    private fun recognize(captured: Bitmap, requestGeneration: Long) {
        imageIo.execute {
            var file: File? = null
            val saved = runCatching {
                File.createTempFile("screen-", ".png", cacheDir).also { target ->
                    file = target
                    FileOutputStream(target).use { check(captured.compress(Bitmap.CompressFormat.PNG,100,it)) }
                }
            }
            handler.post {
                if (generation != requestGeneration || projection == null) { file?.delete(); captured.recycle() }
                else saved.fold({ processRecognition(captured,it,requestGeneration) }, {
                    file?.delete(); captured.recycle(); processing=false; message("无法保存截图，请检查可用空间。")
                })
            }
        }
    }
    private fun processRecognition(captured: Bitmap, imageFile: File, requestGeneration: Long) {
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        try {
            recognizer.process(InputImage.fromBitmap(captured, 0))
                .addOnSuccessListener { result ->
                    if (generation != requestGeneration || projection == null) { imageFile.delete(); return@addOnSuccessListener }
                    val boxes = JSONArray()
                    result.textBlocks.forEachIndexed { blockIndex, block ->
                        var contextWritten = false
                        block.lines.forEach { line -> line.elements.forEach { element ->
                            val rect = element.boundingBox
                            if (element.text.any { it.isLetter() } && rect != null) {
                                boxes.put(JSONObject().put("text", element.text.trim()).put("left", rect.left).put("top", rect.top)
                                    .put("right", rect.right).put("bottom", rect.bottom).put("block", blockIndex).apply {
                                        if (!contextWritten) { put("context", block.text); contextWritten = true }
                                    })
                            }
                        } }
                    }
                    val text = result.textBlocks.joinToString("\n\n") { it.text }
                    if (text.isBlank()) { imageFile.delete(); message("没有识别到清晰英文，请放大原文后重试。"); return@addOnSuccessListener }
                    val resultIntent = Intent(this, ScreenLookupActivity::class.java).setAction(ACTION_OCR_RESULT)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                        .putExtra(EXTRA_TEXT, text).putExtra(EXTRA_IMAGE_PATH, imageFile.absolutePath).putExtra(EXTRA_WORD_BOXES, boxes.toString())
                        .putExtra(EXTRA_IMAGE_WIDTH, captured.width).putExtra(EXTRA_IMAGE_HEIGHT, captured.height)
                    // Let the restored overlay become visible before a background launch.
                    // Android 15 checks for an actually visible SYSTEM_ALERT_WINDOW window.
                    pendingResultFile = imageFile
                    pendingDelivery = Runnable {
                        pendingDelivery = null; pendingResultFile = null
                        if (generation != requestGeneration || projection == null) { imageFile.delete(); return@Runnable }
                        try { startActivity(resultIntent) }
                        catch (_: RuntimeException) { imageFile.delete(); message("无法打开识别结果，请再次点击取词。"); }
                    }.also { handler.postDelayed(it, 150) }
                }
                .addOnFailureListener {
                    imageFile.delete()
                    if (generation == requestGeneration) message("识别失败，请再点取词重试。")
                }
                .addOnCompleteListener {
                    if (generation == requestGeneration) processing = false
                    captured.recycle(); recognizer.close()
                }
        } catch (_: RuntimeException) {
            captured.recycle(); recognizer.close(); imageFile.delete(); processing = false; message("识别未能开始，请重试。")
        }
    }

    private fun releaseCapture(stopProjection: Boolean = true) {
        generation++; sessionActive = false; captureRequested = false; processing = false
        captureTimeout?.let(handler::removeCallbacks); captureTimeout = null
        settle?.let(handler::removeCallbacks); settle = null
        pendingDelivery?.let(handler::removeCallbacks); pendingDelivery = null
        pendingResultFile?.delete(); pendingResultFile = null
        OverlayService.setCaptureHidden(this, false)
        frames.clear()
        try { virtualDisplay?.release() } catch (_: RuntimeException) {}
        virtualDisplay = null
        try { synchronized(imageLock) { imageReader?.setOnImageAvailableListener(null, null); imageReader?.close() } } catch (_: RuntimeException) {}
        imageReader = null
        val oldProjection = projection; projection = null
        try { projectionCallback?.let { oldProjection?.unregisterCallback(it) } } catch (_: RuntimeException) {}
        projectionCallback = null
        if (stopProjection) try { oldProjection?.stop() } catch (_: RuntimeException) {}
    }
    private fun stopCapture() { releaseCapture(); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf() }
    private fun message(text: String) { Toast.makeText(this, text, Toast.LENGTH_LONG).show() }
    private fun notification(): Notification {
        val stop = PendingIntent.getService(this, STOP_REQUEST_CODE, Intent(this, CaptureService::class.java).setAction(ACTION_STOP_CAPTURE),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, CHANNEL_ID).setContentTitle("随身单词本取词已开启")
            .setContentText("轻点悬浮按钮截取当前应用；关闭结果后返回原应用")
            .setSmallIcon(android.R.drawable.ic_menu_search).setOngoing(true)
            .addAction(android.R.drawable.ic_media_pause, "停止取词", stop).build()
    }
    private fun createNotificationChannel() {
        getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel(CHANNEL_ID, "屏幕取词", NotificationManager.IMPORTANCE_LOW))
    }
    override fun onDestroy() { releaseCapture(); imageIo.shutdown(); super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
    companion object {
        const val ACTION_OCR_RESULT = "com.pocketwords.app.OCR_RESULT"
        const val ACTION_CAPTURE_ONCE = "com.pocketwords.app.CAPTURE_ONCE"
        const val ACTION_STOP_CAPTURE = "com.pocketwords.app.STOP_CAPTURE"
        const val EXTRA_TEXT = "ocr_text"
        const val EXTRA_IMAGE_PATH = "ocr_image_path"
        const val EXTRA_WORD_BOXES = "ocr_word_boxes"
        const val EXTRA_IMAGE_WIDTH = "ocr_image_width"
        const val EXTRA_IMAGE_HEIGHT = "ocr_image_height"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        @Volatile var sessionActive = false
            private set
        private const val CHANNEL_ID = "pocket_words_capture"
        private const val NOTIFICATION_ID = 731
        private const val STOP_REQUEST_CODE = 732
        private const val SETTLE_DELAY_MS = 450L
        private const val CAPTURE_TIMEOUT_MS = 5000L
    }
}

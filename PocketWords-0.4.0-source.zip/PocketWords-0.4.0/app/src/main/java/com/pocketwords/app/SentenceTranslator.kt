package com.pocketwords.app

import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.common.model.RemoteModelManager
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.TranslateRemoteModel
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions

/** Checking local model availability never starts a download. */
internal interface SentenceTranslator : AutoCloseable {
    fun checkModel(success: (Boolean) -> Unit, failure: (Exception) -> Unit)
    fun download(success: () -> Unit, failure: (Exception) -> Unit)
    fun translate(text: String, success: (String) -> Unit, failure: (Exception) -> Unit)
}

internal class OfflineSentenceTranslator : SentenceTranslator {
    private val client = Translation.getClient(TranslatorOptions.Builder()
        .setSourceLanguage(TranslateLanguage.ENGLISH)
        .setTargetLanguage(TranslateLanguage.CHINESE).build())
    private var closed = false

    override fun checkModel(success: (Boolean) -> Unit, failure: (Exception) -> Unit) {
        // English is built in; English <-> Chinese needs the Chinese model.
        val model = TranslateRemoteModel.Builder(TranslateLanguage.CHINESE).build()
        RemoteModelManager.getInstance().isModelDownloaded(model)
            .addOnSuccessListener { if (!closed) success(it) }
            .addOnFailureListener { if (!closed) failure(it) }
    }
    override fun download(success: () -> Unit, failure: (Exception) -> Unit) {
        client.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .addOnSuccessListener { if (!closed) success() }
            .addOnFailureListener { if (!closed) failure(it) }
    }
    override fun translate(text: String, success: (String) -> Unit, failure: (Exception) -> Unit) {
        client.translate(text)
            .addOnSuccessListener { if (!closed) success(it) }
            .addOnFailureListener { if (!closed) failure(it) }
    }
    override fun close() { closed = true; client.close() }
}

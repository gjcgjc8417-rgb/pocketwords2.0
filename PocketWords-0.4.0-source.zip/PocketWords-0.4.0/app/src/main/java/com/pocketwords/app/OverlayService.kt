package com.pocketwords.app

import android.animation.ValueAnimator
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.BroadcastReceiver
import android.content.IntentFilter
import androidx.core.content.ContextCompat
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.view.Display
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowInsets
import android.view.WindowManager
import android.widget.Toast

class OverlayService : Service() {
    private lateinit var windowManager: WindowManager
    private var bubble: View? = null
    private var params: WindowManager.LayoutParams? = null
    private val handler = Handler(Looper.getMainLooper())
    private var snapAnimator: ValueAnimator? = null
    private var dockedRight = true
    private var captureHidden = false
    private var lookupVisible = false
    private val visibilityReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.hasExtra(EXTRA_CAPTURE_HIDDEN) == true) captureHidden = intent.getBooleanExtra(EXTRA_CAPTURE_HIDDEN, false)
            if (intent?.hasExtra(EXTRA_LOOKUP_VISIBLE) == true) lookupVisible = intent.getBooleanExtra(EXTRA_LOOKUP_VISIBLE, false)
            bubble?.visibility = if (captureHidden || lookupVisible) View.INVISIBLE else View.VISIBLE
        }
    }

    override fun onCreate() {
        super.onCreate()
        ContextCompat.registerReceiver(this, visibilityReceiver, IntentFilter(ACTION_VISIBILITY), ContextCompat.RECEIVER_NOT_EXPORTED)
        val overlayContext = if (Build.VERSION.SDK_INT >= 30) {
            try {
                val display = (getSystemService(Context.DISPLAY_SERVICE) as DisplayManager).getDisplay(Display.DEFAULT_DISPLAY)
                if (display != null) createDisplayContext(display).createWindowContext(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, null) else this
            } catch (_: RuntimeException) { this }
        } else this
        windowManager = overlayContext.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val view = OverlayBubbleView(overlayContext)
        val prefs = getSharedPreferences("overlay_position", Context.MODE_PRIVATE)
        dockedRight = prefs.getBoolean("right", true)
        val lp = WindowManager.LayoutParams(dp(88), dp(48), WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.LEFT }
        val safe = safeBounds()
        lp.x = if (dockedRight) safe.right - lp.width else safe.left
        lp.y = prefs.getInt("y", safe.top + dp(150))
        constrain(lp)
        view.setOnClickListener {
            ScreenCaptureFlow.request(this)
        }
        view.setOnLongClickListener {
            view.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            Toast.makeText(this, "悬浮取词已关闭，可在首页重新开启。", Toast.LENGTH_SHORT).show()
            stopService(Intent(this, CaptureService::class.java))
            stopSelf(); true
        }
        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0
        var moved = false; var held = false
        val slop = ViewConfiguration.get(overlayContext).scaledTouchSlop
        val longPress = Runnable { held = true; view.performLongClick() }
        view.setOnTouchListener { target, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    snapAnimator?.cancel()
                    downX = event.rawX; downY = event.rawY; startX = lp.x; startY = lp.y
                    moved = false; held = false
                    handler.postDelayed(longPress, ViewConfiguration.getLongPressTimeout().toLong())
                    target.isPressed = true
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downX).toInt(); val dy = (event.rawY - downY).toInt()
                    if (kotlin.math.abs(dx) > slop || kotlin.math.abs(dy) > slop) {
                        moved = true; handler.removeCallbacks(longPress); target.isPressed = false
                    }
                    if (moved && !held) {
                        lp.x = startX + dx; lp.y = startY + dy
                        constrain(lp); updatePosition()
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    handler.removeCallbacks(longPress); target.isPressed = false
                    if (!held) {
                        if (moved) snapToEdge(lp) else target.performClick()
                    }
                    true
                }
                MotionEvent.ACTION_CANCEL -> {
                    handler.removeCallbacks(longPress); target.isPressed = false
                    if (moved && !held) snapToEdge(lp)
                    true
                }
                else -> true
            }
        }
        bubble = view; params = lp
        try { windowManager.addView(view, lp); updateActive(true) }
        catch (_: RuntimeException) {
            bubble = null; params = null; updateActive(false)
            Toast.makeText(this, "无法显示悬浮按钮，请检查悬浮窗权限。", Toast.LENGTH_LONG).show()
            stopSelf()
        }
    }

    private fun updateActive(value: Boolean) {
        active = value
        sendBroadcast(Intent(ACTION_STATE_CHANGED).setPackage(packageName))
    }

    private fun safeBounds(): Rect {
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                val metrics = windowManager.currentWindowMetrics
                val bars = metrics.windowInsets.getInsetsIgnoringVisibility(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
                return Rect(metrics.bounds.left + bars.left + dp(8), metrics.bounds.top + bars.top + dp(8),
                    metrics.bounds.right - bars.right - dp(8), metrics.bounds.bottom - bars.bottom - dp(8))
            } catch (_: RuntimeException) { /* Fall back to display bounds if metrics are not yet attached. */ }
        }
        val metrics = resources.displayMetrics
        return Rect(dp(8), dp(32), metrics.widthPixels - dp(8), metrics.heightPixels - dp(32))
    }
    private fun constrain(lp: WindowManager.LayoutParams) {
        val safe = safeBounds()
        lp.x = lp.x.coerceIn(safe.left, maxOf(safe.left, safe.right - lp.width))
        lp.y = lp.y.coerceIn(safe.top, maxOf(safe.top, safe.bottom - lp.height))
    }
    private fun updatePosition() {
        val view = bubble ?: return
        try { windowManager.updateViewLayout(view, params) } catch (_: RuntimeException) { stopSelf() }
    }
    private fun snapToEdge(lp: WindowManager.LayoutParams) {
        val safe = safeBounds()
        dockedRight = lp.x + lp.width / 2 >= safe.centerX()
        val end = if (dockedRight) maxOf(safe.left, safe.right - lp.width) else safe.left
        snapAnimator = ValueAnimator.ofInt(lp.x, end).apply {
            duration = 180
            addUpdateListener { lp.x = it.animatedValue as Int; updatePosition() }
            start()
        }
        getSharedPreferences("overlay_position", Context.MODE_PRIVATE).edit().putBoolean("right", dockedRight).putInt("y", lp.y).apply()
    }
    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        snapAnimator?.cancel()
        params?.let {
            val safe = safeBounds()
            it.x = if (dockedRight) maxOf(safe.left, safe.right - it.width) else safe.left
            constrain(it); updatePosition()
        }
    }
    override fun onDestroy() {
        try { unregisterReceiver(visibilityReceiver) } catch (_: RuntimeException) {}
        handler.removeCallbacksAndMessages(null); snapAnimator?.cancel()
        bubble?.let { try { windowManager.removeView(it) } catch (_: RuntimeException) {} }
        bubble = null; params = null; updateActive(false)
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
    private fun dp(value: Int) = BrandUi.dp(this, value)
    companion object {
        const val ACTION_CAPTURE = "com.pocketwords.app.CAPTURE_SCREEN"
        const val ACTION_STATE_CHANGED = "com.pocketwords.app.OVERLAY_STATE_CHANGED"
        private const val ACTION_VISIBILITY = "com.pocketwords.app.OVERLAY_VISIBILITY"
        private const val EXTRA_CAPTURE_HIDDEN = "capture_hidden"
        private const val EXTRA_LOOKUP_VISIBLE = "lookup_visible"
        fun setCaptureHidden(context: Context, hidden: Boolean) {
            context.sendBroadcast(Intent(ACTION_VISIBILITY).setPackage(context.packageName).putExtra(EXTRA_CAPTURE_HIDDEN, hidden))
        }
        fun setLookupVisible(context: Context, visible: Boolean) {
            context.sendBroadcast(Intent(ACTION_VISIBILITY).setPackage(context.packageName).putExtra(EXTRA_LOOKUP_VISIBLE, visible))
        }
        var active = false
            private set
    }
}

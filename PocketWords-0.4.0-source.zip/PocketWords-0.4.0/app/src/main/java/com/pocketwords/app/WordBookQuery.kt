package com.pocketwords.app

internal enum class BookFilter(val title: String) { ALL("全部"), DUE("待复习"), WEAK("待巩固"), MASTERED("已掌握"), MISSING("释义待补充"), PAUSED("已暂停") }
internal enum class BookSort(val title: String) { NEWEST("最近收藏"), ALPHABETICAL("英文 A–Z"), DUE("最早到期") }
internal object WordBookQuery {
    fun apply(cards: List<ReviewCard>, query: String, filter: BookFilter, sort: BookSort, now: Long): List<WordEntry> {
        val selected = cards.filter { c ->
            (c.entry.word.contains(query.trim(), true) || c.entry.meaning.contains(query.trim(), true)) && when (filter) {
                BookFilter.ALL -> true
                BookFilter.DUE -> !c.profile.paused && ReviewEngine.hasMeaning(c) && minOf(c.profile.meaning.due,c.profile.spelling.due) <= now
                BookFilter.WEAK -> c.profile.needsWork
                BookFilter.MASTERED -> c.profile.mastered
                BookFilter.MISSING -> !ReviewEngine.hasMeaning(c)
                BookFilter.PAUSED -> c.profile.paused
            }
        }
        return when (sort) {
            BookSort.NEWEST -> selected
            BookSort.ALPHABETICAL -> selected.sortedBy { WordForms.key(it.entry.word) }
            BookSort.DUE -> selected.sortedBy { minOf(it.profile.meaning.due,it.profile.spelling.due) }
        }.map { it.entry }
    }
}

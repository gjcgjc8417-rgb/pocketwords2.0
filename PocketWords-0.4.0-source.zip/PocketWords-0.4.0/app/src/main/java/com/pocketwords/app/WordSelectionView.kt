package com.pocketwords.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View

data class WordBox(val text: String, val left: Int, val top: Int, val right: Int, val bottom: Int, val context: String = "")

/** Drawing, hit testing and cropping share one image-to-view transform. */
class WordSelectionView(
    context: Context,
    private val bitmap: Bitmap,
    private val boxes: List<WordBox>,
    private val sourceWidth: Int,
    private val sourceHeight: Int,
    private val onWordSelected: (String) -> Unit
) : View(context) {
    private val imagePaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val boxPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x44D1E58A }
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = BrandUi.Forest; style = Paint.Style.STROKE; strokeWidth = resources.displayMetrics.density
    }
    private var zoom = 1f
    private var offsetX = 0f
    private var offsetY = 0f
    private var multiTouch = false
    var selectedBox: WordBox? = null
        private set
    private var selectingRegion = false
    private var region: RectF? = null
    private var regionStartX = 0f
    private var regionStartY = 0f
    private val regionPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = BrandUi.Forest; style = Paint.Style.STROKE; strokeWidth = BrandUi.dp(context, 3).toFloat()
    }
    private val imageRect: RectF
        get() {
            val scale = minOf(width.toFloat() / bitmap.width, height.toFloat() / bitmap.height) * zoom
            val w = bitmap.width * scale; val h = bitmap.height * scale
            return RectF((width - w) / 2 + offsetX, (height - h) / 2 + offsetY,
                (width + w) / 2 + offsetX, (height + h) / 2 + offsetY)
        }
    private val scaleDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            val before = imageRect
            region = null
            val next = (zoom * detector.scaleFactor).coerceIn(1f, 12f)
            val factor = next / zoom
            zoom = next
            val after = imageRect
            offsetX += detector.focusX - (after.left + (detector.focusX - before.left) * factor)
            offsetY += detector.focusY - (after.top + (detector.focusY - before.top) * factor)
            constrain(); invalidate(); return true
        }
    })
    private val gestures = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent) = true
        override fun onScroll(first: MotionEvent?, current: MotionEvent, dx: Float, dy: Float): Boolean {
            if (!scaleDetector.isInProgress && zoom > 1f) { offsetX -= dx; offsetY -= dy; constrain(); invalidate() }
            return true
        }
        override fun onDoubleTap(e: MotionEvent): Boolean {
            if (zoom >= 8f) { fitImage(); return true }
            val before = imageRect
            val next = (zoom * 3f).coerceAtMost(12f)
            val factor = next / zoom
            zoom = next
            val after = imageRect
            offsetX += e.x - (after.left + (e.x - before.left) * factor)
            offsetY += e.y - (after.top + (e.y - before.top) * factor)
            constrain(); invalidate(); return true
        }
        override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
            select(e.x, e.y); return true
        }
    })

    private fun constrain() {
        val rect = imageRect
        offsetX = if (rect.width() <= width) 0f else offsetX.coerceIn(-(rect.width() - width) / 2, (rect.width() - width) / 2)
        offsetY = if (rect.height() <= height) 0f else offsetY.coerceIn(-(rect.height() - height) / 2, (rect.height() - height) / 2)
    }

    fun setRegionSelectionEnabled(enabled: Boolean) {
        selectingRegion = enabled; region = null; invalidate()
    }

    fun zoomBy(factor: Float) {
        val next = (zoom * factor).coerceIn(1f, 12f)
        offsetX *= next / zoom; offsetY *= next / zoom; zoom = next
        region = null; constrain(); invalidate()
    }

    fun fitWidth() {
        if (width <= 0 || height <= 0) return
        val fit = minOf(width.toFloat() / bitmap.width, height.toFloat() / bitmap.height)
        zoom = (width.toFloat() / bitmap.width / fit).coerceIn(1f, 12f)
        offsetX = 0f
        // Start at the top of tall screenshots, then drag to read further down.
        offsetY = maxOf(0f, (bitmap.height * fit * zoom - height) / 2f)
        region = null; constrain(); invalidate()
    }

    fun fitImage() {
        zoom = 1f; offsetX = 0f; offsetY = 0f; region = null; invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (w > 0 && h > 0) { region = null; constrain() }
    }

    override fun onDraw(canvas: Canvas) {
        val rect = imageRect
        canvas.drawColor(BrandUi.Paper)
        canvas.drawBitmap(bitmap, null, rect, imagePaint)
        val sx = rect.width() / sourceWidth.coerceAtLeast(1)
        val sy = rect.height() / sourceHeight.coerceAtLeast(1)
        boxes.forEach {
            val box = RectF(rect.left + it.left * sx, rect.top + it.top * sy, rect.left + it.right * sx, rect.top + it.bottom * sy)
            canvas.drawRect(box, boxPaint); canvas.drawRect(box, borderPaint)
        }
        region?.let { canvas.drawRect(it, regionPaint) }
    }

    private fun select(x: Float, y: Float) {
        val rect = imageRect
        if (!rect.contains(x, y)) return
        val px = (x - rect.left) / rect.width() * sourceWidth
        val py = (y - rect.top) / rect.height() * sourceHeight
        val exact = boxes.filter { px >= it.left && px <= it.right && py >= it.top && py <= it.bottom }
            .minByOrNull { (it.right - it.left).toLong() * (it.bottom - it.top) }
        // Nearby taps use distance in screen pixels, so zoom does not inflate the tolerance.
        val tolerance = BrandUi.dp(context, 12).toFloat()
        val nearby = if (exact == null) boxes.map { box ->
            val dx = maxOf(box.left - px, 0f, px - box.right) * rect.width() / sourceWidth.coerceAtLeast(1)
            val dy = maxOf(box.top - py, 0f, py - box.bottom) * rect.height() / sourceHeight.coerceAtLeast(1)
            box to (dx * dx + dy * dy)
        }.filter { it.second <= tolerance * tolerance }.minByOrNull { it.second }?.first else null
        val hit = exact ?: nearby
        if (hit != null) { selectedBox = hit; performClick(); onWordSelected(hit.text) }
    }

    /** Save only the source paragraph, without OCR highlights or the rest of the screen. */
    fun cropContext(): Bitmap? {
        val selected = selectedBox ?: return null
        val group = if (selected.context.isBlank()) listOf(selected) else boxes.filter { it.context == selected.context }
        val padding = maxOf(12, selected.bottom - selected.top)
        val rect = imageRect
        val sx = rect.width() / sourceWidth.coerceAtLeast(1)
        val sy = rect.height() / sourceHeight.coerceAtLeast(1)
        return crop(RectF(rect.left + (group.minOf { it.left } - padding) * sx,
            rect.top + (group.minOf { it.top } - padding) * sy,
            rect.left + (group.maxOf { it.right } + padding) * sx,
            rect.top + (group.maxOf { it.bottom } + padding) * sy))
    }

    fun visibleArea(): RectF = normalized(RectF(0f,0f,width.toFloat(),height.toFloat()))
    fun selectionArea(): RectF? = region?.takeIf { it.width() >= BrandUi.dp(context,12) && it.height() >= BrandUi.dp(context,12) }?.let(::normalized)
    fun contextArea(): RectF? {
        val selected = selectedBox ?: return null
        val group = if (selected.context.isBlank()) listOf(selected) else boxes.filter { it.context == selected.context }
        val padding = maxOf(12, selected.bottom-selected.top)
        return RectF(((group.minOf { it.left }-padding).toFloat()/sourceWidth).coerceIn(0f,1f),
            ((group.minOf { it.top }-padding).toFloat()/sourceHeight).coerceIn(0f,1f),
            ((group.maxOf { it.right }+padding).toFloat()/sourceWidth).coerceIn(0f,1f),
            ((group.maxOf { it.bottom }+padding).toFloat()/sourceHeight).coerceIn(0f,1f))
    }
    private fun normalized(area: RectF): RectF {
        val image = imageRect
        return RectF(((area.left-image.left)/image.width()).coerceIn(0f,1f),((area.top-image.top)/image.height()).coerceIn(0f,1f),
            ((area.right-image.left)/image.width()).coerceIn(0f,1f),((area.bottom-image.top)/image.height()).coerceIn(0f,1f))
    }

    /** Crop the original pixels, without drawing OCR boxes into the next input. */
    fun cropVisible(): Bitmap {
        return crop(RectF(0f, 0f, width.toFloat(), height.toFloat()))
    }

    fun cropSelection(): Bitmap? {
        val selected = region ?: return null
        if (selected.width() < BrandUi.dp(context, 12) || selected.height() < BrandUi.dp(context, 12)) return null
        return crop(selected)
    }

    private fun crop(area: RectF): Bitmap {
        val rect = imageRect
        val left = ((area.left - rect.left).coerceAtLeast(0f) / rect.width() * bitmap.width).toInt().coerceIn(0, bitmap.width - 1)
        val top = ((area.top - rect.top).coerceAtLeast(0f) / rect.height() * bitmap.height).toInt().coerceIn(0, bitmap.height - 1)
        val right = ((area.right - rect.left).coerceAtMost(rect.width()) / rect.width() * bitmap.width).toInt().coerceIn(left + 1, bitmap.width)
        val bottom = ((area.bottom - rect.top).coerceAtMost(rect.height()) / rect.height() * bitmap.height).toInt().coerceIn(top + 1, bitmap.height)
        val cropped = Bitmap.createBitmap(bitmap, left, top, right - left, bottom - top)
        return try { checkNotNull(cropped.copy(Bitmap.Config.ARGB_8888, false)) }
        finally { if (cropped !== bitmap) cropped.recycle() }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        parent?.requestDisallowInterceptTouchEvent(true)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> multiTouch = false
            MotionEvent.ACTION_POINTER_DOWN -> multiTouch = true
        }
        scaleDetector.onTouchEvent(event)
        if (selectingRegion) {
            if (multiTouch) { region = null; invalidate(); return true }
            val rect = imageRect
            val x = event.x.coerceIn(maxOf(0f, rect.left), minOf(width.toFloat(), rect.right))
            val y = event.y.coerceIn(maxOf(0f, rect.top), minOf(height.toFloat(), rect.bottom))
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> { regionStartX = x; regionStartY = y; region = null }
                MotionEvent.ACTION_MOVE, MotionEvent.ACTION_UP -> {
                    region = RectF(minOf(regionStartX, x), minOf(regionStartY, y), maxOf(regionStartX, x), maxOf(regionStartY, y))
                }
                MotionEvent.ACTION_CANCEL -> region = null
            }
            invalidate(); return true
        }
        // Suppress taps at the end of a pinch; continue feeding regular drags to the gesture detector.
        if (!multiTouch) gestures.onTouchEvent(event)
        else if (event.actionMasked == MotionEvent.ACTION_POINTER_DOWN || event.actionMasked == MotionEvent.ACTION_UP || event.actionMasked == MotionEvent.ACTION_CANCEL) {
            val cancel = MotionEvent.obtain(event); cancel.action = MotionEvent.ACTION_CANCEL
            gestures.onTouchEvent(cancel); cancel.recycle()
        }
        return true
    }

    fun state() = org.json.JSONObject().put("zoom", zoom).put("x", offsetX / width.coerceAtLeast(1))
        .put("y", offsetY / height.coerceAtLeast(1)).apply {
            selectionArea()?.let { put("selection", org.json.JSONArray(listOf(it.left, it.top, it.right, it.bottom))) }
        }
    fun restore(state: org.json.JSONObject) {
        zoom = state.optDouble("zoom", 1.0).toFloat().coerceIn(1f, 12f)
        offsetX = state.optDouble("x").toFloat() * width
        offsetY = state.optDouble("y").toFloat() * height
        constrain()
        state.optJSONArray("selection")?.let { a ->
            val r = imageRect
            region = RectF(r.left + a.getDouble(0).toFloat() * r.width(), r.top + a.getDouble(1).toFloat() * r.height(),
                r.left + a.getDouble(2).toFloat() * r.width(), r.top + a.getDouble(3).toFloat() * r.height())
        }
        invalidate()
    }

    override fun performClick(): Boolean { super.performClick(); return true }
}

package com.pocketwords.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View

data class WordBox(val text: String, val left: Int, val top: Int, val right: Int, val bottom: Int)

/** Drawing, hit testing and cropping share one image-to-view transform. */
class WordSelectionView(
    context: Context,
    private val bitmap: Bitmap,
    private val boxes: List<WordBox>,
    private val sourceWidth: Int,
    private val sourceHeight: Int,
    private val onWordSelected: (String) -> Unit
) : View(context) {
    private val imagePaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val boxPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x4432A879 }
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF16845D.toInt(); style = Paint.Style.STROKE; strokeWidth = resources.displayMetrics.density
    }
    private var zoom = 1f
    private var offsetX = 0f
    private var offsetY = 0f
    private var multiTouch = false
    private val imageRect: RectF
        get() {
            val scale = minOf(width.toFloat() / bitmap.width, height.toFloat() / bitmap.height) * zoom
            val w = bitmap.width * scale; val h = bitmap.height * scale
            return RectF((width - w) / 2 + offsetX, (height - h) / 2 + offsetY,
                (width + w) / 2 + offsetX, (height + h) / 2 + offsetY)
        }
    private val scaleDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            val before = imageRect
            val next = (zoom * detector.scaleFactor).coerceIn(1f, 8f)
            val factor = next / zoom
            zoom = next
            val after = imageRect
            offsetX += detector.focusX - (after.left + (detector.focusX - before.left) * factor)
            offsetY += detector.focusY - (after.top + (detector.focusY - before.top) * factor)
            constrain(); invalidate(); return true
        }
    })
    private val gestures = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent) = true
        override fun onScroll(first: MotionEvent?, current: MotionEvent, dx: Float, dy: Float): Boolean {
            if (!scaleDetector.isInProgress && zoom > 1f) { offsetX -= dx; offsetY -= dy; constrain(); invalidate() }
            return true
        }
        override fun onDoubleTap(e: MotionEvent): Boolean {
            if (zoom > 1f) { zoom = 1f; offsetX = 0f; offsetY = 0f }
            else { zoom = 3f; offsetX = (width / 2f - e.x) * zoom; offsetY = (height / 2f - e.y) * zoom }
            constrain(); invalidate(); return true
        }
        override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
            select(e.x, e.y); return true
        }
    })

    private fun constrain() {
        val rect = imageRect
        offsetX = if (rect.width() <= width) 0f else offsetX.coerceIn(-(rect.width() - width) / 2, (rect.width() - width) / 2)
        offsetY = if (rect.height() <= height) 0f else offsetY.coerceIn(-(rect.height() - height) / 2, (rect.height() - height) / 2)
    }

    override fun onDraw(canvas: Canvas) {
        val rect = imageRect
        canvas.drawColor(0xFFE8ECE9.toInt())
        canvas.drawBitmap(bitmap, null, rect, imagePaint)
        val sx = rect.width() / sourceWidth.coerceAtLeast(1)
        val sy = rect.height() / sourceHeight.coerceAtLeast(1)
        boxes.forEach {
            val box = RectF(rect.left + it.left * sx, rect.top + it.top * sy, rect.left + it.right * sx, rect.top + it.bottom * sy)
            canvas.drawRect(box, boxPaint); canvas.drawRect(box, borderPaint)
        }
    }

    private fun select(x: Float, y: Float) {
        val rect = imageRect
        if (!rect.contains(x, y)) return
        val px = (x - rect.left) / rect.width() * sourceWidth
        val py = (y - rect.top) / rect.height() * sourceHeight
        val hit = boxes.filter { px >= it.left && px <= it.right && py >= it.top && py <= it.bottom }
            .minByOrNull { (it.right - it.left).toLong() * (it.bottom - it.top) }
        if (hit != null) { performClick(); onWordSelected(hit.text) }
    }

    /** Crop the original pixels, without drawing OCR boxes into the next input. */
    fun cropVisible(): Bitmap {
        val rect = imageRect
        val left = ((0f - rect.left).coerceAtLeast(0f) / rect.width() * bitmap.width).toInt().coerceIn(0, bitmap.width - 1)
        val top = ((0f - rect.top).coerceAtLeast(0f) / rect.height() * bitmap.height).toInt().coerceIn(0, bitmap.height - 1)
        val right = ((width - rect.left).coerceAtMost(rect.width()) / rect.width() * bitmap.width).toInt().coerceIn(left + 1, bitmap.width)
        val bottom = ((height - rect.top).coerceAtMost(rect.height()) / rect.height() * bitmap.height).toInt().coerceIn(top + 1, bitmap.height)
        val cropped = Bitmap.createBitmap(bitmap, left, top, right - left, bottom - top)
        return try { checkNotNull(cropped.copy(Bitmap.Config.ARGB_8888, false)) }
        finally { if (cropped !== bitmap) cropped.recycle() }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        parent?.requestDisallowInterceptTouchEvent(true)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> multiTouch = false
            MotionEvent.ACTION_POINTER_DOWN -> multiTouch = true
        }
        scaleDetector.onTouchEvent(event)
        // Suppress taps at the end of a pinch; continue feeding regular drags to the gesture detector.
        if (!multiTouch) gestures.onTouchEvent(event)
        else if (event.actionMasked == MotionEvent.ACTION_POINTER_DOWN || event.actionMasked == MotionEvent.ACTION_UP || event.actionMasked == MotionEvent.ACTION_CANCEL) {
            val cancel = MotionEvent.obtain(event); cancel.action = MotionEvent.ACTION_CANCEL
            gestures.onTouchEvent(cancel); cancel.recycle()
        }
        return true
    }

    override fun performClick(): Boolean { super.performClick(); return true }
}

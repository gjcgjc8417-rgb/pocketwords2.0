package com.pocketwords.app

/** Keep one native frame, so a static source is still capturable after the UI has settled. */
internal class CaptureFrameBuffer<T>(private val release: (T) -> Unit) {
    private var frame: T? = null
    var sequence: Long = 0
        private set
    fun offer(value: T) {
        frame?.let(release)
        frame = value; sequence++
    }
    fun takeNewerThan(sequenceAtRequest: Long): T? {
        if (sequence <= sequenceAtRequest) return null
        val value = frame; frame = null
        return value
    }
    fun clear() { frame?.let(release); frame = null }
}

package com.pocketwords.app

import android.app.Activity
import android.app.AlertDialog
import android.widget.Toast

/** Uses OCR reading order, so selected wrapped lines remain in their original order. */
internal object OcrLineSelectionDialog {
    fun show(activity: Activity, text: String, selected: (String) -> Unit): AlertDialog {
        val lines = text.lineSequence().map { it.trim() }.filter { it.isNotEmpty() }.toList()
        val checked = BooleanArray(lines.size)
        val dialog = AlertDialog.Builder(activity).setTitle("选择要翻译的行（可多选）")
            .setMultiChoiceItems(lines.toTypedArray(), checked) { _, index, value -> checked[index] = value }
            .setNegativeButton("取消", null).setNeutralButton("全选", null)
            .setPositiveButton("使用所选文字", null).create()
        fun update() {
            val count = checked.count { it }
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).text = "使用所选文字（$count 行）"
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).isEnabled = count > 0
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).text = if (checked.isNotEmpty() && checked.all { it }) "取消全选" else "全选"
        }
        dialog.show()
        dialog.listView.setOnItemClickListener { _, _, position, _ ->
            checked[position] = dialog.listView.isItemChecked(position); update()
        }
        dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
            val value = !checked.all { it }
            checked.indices.forEach { checked[it] = value; dialog.listView.setItemChecked(it, value) }; update()
        }
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val result = lines.filterIndexed { index, _ -> checked[index] }.joinToString("\n")
            if (result.length > SentenceTranslationDialog.MAX_LENGTH) {
                Toast.makeText(activity, "所选文字超过 3000 字符，请减少选择，分段翻译。", Toast.LENGTH_LONG).show()
            } else if (result.isNotBlank()) { dialog.dismiss(); selected(result) }
        }
        update()
        return dialog
    }
}

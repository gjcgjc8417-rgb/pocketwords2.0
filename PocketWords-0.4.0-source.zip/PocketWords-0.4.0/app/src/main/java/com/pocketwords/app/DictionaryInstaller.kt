package com.pocketwords.app

import java.io.File
import java.io.InputStream

/** Keep the old usable database until the replacement has been fully copied and validated. */
internal class DictionaryInstaller(private val database: File, private val versionFile: File) {
    fun needsInstall(version: String): Boolean = !database.exists() || database.length() == 0L ||
        !versionFile.exists() || versionFile.readText().trim() != version

    fun install(version: String, source: () -> InputStream, validate: (File) -> Unit) {
        val temporary = File(database.parentFile, database.name + ".tmp")
        val temporaryVersion = File(versionFile.parentFile, versionFile.name + ".tmp")
        try {
            source().use { input -> temporary.outputStream().use { input.copyTo(it) } }
            validate(temporary)
            temporaryVersion.writeText(version)
            check(temporary.renameTo(database)) { "无法安装离线词典，请检查存储空间。" }
            // If this is interrupted, a mismatched version triggers a safe reinstall on next launch.
            check(temporaryVersion.renameTo(versionFile)) { "无法保存词典版本，请重试。" }
        } finally {
            temporary.delete(); temporaryVersion.delete()
        }
    }
}

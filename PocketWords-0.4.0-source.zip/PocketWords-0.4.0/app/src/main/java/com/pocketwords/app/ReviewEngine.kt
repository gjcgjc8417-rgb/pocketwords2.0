package com.pocketwords.app

import java.time.Instant
import java.time.ZoneId

internal enum class ReviewSkill { MEANING, SPELLING }
internal enum class QuizKind(val title: String) { RECALL("回想释义"), SPELL("拼写练习"), CLOZE("原句填空") }
internal enum class ReviewMode(val title: String) { MIXED("混合练习"), RECALL("快速认词"), SPELL("拼写挑战"), CLOZE("原句填空") }
internal enum class ReviewScope(val title: String) { DUE("今日到期"), ALL("全部单词"), RECENT("最近收藏"), WEAK("容易忘的词"), SOURCE("同次取词") }
internal data class SkillProgress(val level: Int = 0, val due: Long = 0, val goodDay: String = "", val errors: Int = 0, val needsWork: Boolean = false)
internal data class ReviewProfile(
    val word: String, val meaning: SkillProgress = SkillProgress(), val spelling: SkillProgress = SkillProgress(),
    val paused: Boolean = false, val created: Long = 0, val phonetic: String = ""
) {
    val needsWork get() = meaning.needsWork || spelling.needsWork
    val mastered get() = meaning.level >= 3 && spelling.level >= 3 && !needsWork
    val errors get() = meaning.errors + spelling.errors
    val stage get() = when { paused -> "已暂停"; needsWork -> "待巩固"; mastered -> "已掌握"; meaning.level + spelling.level > 0 -> "学习中"; else -> "新收藏" }
}
internal data class ReadingContext(val id: Long = 0, val sentence: String = "", val note: String = "", val image: String = "", val source: String = "", val created: Long = 0, val pinned: Boolean = false)
internal data class ReviewCard(val entry: WordEntry, val profile: ReviewProfile, val contexts: List<ReadingContext> = emptyList(), val phonetic: String = "") {
    val clozeContext get() = contexts.firstOrNull { ReviewEngine.cloze(it.sentence, entry.word) != null }
}
internal data class ReviewTask(val word: String, val kind: QuizKind, val retry: Boolean = false) {
    val skill get() = if (kind == QuizKind.RECALL) ReviewSkill.MEANING else ReviewSkill.SPELLING
    val key get() = WordForms.key(word) + ":" + skill.name
}
internal data class ReviewRun(
    val tasks: MutableList<ReviewTask>, var index: Int = 0, var answered: Int = 0, var correct: Int = 0,
    val wrong: MutableSet<String> = linkedSetOf(), val retried: MutableSet<String> = linkedSetOf(),
    var elapsed: Long = 0, val short: Boolean = false, val id: String = java.util.UUID.randomUUID().toString(),
    var pendingHinted: Boolean = false, var pendingRevealed: Boolean = false, var pendingTyped: String = ""
) {
    val finished get() = index >= tasks.size || short && elapsed >= 180_000
    fun record(rating: Int) {
        val task = tasks[index]
        answered++
        if (rating == 2) correct++ else wrong.add(WordForms.key(task.word))
        if (rating == 0 && !task.retry && retried.add(task.key)) {
            val retryKind = if (task.kind == QuizKind.RECALL || task.kind == QuizKind.CLOZE) QuizKind.SPELL else task.kind
            tasks.add(minOf(index + 4, tasks.size), ReviewTask(task.word, retryKind, true))
        }
        index++
        pendingHinted = false; pendingRevealed = false; pendingTyped = ""
    }
}

internal object ReviewEngine {
    const val DAY = 86_400_000L
    fun day(now: Long) = Instant.ofEpochMilli(now).atZone(ZoneId.systemDefault()).toLocalDate().toString()
    fun advance(old: SkillProgress, rating: Int, now: Long): SkillProgress {
        require(rating in 0..2)
        val today = day(now)
        return when (rating) {
            0 -> old.copy(level = maxOf(0, old.level - 1), due = now + DAY, errors = old.errors + 1, needsWork = true)
            1 -> old.copy(due = now + DAY, needsWork = true)
            else -> {
                if (old.goodDay == today || old.due > now) return old
                val level = minOf(6, old.level + 1)
                val interval = listOf(1, 3, 7, 14, 30, 60)[(level - 1).coerceIn(0, 5)]
                old.copy(level = level, goodDay = today, due = now + interval * DAY, needsWork = false)
            }
        }
    }

    fun cloze(sentence: String, word: String): String? {
        if (sentence.isBlank() || word.isBlank()) return null
        val pattern = Regex("(?<![\\p{L}\\p{N}])" + Regex.escape(word.trim()) + "(?![\\p{L}\\p{N}])", RegexOption.IGNORE_CASE)
        return if (pattern.containsMatchIn(sentence)) pattern.replace(sentence, "______") else null
    }

    fun isCorrect(answer: String, word: String) = answer.trim().equals(word.trim(), ignoreCase = true)
    fun promptMeaning(meaning: String) = meaning.lineSequence().flatMap { it.split('；', ';').asSequence() }
        .firstOrNull { it.isNotBlank() }?.trim()?.let { if (it.length > 120) it.take(120) + "…" else it }.orEmpty()
    fun hasMeaning(card: ReviewCard) = card.entry.meaning.isNotBlank() && !card.entry.meaning.startsWith("释义待补充")

    fun plan(cards: List<ReviewCard>, scope: ReviewScope, mode: ReviewMode, now: Long, limit: Int = 10, source: String = ""): List<ReviewTask> {
        val eligible = cards.filter { card ->
            !card.profile.paused && hasMeaning(card) && when (scope) {
                ReviewScope.DUE -> when (mode) {
                    ReviewMode.RECALL -> card.profile.meaning.due <= now
                    ReviewMode.SPELL, ReviewMode.CLOZE -> card.profile.spelling.due <= now
                    ReviewMode.MIXED -> card.profile.meaning.due <= now || card.profile.spelling.due <= now
                }
                ReviewScope.WEAK -> card.profile.needsWork
                ReviewScope.RECENT -> card.profile.created >= now - 7 * DAY
                ReviewScope.SOURCE -> source.isNotBlank() && card.contexts.any { it.source == source }
                ReviewScope.ALL -> true
            }
        }.sortedWith(compareBy<ReviewCard> { if (it.profile.meaning.level + it.profile.spelling.level == 0 && it.profile.errors == 0) 1 else 0 }
            .thenBy { minOf(it.profile.meaning.due, it.profile.spelling.due) }
            .thenByDescending { it.profile.errors }.thenByDescending { it.profile.created })
        return eligible.mapNotNull { card ->
            val p = card.profile
            val kind = when (mode) {
                ReviewMode.RECALL -> QuizKind.RECALL
                ReviewMode.SPELL -> QuizKind.SPELL
                ReviewMode.CLOZE -> if (card.clozeContext != null) QuizKind.CLOZE else return@mapNotNull null
                ReviewMode.MIXED -> if (p.meaning.level == 0 || p.meaning.due <= now && p.spelling.due > now) QuizKind.RECALL
                    else if (card.clozeContext != null && p.spelling.level < p.meaning.level) QuizKind.CLOZE
                    else if (p.spelling.due <= now || p.spelling.level < p.meaning.level) QuizKind.SPELL else QuizKind.RECALL
            }
            ReviewTask(card.entry.word, kind)
        }.take(limit)
    }
}

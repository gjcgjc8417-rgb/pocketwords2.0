package com.pocketwords.app

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.graphics.Bitmap
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

/** Vocabulary and learning records share one database, including the legacy migration. */
internal object ReviewStore {
    private class Database(context: Context) : SQLiteOpenHelper(context.applicationContext, "pocketwords_review.db", null, 3) {
        private fun createVocabulary(db: SQLiteDatabase) {
            db.execSQL("CREATE TABLE vocabulary (word_key TEXT PRIMARY KEY, word TEXT NOT NULL, meaning TEXT NOT NULL, position INTEGER NOT NULL)")
            db.execSQL("CREATE TABLE storage_meta (key TEXT PRIMARY KEY, value TEXT NOT NULL)")
        }
        override fun onCreate(db: SQLiteDatabase) {
            createVocabulary(db)
            db.execSQL("CREATE TABLE seen_records (word TEXT PRIMARY KEY, count INTEGER NOT NULL, last_seen INTEGER NOT NULL)")
            db.execSQL("CREATE TABLE profiles (word TEXT PRIMARY KEY, data TEXT NOT NULL)")
            db.execSQL("CREATE TABLE encounters (id INTEGER PRIMARY KEY, word TEXT NOT NULL, sentence TEXT NOT NULL, note TEXT NOT NULL, image TEXT NOT NULL, source TEXT NOT NULL, created INTEGER NOT NULL, pinned INTEGER NOT NULL DEFAULT 0)")
            db.execSQL("CREATE INDEX encounters_word ON encounters(word)")
            db.execSQL("CREATE TABLE events (id INTEGER PRIMARY KEY, word TEXT NOT NULL, day TEXT NOT NULL, skill TEXT NOT NULL, rating INTEGER NOT NULL)")
            db.execSQL("CREATE TABLE study_session (id INTEGER PRIMARY KEY, data TEXT NOT NULL)")
            db.execSQL("CREATE TABLE word_groups (id INTEGER PRIMARY KEY, title TEXT NOT NULL, note TEXT NOT NULL, words TEXT NOT NULL)")
        }
        override fun onUpgrade(db: SQLiteDatabase, old: Int, new: Int) {
            if (old < 2) {
                db.execSQL("CREATE TABLE seen_records (word TEXT PRIMARY KEY, count INTEGER NOT NULL, last_seen INTEGER NOT NULL)")
                db.execSQL("INSERT INTO seen_records SELECT word,COUNT(*),MAX(created) FROM encounters WHERE sentence='' AND image='' AND note='今天又遇到了' GROUP BY word")
                db.execSQL("DELETE FROM encounters WHERE sentence='' AND image='' AND note='今天又遇到了'")
                val upgraded=mutableListOf<ReviewProfile>()
                db.rawQuery("SELECT word,data FROM profiles",null).use { c ->
                    while (c.moveToNext()) {
                        val key=c.getString(0);val oldProfile=ReviewStore.profile(JSONObject(c.getString(1)))
                        fun migrated(skill: ReviewSkill, progress: SkillProgress): SkillProgress {
                            val rating=db.rawQuery("SELECT rating FROM events WHERE word=? AND skill=? ORDER BY id DESC LIMIT 1",arrayOf(key,skill.name)).use { if(it.moveToFirst()) it.getInt(0) else null }
                            return progress.copy(needsWork=rating?.let { it<2 } ?: progress.needsWork)
                        }
                        upgraded.add(oldProfile.copy(meaning=migrated(ReviewSkill.MEANING,oldProfile.meaning),spelling=migrated(ReviewSkill.SPELLING,oldProfile.spelling)))
                    }
                }
                upgraded.forEach { ReviewStore.put(db,it) }
            }
            if (old < 3) {
                createVocabulary(db)
                db.execSQL("ALTER TABLE encounters ADD COLUMN pinned INTEGER NOT NULL DEFAULT 0")
            }
        }
    }
    private val connection = ThreadLocal<SQLiteDatabase>()
    @Synchronized internal fun <T> access(context: Context, block: (SQLiteDatabase) -> T): T {
        connection.get()?.let { return block(it) }
        val helper = Database(context)
        try {
            val db = helper.writableDatabase
            connection.set(db)
            if (db.rawQuery("SELECT 1 FROM storage_meta WHERE key='legacy-imported'", null).use { !it.moveToFirst() }) {
                val legacy = WordStore.legacyEntries(context)
                db.beginTransaction()
                try {
                    replaceWords(db, legacy)
                    db.execSQL("INSERT INTO storage_meta VALUES('legacy-imported','1')")
                    db.setTransactionSuccessful()
                } finally { db.endTransaction() }
            }
            return block(db)
        } finally { connection.remove(); helper.close() }
    }
    fun <T> atomic(context: Context, block: () -> T): T = access(context) { db ->
        db.beginTransaction()
        try { val value = block(); db.setTransactionSuccessful(); value } finally { db.endTransaction() }
    }
    fun words(context: Context): List<WordEntry> = access(context) { db ->
        db.rawQuery("SELECT word,meaning FROM vocabulary ORDER BY position", null).use { c ->
            buildList { while (c.moveToNext()) add(WordEntry(c.getString(0), c.getString(1))) }
        }
    }
    private fun replaceWords(db: SQLiteDatabase, entries: List<WordEntry>) {
        db.execSQL("DELETE FROM vocabulary")
        entries.forEachIndexed { i, e -> db.execSQL("INSERT INTO vocabulary VALUES(?,?,?,?)", arrayOf(WordForms.key(e.word), e.word, e.meaning, i)) }
    }
    fun replaceWords(context: Context, entries: List<WordEntry>) = atomic(context) { access(context) { replaceWords(it, entries) } }
    private fun skillJson(s: SkillProgress) = JSONObject().put("level", s.level).put("due", s.due).put("day", s.goodDay).put("errors", s.errors).put("weak", s.needsWork)
    private fun skill(j: JSONObject?) = if (j == null) SkillProgress() else SkillProgress(j.optInt("level"), j.optLong("due"), j.optString("day"), j.optInt("errors"), j.optBoolean("weak", j.optInt("errors") > 0 && j.optInt("level") < 3))
    private fun profile(j: JSONObject) = ReviewProfile(j.getString("word"), skill(j.optJSONObject("meaning")), skill(j.optJSONObject("spelling")), j.optBoolean("paused"), j.optLong("created"), j.optString("phonetic"))
    private fun profileJson(p: ReviewProfile) = JSONObject().put("word", p.word).put("meaning", skillJson(p.meaning)).put("spelling", skillJson(p.spelling)).put("paused", p.paused).put("created", p.created).put("phonetic", p.phonetic)
    private fun get(db: SQLiteDatabase, word: String, now: Long): ReviewProfile = db.rawQuery("SELECT data FROM profiles WHERE word = ?", arrayOf(WordForms.key(word))).use {
        if (it.moveToFirst()) profile(JSONObject(it.getString(0))) else ReviewProfile(word, created = now)
    }
    private fun put(db: SQLiteDatabase, profile: ReviewProfile) {
        db.execSQL("INSERT OR REPLACE INTO profiles VALUES (?, ?)", arrayOf(WordForms.key(profile.word), profileJson(profile).toString()))
    }
    private fun contexts(db: SQLiteDatabase, word: String): List<ReadingContext> = db.rawQuery(
        "SELECT id,sentence,note,image,source,created,pinned FROM encounters WHERE word = ? ORDER BY pinned DESC,created DESC,id DESC", arrayOf(WordForms.key(word))
    ).use { cursor -> buildList {
        while (cursor.moveToNext()) add(ReadingContext(cursor.getLong(0), cursor.getString(1), cursor.getString(2), cursor.getString(3), cursor.getString(4), cursor.getLong(5), cursor.getInt(6) != 0))
    } }
    fun cards(context: Context, entries: List<WordEntry>, now: Long = System.currentTimeMillis(), details: Boolean = true): List<ReviewCard> = access(context) { db ->
        db.beginTransaction()
        try {
            val result = entries.mapIndexed { index, entry ->
                val p = get(db, entry.word, now - index)
                db.execSQL("INSERT OR IGNORE INTO profiles VALUES (?,?)", arrayOf(WordForms.key(p.word), profileJson(p).toString()))
                if (details) ReviewCard(entry, p, contexts(db, entry.word), p.phonetic.ifBlank { WordStore.lookupPhonetic(context, entry.word) }) else ReviewCard(entry, p)
            }
            db.setTransactionSuccessful(); result
        } finally { db.endTransaction() }
    }
    fun profile(context: Context, word: String): ReviewProfile = access(context) { get(it, word, System.currentTimeMillis()) }
    fun setPaused(context: Context, word: String, paused: Boolean) = access(context) { db -> put(db, get(db, word, System.currentTimeMillis()).copy(paused = paused)) }
    fun setPhonetic(context: Context, word: String, value: String) = access(context) { db -> put(db, get(db, word, System.currentTimeMillis()).copy(phonetic = value.trim())) }
    fun markSeen(context: Context, word: String) = access(context) { db ->
        val key = WordForms.key(word)
        db.execSQL("INSERT OR IGNORE INTO seen_records VALUES(?,0,0)", arrayOf(key))
        db.execSQL("UPDATE seen_records SET count=count+1,last_seen=? WHERE word=?", arrayOf(System.currentTimeMillis(), key))
    }
    fun seenCount(context: Context, word: String): Int = access(context) { db ->
        db.rawQuery("SELECT count FROM seen_records WHERE word=?", arrayOf(WordForms.key(word))).use { if (it.moveToFirst()) it.getInt(0) else 0 }
    }
    fun withContexts(context: Context, cards: List<ReviewCard>): List<ReviewCard> = access(context) { db ->
        val rows = mutableMapOf<String, MutableList<ReadingContext>>()
        db.rawQuery("SELECT word,id,sentence,note,image,source,created,pinned FROM encounters ORDER BY pinned DESC,created DESC,id DESC", null).use { c ->
            while (c.moveToNext()) rows.getOrPut(c.getString(0)) { mutableListOf() }.let { list ->
                list.add(ReadingContext(c.getLong(1),c.getString(2),c.getString(3),c.getString(4),c.getString(5),c.getLong(6),c.getInt(7) != 0))
            }
        }
        cards.map { it.copy(contexts = rows[WordForms.key(it.entry.word)].orEmpty()) }
    }
    fun hydrate(context: Context, cards: List<ReviewCard>): List<ReviewCard> = access(context) { db ->
        cards.map { card -> card.copy(contexts = contexts(db, card.entry.word),
            phonetic = card.profile.phonetic.ifBlank { WordStore.lookupPhonetic(context, card.entry.word) }) }
    }
    fun updateContext(context: Context, word: String, id: Long, sentence: String, note: String) = access(context) { db ->
        db.execSQL("UPDATE encounters SET sentence=?,note=? WHERE id=? AND word=?", arrayOf(sentence.trim(),note.trim(),id,WordForms.key(word)))
    }
    fun overview(context: Context, words: List<WordEntry>): Pair<Int, Int> = access(context) { db ->
        val now = System.currentTimeMillis()
        var due = 0; var mastered = 0
        db.beginTransaction()
        try {
            words.forEachIndexed { index, entry ->
                val p = get(db, entry.word, now - index); db.execSQL("INSERT OR IGNORE INTO profiles VALUES(?,?)", arrayOf(WordForms.key(p.word), profileJson(p).toString()))
                if (!p.paused && !entry.meaning.startsWith("释义待补充") && (p.meaning.due <= now || p.spelling.due <= now)) due++
                if (p.mastered) mastered++
            }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
        due to mastered
    }
    @Synchronized
    fun recordEncounter(context: Context, word: String, sentence: String, note: String, source: String, bitmap: Bitmap? = null) {
        if (sentence.isBlank() && note.isBlank() && source.isBlank() && bitmap == null) {
            access(context) { db -> put(db, get(db, word, System.currentTimeMillis())) }
            return
        }
        val filename = if (bitmap == null) "" else UUID.randomUUID().toString() + ".jpg"
        val image = filename.takeIf { it.isNotEmpty() }?.let { imageFile(context, it) }
        try {
            if (bitmap != null && image != null) {
                image.parentFile!!.mkdirs()
                image.outputStream().use { check(bitmap.compress(Bitmap.CompressFormat.JPEG, 90, it)) { "原图片段保存失败" } }
            }
            access(context) { db ->
                db.beginTransaction()
                try {
                    put(db, get(db, word, System.currentTimeMillis()))
                    val duplicate = db.rawQuery("SELECT id,image FROM encounters WHERE word=? AND sentence=? AND note=? LIMIT 1",
                        arrayOf(WordForms.key(word),sentence.trim(),note.trim())).use { if (it.moveToFirst()) it.getLong(0) to it.getString(1) else null }
                    if (duplicate == null) db.execSQL("INSERT INTO encounters(word,sentence,note,image,source,created) VALUES(?,?,?,?,?,?)", arrayOf(WordForms.key(word), sentence.trim().take(12000), note.trim().take(4000), filename, source, System.currentTimeMillis()))
                    else db.execSQL("UPDATE encounters SET image=?,source=?,created=? WHERE id=?", arrayOf(filename.ifEmpty { duplicate.second },source,System.currentTimeMillis(),duplicate.first))
                    db.setTransactionSuccessful()
                    // Image cleanup happens after the transaction commits, below.
                } finally { db.endTransaction() }
            }
            if (connection.get()?.inTransaction() != true) runCatching { cleanUnusedImages(context) }
        } catch (e: Exception) { image?.delete(); throw e }
    }
    private fun cleanUnusedImages(context: Context) = access(context) { db ->
        val used = db.rawQuery("SELECT image FROM encounters WHERE image != ''", null).use { c -> buildSet { while (c.moveToNext()) add(c.getString(0)) } }
        File(context.filesDir, "reading_contexts").listFiles()?.filter { it.name !in used }?.forEach { it.delete() }
    }
    fun imageFile(context: Context, name: String): File {
        require(name == File(name).name && name.endsWith(".jpg"))
        return File(File(context.filesDir, "reading_contexts"), name)
    }
    fun delete(context: Context, word: String) { atomic(context) { access(context) { db ->
        val key = WordForms.key(word)
        db.execSQL("DELETE FROM seen_records WHERE word = ?", arrayOf(key))
        db.execSQL("DELETE FROM profiles WHERE word = ?", arrayOf(key))
        db.execSQL("DELETE FROM encounters WHERE word = ?", arrayOf(key))
        db.execSQL("DELETE FROM events WHERE word = ?", arrayOf(key))
        groups(context).forEach { group ->
            val remaining = group.words.filterNot { WordForms.key(it) == key }
            if (remaining.size < 2) deleteGroup(context, group.id)
            else db.execSQL("UPDATE word_groups SET words=? WHERE id=?", arrayOf(JSONArray(remaining).toString(), group.id))
        }
    } }
        if (connection.get()?.inTransaction() != true) cleanUnusedImages(context)
    }
    fun cleanupImages(context: Context) = cleanUnusedImages(context)
    fun pinContext(context: Context, word: String, id: Long, pinned: Boolean) = access(context) {
        it.execSQL("UPDATE encounters SET pinned=? WHERE word=? AND id=?", arrayOf(if (pinned) 1 else 0, WordForms.key(word), id))
    }
    fun deleteContext(context: Context, word: String, id: Long) {
        access(context) { it.execSQL("DELETE FROM encounters WHERE word=? AND id=?", arrayOf(WordForms.key(word), id)) }
        cleanUnusedImages(context)
    }
    fun runJson(run: ReviewRun): JSONObject = JSONObject().put("tasks", JSONArray().apply {
        run.tasks.forEach { put(JSONObject().put("word", it.word).put("kind", it.kind.name).put("retry", it.retry)) }
    }).put("index", run.index).put("answered", run.answered).put("correct", run.correct).put("wrong", JSONArray(run.wrong.toList()))
        .put("retried", JSONArray(run.retried.toList())).put("elapsed", run.elapsed).put("short", run.short).put("id", run.id)
        .put("hinted", run.pendingHinted).put("revealed", run.pendingRevealed).put("typed", run.pendingTyped)
    private fun strings(arr: JSONArray) = (0 until arr.length()).map { arr.getString(it) }
    fun parseRun(j: JSONObject): ReviewRun {
        val tasks = j.getJSONArray("tasks")
        return ReviewRun((0 until tasks.length()).map { index -> tasks.getJSONObject(index).let {
            ReviewTask(it.getString("word"), QuizKind.valueOf(it.getString("kind")), it.optBoolean("retry"))
        } }.toMutableList(), j.getInt("index"), j.getInt("answered"), j.getInt("correct"),
            strings(j.getJSONArray("wrong")).toMutableSet(), strings(j.getJSONArray("retried")).toMutableSet(), j.getLong("elapsed"), j.getBoolean("short"), j.getString("id"),
            j.optBoolean("hinted"), j.optBoolean("revealed"), j.optString("typed"))
    }
    private fun saveRun(db: SQLiteDatabase, run: ReviewRun?) {
        if (run == null) db.execSQL("DELETE FROM study_session")
        else db.execSQL("INSERT OR REPLACE INTO study_session VALUES(1, ?)", arrayOf(runJson(run).toString()))
    }
    fun saveRun(context: Context, run: ReviewRun?, replace: Boolean = false) = access(context) { db ->
        val current = readRun(db)
        if (!replace && run != null && current != null && (current.id != run.id || current.index > run.index)) return@access
        saveRun(db, run)
    }
    private fun readRun(db: SQLiteDatabase): ReviewRun? = db.rawQuery("SELECT data FROM study_session WHERE id = 1", null).use {
        if (it.moveToFirst()) parseRun(JSONObject(it.getString(0))) else null
    }
    fun loadRun(context: Context): ReviewRun? = access(context) { db ->
        readRun(db)
    }
    fun answer(context: Context, run: ReviewRun, rating: Int, now: Long = System.currentTimeMillis()): Pair<ReviewRun, ReviewProfile> = access(context) { db ->
        val stored = readRun(db)
        check(stored?.id == run.id && stored.index == run.index) { "复习进度已更新，请关闭后从首页继续复习。" }
        val effectiveRating = if (run.pendingHinted || stored.pendingHinted) minOf(1, rating) else rating
        val copy = parseRun(runJson(run))
        val task = copy.tasks[copy.index]
        val p = get(db, task.word, now)
        val next = if (task.skill == ReviewSkill.MEANING) p.copy(meaning = ReviewEngine.advance(p.meaning, effectiveRating, now))
            else p.copy(spelling = ReviewEngine.advance(p.spelling, effectiveRating, now))
        copy.record(effectiveRating)
        db.beginTransaction()
        try {
            put(db, next)
            db.execSQL("INSERT INTO events(word,day,skill,rating) VALUES(?,?,?,?)", arrayOf(WordForms.key(task.word), ReviewEngine.day(now), task.skill.name, effectiveRating))
            saveRun(db, copy); db.setTransactionSuccessful()
        } finally { db.endTransaction() }
        copy to next
    }
    data class Daily(val day: String, val words: Int, val answers: Int, val meaningErrors: Int, val spellingErrors: Int)
    fun statistics(context: Context, now: Long = System.currentTimeMillis()): List<Daily> = access(context) { db ->
        db.rawQuery("SELECT day,COUNT(DISTINCT word),COUNT(*),SUM(CASE WHEN skill='MEANING' AND rating=0 THEN 1 ELSE 0 END),SUM(CASE WHEN skill='SPELLING' AND rating=0 THEN 1 ELSE 0 END) FROM events WHERE day >= ? GROUP BY day ORDER BY day DESC", arrayOf(ReviewEngine.day(now - 6 * ReviewEngine.DAY))).use { c ->
            buildList { while (c.moveToNext()) add(Daily(c.getString(0), c.getInt(1), c.getInt(2), c.getInt(3), c.getInt(4))) }
        }
    }
    data class Group(val id: Long, val title: String, val note: String, val words: List<String>)
    fun groups(context: Context): List<Group> = access(context) { db -> db.rawQuery("SELECT id,title,note,words FROM word_groups ORDER BY id DESC", null).use { c ->
        buildList { while (c.moveToNext()) add(Group(c.getLong(0), c.getString(1), c.getString(2), strings(JSONArray(c.getString(3))))) }
    } }
    fun saveGroup(context: Context, title: String, note: String, words: List<String>, id: Long? = null) = access(context) { db ->
        require(words.map(WordForms::key).distinct().size >= 2) { "请至少选择两个不同的词" }
        if (id == null) db.execSQL("INSERT INTO word_groups(title,note,words) VALUES(?,?,?)", arrayOf(title, note, JSONArray(words).toString()))
        else db.execSQL("UPDATE word_groups SET title=?,note=?,words=? WHERE id=?", arrayOf(title, note, JSONArray(words).toString(), id))
    }
    fun deleteGroup(context: Context, id: Long) = access(context) { it.execSQL("DELETE FROM word_groups WHERE id=?", arrayOf(id)) }
    private val tables = linkedMapOf(
        "profiles" to listOf("word","data"),
        "encounters" to listOf("id","word","sentence","note","image","source","created","pinned"),
        "events" to listOf("id","word","day","skill","rating"),
        "study_session" to listOf("id","data"),
        "word_groups" to listOf("id","title","note","words"),
        "seen_records" to listOf("word","count","last_seen")
    )
    fun <T> snapshot(context: Context, block: (JSONObject) -> T): T = access(context) { db ->
        val data = JSONObject()
        tables.forEach { (table, columns) ->
            val rows = JSONArray()
            db.rawQuery("SELECT ${columns.joinToString(",")} FROM $table", null).use { c ->
                while (c.moveToNext()) rows.put(JSONObject().apply {
                    columns.forEachIndexed { i, name -> put(name, if (c.getType(i) == android.database.Cursor.FIELD_TYPE_INTEGER) c.getLong(i) else c.getString(i)) }
                })
            }
            data.put(table, rows)
        }
        block(data)
    }
    fun validateSnapshot(data: JSONObject) {
        tables.forEach { (table, columns) ->
            val rows = data.getJSONArray(table)
            if (table == "encounters") for (i in 0 until rows.length()) {
                if (!rows.getJSONObject(i).has("pinned")) rows.getJSONObject(i).put("pinned", 0)
            }
            val primary = mutableSetOf<String>()
            for (i in 0 until rows.length()) {
                val row = rows.getJSONObject(i)
                columns.forEach { check(row.get(it) is String || row.get(it) is Number) { "备份字段不完整" } }
                check(primary.add(row.get(columns.first()).toString())) { "备份中存在重复记录" }
                when (table) {
                    "profiles" -> {
                        val p = profile(JSONObject(row.getString("data")))
                        check(WordForms.key(p.word) == row.getString("word"))
                        listOf(p.meaning, p.spelling).forEach { check(it.level in 0..6 && it.due >= 0 && it.errors >= 0) { "备份中的复习进度无效" } }
                    }
                    "study_session" -> parseRun(JSONObject(row.getString("data"))).let {
                        check(it.index in 0..it.tasks.size && it.answered >= 0 && it.correct in 0..it.answered && it.elapsed >= 0) { "备份中的续练进度无效" }
                    }
                    "word_groups" -> JSONArray(row.getString("words"))
                    "encounters" -> {
                        check(row.getInt("pinned") in 0..1)
                        if (row.getString("image").isNotEmpty()) check(row.getString("image").matches(Regex("[A-Za-z0-9-]+\\.jpg")))
                    }
                    "events" -> { check(row.getInt("rating") in 0..2); ReviewSkill.valueOf(row.getString("skill")) }
                    "seen_records" -> check(row.getLong("count") >= 0)
                }
            }
        }
    }
    fun restoreSnapshot(context: Context, data: JSONObject, words: List<WordEntry>) = access(context) { db ->
        validateSnapshot(data)
        db.beginTransaction()
        try {
            tables.forEach { (table, columns) ->
                db.execSQL("DELETE FROM $table")
                val rows = data.getJSONArray(table)
                for (i in 0 until rows.length()) {
                    val row = rows.getJSONObject(i)
                    db.execSQL("INSERT INTO $table (${columns.joinToString(",")}) VALUES (${columns.joinToString(",") { "?" }})", columns.map { row.get(it) }.toTypedArray())
                }
            }
            WordStore.replaceAll(context, words)
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

}

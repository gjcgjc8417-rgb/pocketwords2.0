package com.pocketwords.app

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.graphics.Bitmap
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

/** Review data is separate from the original vocabulary; no destructive migration is needed. */
internal object ReviewStore {
    private class Database(context: Context) : SQLiteOpenHelper(context.applicationContext, "pocketwords_review.db", null, 1) {
        override fun onCreate(db: SQLiteDatabase) {
            db.execSQL("CREATE TABLE profiles (word TEXT PRIMARY KEY, data TEXT NOT NULL)")
            db.execSQL("CREATE TABLE encounters (id INTEGER PRIMARY KEY, word TEXT NOT NULL, sentence TEXT NOT NULL, note TEXT NOT NULL, image TEXT NOT NULL, source TEXT NOT NULL, created INTEGER NOT NULL)")
            db.execSQL("CREATE INDEX encounters_word ON encounters(word)")
            db.execSQL("CREATE TABLE events (id INTEGER PRIMARY KEY, word TEXT NOT NULL, day TEXT NOT NULL, skill TEXT NOT NULL, rating INTEGER NOT NULL)")
            db.execSQL("CREATE TABLE study_session (id INTEGER PRIMARY KEY, data TEXT NOT NULL)")
            db.execSQL("CREATE TABLE word_groups (id INTEGER PRIMARY KEY, title TEXT NOT NULL, note TEXT NOT NULL, words TEXT NOT NULL)")
        }
        override fun onUpgrade(db: SQLiteDatabase, old: Int, new: Int) = Unit
    }
    @Synchronized private fun <T> access(context: Context, block: (SQLiteDatabase) -> T): T {
        val helper = Database(context)
        // SQLiteOpenHelper only implements AutoCloseable on newer Android versions.
        try { return block(helper.writableDatabase) } finally { helper.close() }
    }
    private fun skillJson(s: SkillProgress) = JSONObject().put("level", s.level).put("due", s.due).put("day", s.goodDay).put("errors", s.errors)
    private fun skill(j: JSONObject?) = if (j == null) SkillProgress() else SkillProgress(j.optInt("level"), j.optLong("due"), j.optString("day"), j.optInt("errors"))
    private fun profile(j: JSONObject) = ReviewProfile(j.getString("word"), skill(j.optJSONObject("meaning")), skill(j.optJSONObject("spelling")), j.optBoolean("paused"), j.optLong("created"), j.optString("phonetic"))
    private fun profileJson(p: ReviewProfile) = JSONObject().put("word", p.word).put("meaning", skillJson(p.meaning)).put("spelling", skillJson(p.spelling)).put("paused", p.paused).put("created", p.created).put("phonetic", p.phonetic)
    private fun get(db: SQLiteDatabase, word: String, now: Long): ReviewProfile = db.rawQuery("SELECT data FROM profiles WHERE word = ?", arrayOf(WordForms.key(word))).use {
        if (it.moveToFirst()) profile(JSONObject(it.getString(0))) else ReviewProfile(word, created = now)
    }
    private fun put(db: SQLiteDatabase, profile: ReviewProfile) {
        db.execSQL("INSERT OR REPLACE INTO profiles VALUES (?, ?)", arrayOf(WordForms.key(profile.word), profileJson(profile).toString()))
    }
    private fun contexts(db: SQLiteDatabase, word: String): List<ReadingContext> = db.rawQuery(
        "SELECT id,sentence,note,image,source,created FROM encounters WHERE word = ? ORDER BY created DESC,id DESC LIMIT 5", arrayOf(WordForms.key(word))
    ).use { cursor -> buildList {
        while (cursor.moveToNext()) add(ReadingContext(cursor.getLong(0), cursor.getString(1), cursor.getString(2), cursor.getString(3), cursor.getString(4), cursor.getLong(5)))
    } }
    fun cards(context: Context, entries: List<WordEntry>, now: Long = System.currentTimeMillis()): List<ReviewCard> = access(context) { db ->
        db.beginTransaction()
        try {
            val result = entries.mapIndexed { index, entry ->
                val p = get(db, entry.word, now - index)
                put(db, p)
                ReviewCard(entry, p, contexts(db, entry.word), p.phonetic.ifBlank { WordStore.lookupPhonetic(context, entry.word) })
            }
            db.setTransactionSuccessful(); result
        } finally { db.endTransaction() }
    }
    fun profile(context: Context, word: String): ReviewProfile = access(context) { get(it, word, System.currentTimeMillis()) }
    fun setPaused(context: Context, word: String, paused: Boolean) = access(context) { db -> put(db, get(db, word, System.currentTimeMillis()).copy(paused = paused)) }
    fun setPhonetic(context: Context, word: String, value: String) = access(context) { db -> put(db, get(db, word, System.currentTimeMillis()).copy(phonetic = value.trim())) }
    fun markSeen(context: Context, word: String) = recordEncounter(context, word, "", "今天又遇到了", "")
    fun overview(context: Context, words: List<WordEntry>): Pair<Int, Int> = access(context) { db ->
        val now = System.currentTimeMillis()
        var due = 0; var mastered = 0
        db.beginTransaction()
        try {
            words.forEachIndexed { index, entry ->
                val p = get(db, entry.word, now - index); put(db, p)
                if (!p.paused && !entry.meaning.startsWith("释义待补充") && (p.meaning.due <= now || p.spelling.due <= now)) due++
                if (p.mastered) mastered++
            }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
        due to mastered
    }
    @Synchronized
    fun recordEncounter(context: Context, word: String, sentence: String, note: String, source: String, bitmap: Bitmap? = null) {
        if (sentence.isBlank() && note.isBlank() && source.isBlank() && bitmap == null) {
            access(context) { db -> put(db, get(db, word, System.currentTimeMillis())) }
            return
        }
        val filename = if (bitmap == null) "" else UUID.randomUUID().toString() + ".jpg"
        val image = filename.takeIf { it.isNotEmpty() }?.let { imageFile(context, it) }
        try {
            if (bitmap != null && image != null) {
                image.parentFile!!.mkdirs()
                image.outputStream().use { check(bitmap.compress(Bitmap.CompressFormat.JPEG, 90, it)) { "原图片段保存失败" } }
            }
            access(context) { db ->
                db.beginTransaction()
                try {
                    put(db, get(db, word, System.currentTimeMillis()))
                    db.execSQL("INSERT INTO encounters(word,sentence,note,image,source,created) VALUES(?,?,?,?,?,?)", arrayOf(WordForms.key(word), sentence.trim().take(12000), note.trim().take(4000), filename, source, System.currentTimeMillis()))
                    // Keep at most five contexts per word and remove their old image files.
                    val old = db.rawQuery("SELECT id,image FROM encounters WHERE word = ? ORDER BY created DESC,id DESC LIMIT -1 OFFSET 5", arrayOf(WordForms.key(word))).use { c ->
                        buildList { while (c.moveToNext()) add(c.getLong(0) to c.getString(1)) }
                    }
                    old.forEach { (id, _) -> db.execSQL("DELETE FROM encounters WHERE id = ?", arrayOf(id)) }
                    db.setTransactionSuccessful()
                    // Image cleanup happens after the transaction commits, below.
                } finally { db.endTransaction() }
            }
            runCatching { cleanUnusedImages(context) }
        } catch (e: Exception) { image?.delete(); throw e }
    }
    private fun cleanUnusedImages(context: Context) = access(context) { db ->
        val used = db.rawQuery("SELECT image FROM encounters WHERE image != ''", null).use { c -> buildSet { while (c.moveToNext()) add(c.getString(0)) } }
        File(context.filesDir, "reading_contexts").listFiles()?.filter { it.name !in used }?.forEach { it.delete() }
    }
    fun imageFile(context: Context, name: String): File {
        require(name == File(name).name && name.endsWith(".jpg"))
        return File(File(context.filesDir, "reading_contexts"), name)
    }
    fun delete(context: Context, word: String) = access(context) { db ->
        val images = contexts(db, word).map { it.image }.filter { it.isNotBlank() }
        db.execSQL("DELETE FROM profiles WHERE word = ?", arrayOf(WordForms.key(word)))
        db.execSQL("DELETE FROM encounters WHERE word = ?", arrayOf(WordForms.key(word)))
        images.forEach { imageFile(context, it).delete() }
    }
    fun runJson(run: ReviewRun): JSONObject = JSONObject().put("tasks", JSONArray().apply {
        run.tasks.forEach { put(JSONObject().put("word", it.word).put("kind", it.kind.name).put("retry", it.retry)) }
    }).put("index", run.index).put("answered", run.answered).put("correct", run.correct).put("wrong", JSONArray(run.wrong.toList()))
        .put("retried", JSONArray(run.retried.toList())).put("elapsed", run.elapsed).put("short", run.short).put("id", run.id)
        .put("hinted", run.pendingHinted).put("revealed", run.pendingRevealed).put("typed", run.pendingTyped)
    private fun strings(arr: JSONArray) = (0 until arr.length()).map { arr.getString(it) }
    fun parseRun(j: JSONObject): ReviewRun {
        val tasks = j.getJSONArray("tasks")
        return ReviewRun((0 until tasks.length()).map { index -> tasks.getJSONObject(index).let {
            ReviewTask(it.getString("word"), QuizKind.valueOf(it.getString("kind")), it.optBoolean("retry"))
        } }.toMutableList(), j.getInt("index"), j.getInt("answered"), j.getInt("correct"),
            strings(j.getJSONArray("wrong")).toMutableSet(), strings(j.getJSONArray("retried")).toMutableSet(), j.getLong("elapsed"), j.getBoolean("short"), j.getString("id"),
            j.optBoolean("hinted"), j.optBoolean("revealed"), j.optString("typed"))
    }
    private fun saveRun(db: SQLiteDatabase, run: ReviewRun?) {
        if (run == null) db.execSQL("DELETE FROM study_session")
        else db.execSQL("INSERT OR REPLACE INTO study_session VALUES(1, ?)", arrayOf(runJson(run).toString()))
    }
    fun saveRun(context: Context, run: ReviewRun?, replace: Boolean = false) = access(context) { db ->
        val current = readRun(db)
        if (!replace && run != null && current != null && (current.id != run.id || current.index > run.index)) return@access
        saveRun(db, run)
    }
    private fun readRun(db: SQLiteDatabase): ReviewRun? = db.rawQuery("SELECT data FROM study_session WHERE id = 1", null).use {
        if (it.moveToFirst()) parseRun(JSONObject(it.getString(0))) else null
    }
    fun loadRun(context: Context): ReviewRun? = access(context) { db ->
        readRun(db)
    }
    fun answer(context: Context, run: ReviewRun, rating: Int, now: Long = System.currentTimeMillis()): Pair<ReviewRun, ReviewProfile> = access(context) { db ->
        val stored = readRun(db)
        check(stored?.id == run.id && stored.index == run.index) { "复习进度已更新，请关闭后从首页继续复习。" }
        val effectiveRating = if (run.pendingHinted || stored.pendingHinted) minOf(1, rating) else rating
        val copy = parseRun(runJson(run))
        val task = copy.tasks[copy.index]
        val p = get(db, task.word, now)
        val next = if (task.skill == ReviewSkill.MEANING) p.copy(meaning = ReviewEngine.advance(p.meaning, effectiveRating, now))
            else p.copy(spelling = ReviewEngine.advance(p.spelling, effectiveRating, now))
        copy.record(effectiveRating)
        db.beginTransaction()
        try {
            put(db, next)
            db.execSQL("INSERT INTO events(word,day,skill,rating) VALUES(?,?,?,?)", arrayOf(WordForms.key(task.word), ReviewEngine.day(now), task.skill.name, effectiveRating))
            saveRun(db, copy); db.setTransactionSuccessful()
        } finally { db.endTransaction() }
        copy to next
    }
    data class Daily(val day: String, val words: Int, val answers: Int, val meaningErrors: Int, val spellingErrors: Int)
    fun statistics(context: Context, now: Long = System.currentTimeMillis()): List<Daily> = access(context) { db ->
        db.rawQuery("SELECT day,COUNT(DISTINCT word),COUNT(*),SUM(CASE WHEN skill='MEANING' AND rating=0 THEN 1 ELSE 0 END),SUM(CASE WHEN skill='SPELLING' AND rating=0 THEN 1 ELSE 0 END) FROM events WHERE day >= ? GROUP BY day ORDER BY day DESC", arrayOf(ReviewEngine.day(now - 6 * ReviewEngine.DAY))).use { c ->
            buildList { while (c.moveToNext()) add(Daily(c.getString(0), c.getInt(1), c.getInt(2), c.getInt(3), c.getInt(4))) }
        }
    }
    data class Group(val id: Long, val title: String, val note: String, val words: List<String>)
    fun groups(context: Context): List<Group> = access(context) { db -> db.rawQuery("SELECT id,title,note,words FROM word_groups ORDER BY id DESC", null).use { c ->
        buildList { while (c.moveToNext()) add(Group(c.getLong(0), c.getString(1), c.getString(2), strings(JSONArray(c.getString(3))))) }
    } }
    fun saveGroup(context: Context, title: String, note: String, words: List<String>, id: Long? = null) = access(context) { db ->
        require(words.map(WordForms::key).distinct().size >= 2) { "请至少选择两个不同的词" }
        if (id == null) db.execSQL("INSERT INTO word_groups(title,note,words) VALUES(?,?,?)", arrayOf(title, note, JSONArray(words).toString()))
        else db.execSQL("UPDATE word_groups SET title=?,note=?,words=? WHERE id=?", arrayOf(title, note, JSONArray(words).toString(), id))
    }
    fun deleteGroup(context: Context, id: Long) = access(context) { it.execSQL("DELETE FROM word_groups WHERE id=?", arrayOf(id)) }
}

package com.pocketwords.app

import java.io.Reader
import java.io.Writer

/** UTF-8 CSV: quoted commas, double quotes and embedded newlines round-trip. */
object WordCsv {
    const val MAX_ENTRIES = 10000
    const val MAX_CHARS = 5 * 1024 * 1024

    fun write(entries: List<WordEntry>, output: Writer) {
        output.write("\uFEFFword,meaning\r\n")
        for (entry in entries) {
            fun quote(value: String) = "\"" + value.replace("\"", "\"\"") + "\""
            output.write("${quote(entry.word)},${quote(entry.meaning)}\r\n")
        }
    }

    fun read(input: Reader): List<WordEntry> {
        val text = StringBuilder()
        val buffer = CharArray(4096)
        while (true) {
            val count = input.read(buffer)
            if (count < 0) break
            require(text.length + count <= MAX_CHARS) { "文件太大，请导入不超过 5 MB 的 CSV。" }
            text.append(buffer, 0, count)
        }
        val source = text.toString().removePrefix("\uFEFF")
        val rows = mutableListOf<List<String>>()
        var row = mutableListOf<String>()
        val field = StringBuilder()
        var quoted = false
        var closedQuote = false
        var index = 0
        fun endField() { row.add(field.toString()); field.setLength(0); closedQuote = false }
        fun endRow() {
            endField()
            if (row.any { it.isNotBlank() }) rows.add(row.toList())
            require(rows.size <= MAX_ENTRIES + 1) { "最多导入 10000 个单词。" }
            row = mutableListOf()
        }
        while (index < source.length) {
            val c = source[index++]
            if (quoted) {
                if (c == '"') {
                    if (index < source.length && source[index] == '"') { field.append('"'); index++ }
                    else { quoted = false; closedQuote = true }
                } else field.append(c)
            } else when (c) {
                '"' -> { require(field.isEmpty() && !closedQuote) { "CSV 引号格式错误。" }; quoted = true }
                ',' -> endField()
                '\r', '\n' -> {
                    if (c == '\r' && index < source.length && source[index] == '\n') index++
                    endRow()
                }
                else -> { require(!closedQuote) { "CSV 引号后应为逗号或换行。" }; field.append(c) }
            }
        }
        require(!quoted) { "CSV 引号未闭合。" }
        if (field.isNotEmpty() || row.isNotEmpty() || closedQuote) endRow()
        require(rows.isNotEmpty() && rows.first().map { it.trim().lowercase(java.util.Locale.ROOT) } == listOf("word", "meaning")) {
            "CSV 第一行必须为 word,meaning。"
        }
        return rows.drop(1).mapIndexed { i, cells ->
            require(cells.size == 2 && WordForms.clean(cells[0]).isNotBlank()) { "第 ${i + 2} 行需要单词和释义两列。" }
            require(cells[0].length <= 500 && cells[1].length <= 20000) { "第 ${i + 2} 行内容过长。" }
            WordEntry(WordForms.clean(cells[0]), cells[1].trim())
        }
    }
}

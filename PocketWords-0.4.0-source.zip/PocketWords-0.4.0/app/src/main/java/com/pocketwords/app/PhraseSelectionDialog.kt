package com.pocketwords.app

import android.app.Activity
import android.app.AlertDialog
import android.widget.Toast

internal object PhraseSelectionDialog {
    fun phrase(words: List<WordBox>, indexes: List<Int>): Pair<String, String> {
        require(indexes.size in 2..12) { "请选择 2–12 个相邻的词" }
        val sorted = indexes.sorted()
        require(sorted.distinct().size == sorted.size && sorted.zipWithNext().all { (a,b) -> b == a + 1 }) { "请选择连续相邻的词，避免漏词" }
        require(sorted.all { it in words.indices })
        val selected = sorted.map { words[it] }
        val phrase = selected.joinToString(" ") { WordForms.clean(it.text) }.trim()
        require(phrase.isNotBlank())
        return phrase to OcrText.merge(selected.map { it.context }.filter { it.isNotBlank() }.distinct().joinToString("\n"))
    }
    fun show(activity: Activity, words: List<WordBox>, selected: (String, String) -> Unit): AlertDialog {
        val checked = BooleanArray(words.size)
        val dialog = AlertDialog.Builder(activity).setTitle("选择相邻词组成短语（2–12 词）")
            .setMultiChoiceItems(words.map { it.text }.toTypedArray(), checked) { _, index, value -> checked[index] = value }
            .setNegativeButton("取消", null).setPositiveButton("查询短语", null).create()
        dialog.show()
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            try {
                val (phrase, context) = phrase(words, checked.indices.filter { checked[it] })
                dialog.dismiss(); selected(phrase, context)
            } catch (e: IllegalArgumentException) { Toast.makeText(activity, e.message, Toast.LENGTH_SHORT).show() }
        }
        return dialog
    }
}

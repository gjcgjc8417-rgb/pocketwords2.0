package com.pocketwords.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URI
import java.net.URL
import java.net.URLEncoder
import java.security.MessageDigest

internal data class AudioClip(val file: File, val source: String, val sourceUrl: String, val license: String = "", val licenseUrl: String = "")
internal data class Recording(val url: String, val sourceUrl: String, val license: String, val licenseUrl: String)

/** Fetch only the requested English text. No screenshot, reading context or notebook is uploaded. */
internal class PronunciationAudio(
    private val context: Context,
    private val fetch: (String, Int) -> ByteArray = ::download
) {
    companion object {
        private const val USER_AGENT = "PocketWords/0.9.1 (English learning application)"
        private val hosts = setOf("api.dictionaryapi.dev", "upload.wikimedia.org", "dict.youdao.com")
        fun allowed(url: String): Boolean = runCatching {
            val uri = URI(url)
            uri.scheme == "https" && uri.host in hosts && uri.userInfo == null && uri.port in listOf(-1, 443)
        }.getOrDefault(false)
        private fun download(url: String, limit: Int): ByteArray {
            require(allowed(url)) { "发音来源地址不受支持" }
            val connection = URL(url).openConnection() as HttpURLConnection
            connection.connectTimeout = 4500; connection.readTimeout = 6000
            connection.instanceFollowRedirects = false
            connection.setRequestProperty("User-Agent", USER_AGENT)
            try {
                check(connection.responseCode == 200) { "暂时无法取得词典发音" }
                check(connection.contentLengthLong <= limit) { "发音文件过大" }
                return connection.inputStream.use { input ->
                    val result = java.io.ByteArrayOutputStream()
                    val buffer = ByteArray(8192)
                    while (true) {
                        val count = input.read(buffer); if (count < 0) break
                        check(result.size() + count <= limit) { "发音文件过大" }
                        result.write(buffer, 0, count)
                    }
                    result.toByteArray().also { check(it.isNotEmpty()) { "发音文件为空" } }
                }
            } finally { connection.disconnect() }
        }
        fun recordings(json: String, accent: String): List<Recording> {
            val rows = JSONArray(json)
            val result = mutableListOf<Recording>()
            for (i in 0 until rows.length()) {
                val phonetics = rows.getJSONObject(i).optJSONArray("phonetics") ?: continue
                for (j in 0 until phonetics.length()) {
                    val p = phonetics.getJSONObject(j)
                    val url = p.optString("audio")
                    val license = p.optJSONObject("license")
                    if (allowed(url) && p.optString("sourceUrl").startsWith("https://")) result.add(
                        Recording(url, p.optString("sourceUrl"), license?.optString("name").orEmpty(), license?.optString("url").orEmpty()))
                }
            }
            return result.distinctBy { it.url }.sortedBy {
                val url = it.url.lowercase()
                when { url.contains("-$accent") || url.contains("en-$accent") -> 0
                    url.contains("-us") || url.contains("-uk") -> 1
                    else -> 2 }
            }
        }
    }
    fun load(text: String, accent: String, cancelled: () -> Boolean): AudioClip? {
        val word = WordForms.clean(text)
        if (word.isBlank() || word.length > 200 || cancelled()) return null
        val directory = File(context.cacheDir, "pronunciation").apply { mkdirs() }
        val key = MessageDigest.getInstance("SHA-256").digest((WordForms.key(word) + ":" + accent).toByteArray()).joinToString("") { "%02x".format(it) }
        val audio = File(directory, "$key.mp3")
        val info = File(directory, "$key.json")
        if (audio.isFile && audio.length() > 0 && info.isFile) runCatching {
            val j = JSONObject(info.readText())
            audio.setLastModified(System.currentTimeMillis())
            return AudioClip(audio, j.getString("source"), j.getString("url"), j.optString("license"), j.optString("licenseUrl"))
        }
        fun save(bytes: ByteArray, source: String, sourceUrl: String, license: String = "", licenseUrl: String = ""): AudioClip? {
            if (cancelled()) return null
            val temporary = File.createTempFile("voice-", ".part", directory)
            try {
                temporary.writeBytes(bytes)
                check(temporary.renameTo(audio))
                info.writeText(JSONObject().put("source", source).put("url", sourceUrl).put("license", license).put("licenseUrl", licenseUrl).toString())
                prune(directory, audio.name)
                return AudioClip(audio, source, sourceUrl, license, licenseUrl)
            } finally { temporary.delete() }
        }
        if (word.matches(Regex("[A-Za-z]+(?:[-'][A-Za-z]+)*"))) {
            val list = runCatching {
                val encoded = URLEncoder.encode(word.lowercase(java.util.Locale.ROOT), "UTF-8")
                recordings(fetch("https://api.dictionaryapi.dev/api/v2/entries/en/$encoded", 512 * 1024).toString(Charsets.UTF_8), accent)
            }.getOrDefault(emptyList())
            for (recording in list.take(2)) {
                if (cancelled()) return null
                val bytes = runCatching { fetch(recording.url, 2 * 1024 * 1024) }.getOrNull() ?: continue
                return save(bytes, "词典录音 · Free Dictionary / Wikimedia", recording.sourceUrl, recording.license, recording.licenseUrl)
            }
        }
        if (cancelled()) return null
        val url = "https://dict.youdao.com/dictvoice?audio=${URLEncoder.encode(word, "UTF-8")}&type=${if (accent == "uk") 1 else 2}"
        val bytes = runCatching { fetch(url, 2 * 1024 * 1024) }.getOrNull() ?: return null
        return save(bytes, "有道词典音频（部分词条或短语为合成语音）", "https://dict.youdao.com/")
    }
    private fun prune(directory: File, keep: String) {
        val files = directory.listFiles()?.filter { it.extension == "mp3" }?.sortedBy { it.lastModified() }.orEmpty()
        var total = files.sumOf { it.length() }
        for (file in files) {
            if (total <= 32L * 1024 * 1024) break
            if (file.name == keep) continue
            total -= file.length(); file.delete(); File(directory, file.nameWithoutExtension + ".json").delete()
        }
        directory.listFiles()?.filter { it.extension == "part" && System.currentTimeMillis() - it.lastModified() > 86_400_000 }?.forEach { it.delete() }
    }
}

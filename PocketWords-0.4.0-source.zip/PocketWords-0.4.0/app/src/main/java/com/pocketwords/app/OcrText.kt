package com.pocketwords.app

/** Join wrapped English lines while retaining explicit paragraph breaks. */
internal object OcrText {
    fun merge(text: String): String = text.replace("\r\n", "\n").replace('\r', '\n')
        .split(Regex("""\n[ \t]*\n+"""))
        .map { paragraph ->
            paragraph.lineSequence().map { it.trim() }.filter { it.isNotEmpty() }
                .fold("") { result, line ->
                    when {
                        result.isEmpty() -> line
                        result.last() == '\u00ad' -> result.dropLast(1) + line
                        result.last() == '-' -> result + line
                        else -> "$result $line"
                    }
                }
        }.filter { it.isNotEmpty() }.joinToString("\n\n")
}

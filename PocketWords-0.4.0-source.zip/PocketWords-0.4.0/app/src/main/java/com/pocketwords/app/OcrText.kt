package com.pocketwords.app

/** Join wrapped English lines while retaining explicit paragraph breaks. */
internal object OcrText {
    fun merge(text: String): String = text.replace("\r\n", "\n").replace('\r', '\n')
        .split(Regex("""\n[ \t]*\n+"""))
        .map { paragraph ->
            paragraph.lineSequence().map { it.trim() }.filter { it.isNotEmpty() }
                .fold("") { result, line ->
                    when {
                        result.isEmpty() -> line
                        result.last() == '-' && result.dropLast(1).lastOrNull()?.isLetter() == true &&
                            line.first().isLowerCase() -> result.dropLast(1) + line
                        else -> "$result $line"
                    }
                }
        }.filter { it.isNotEmpty() }.joinToString("\n\n")
}

package com.pocketwords.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.Closeable
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/** Portable user data only: the offline dictionary and temporary captures are rebuildable. */
internal object FullBackup {
    private const val FORMAT = "PocketWords-backup"
    private const val MAX_JSON = 32L * 1024 * 1024
    private const val MAX_BYTES = 1024L * 1024 * 1024
    data class Prepared(val directory: File, val words: List<WordEntry>, val review: JSONObject, val missingImages: Int = 0) : Closeable {
        override fun close() { directory.deleteRecursively() }
    }
    private fun envelope(context: Context, review: JSONObject) = JSONObject().put("format", FORMAT).put("version", 2).put("created", System.currentTimeMillis()).put("appVersion", "0.9.1")
        .put("words", JSONArray().apply { WordStore.allEntries(context).forEach { put(JSONObject().put("word", it.word).put("meaning", it.meaning)) } })
        .put("review", review)
    private fun images(review: JSONObject): Set<String> {
        val rows = review.getJSONArray("encounters")
        return (0 until rows.length()).map { rows.getJSONObject(it).getString("image") }.filter { it.isNotEmpty() }.toSet()
    }
    @Synchronized fun write(context: Context, output: OutputStream, rescue: Boolean = false, progress: (String) -> Unit = {}) = ReviewStore.snapshot(context) { original ->
        val review = JSONObject(original.toString())
        val missing = images(review).filter { !ReviewStore.imageFile(context, it).isFile }.toSet()
        check(rescue || missing.isEmpty()) { "有原图片段缺失。可在备份页选择救援备份，保留其余学习资料。" }
        if (rescue) {
            val rows = review.getJSONArray("encounters")
            for (i in 0 until rows.length()) rows.getJSONObject(i).let { row ->
                if (row.getString("image") in missing) row.put("image", "")
            }
        }
        val root = envelope(context, review).put("missingImages", missing.size).put("rescue", rescue)
        val json = root.toString().toByteArray(Charsets.UTF_8)
        check(json.size <= MAX_JSON) { "学习资料过大，无法生成单个备份" }
        val files = images(review).map { ReviewStore.imageFile(context, it) }
        check(files.sumOf { it.length() } + json.size <= MAX_BYTES) { "资料超过 1 GB 备份上限" }
        ZipOutputStream(output).use { zip ->
            progress("正在保存单词与学习记录…")
            zip.putNextEntry(ZipEntry("data.json")); zip.write(json); zip.closeEntry()
            files.forEachIndexed { index, file ->
                progress("正在保存图片 ${index + 1} / ${files.size}")
                zip.putNextEntry(ZipEntry("images/${file.name}")); file.inputStream().use { it.copyTo(zip) }; zip.closeEntry()
            }
        }
    }
    fun read(context: Context, input: InputStream, progress: (String) -> Unit = {}): Prepared {
        val dir = File(context.cacheDir, "restore-${UUID.randomUUID()}").apply { check(mkdirs()) }
        File(dir, "images").mkdirs()
        try {
            var total = 0L
            val names = mutableSetOf<String>()
            ZipInputStream(input).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    val name = entry.name
                    check(!entry.isDirectory && (name == "data.json" || name.matches(Regex("images/[A-Za-z0-9-]+\\.jpg")))) { "备份包含无法识别的文件" }
                    check(names.add(name) && names.size <= 100001) { "备份文件重复或过多" }
                    val target = File(dir, name)
                    var size = 0L
                    target.outputStream().use { out ->
                        val buffer = ByteArray(32768)
                        while (true) {
                            val n = zip.read(buffer); if (n < 0) break
                            size += n; total += n
                            check(total <= MAX_BYTES && (name != "data.json" || size <= MAX_JSON)) { "备份超过支持的大小" }
                            out.write(buffer, 0, n)
                        }
                    }
                    progress("已读取 ${names.size} 个文件 · ${total / 1024} KB")
                    zip.closeEntry(); entry = zip.nextEntry
                }
            }
            val root = JSONObject(File(dir, "data.json").readText())
            check(root.getString("format") == FORMAT && root.getInt("version") in 1..2) { "备份版本不支持" }
            val arr = root.getJSONArray("words")
            val words = (0 until arr.length()).map { arr.getJSONObject(it).let { WordEntry(it.getString("word"), it.getString("meaning")) } }
            check(words.all { it.word.isNotBlank() } && words.map { WordForms.key(it.word) }.distinct().size == words.size) { "词表存在空词或重复词" }
            val review = root.getJSONObject("review")
            ReviewStore.validateSnapshot(review)
            check(images(review).map { "images/$it" }.toSet() == names.filter { it.startsWith("images/") }.toSet()) { "原图文件不完整" }
            return Prepared(dir, words, review, root.optInt("missingImages"))
        } catch (e: Exception) { dir.deleteRecursively(); throw IllegalArgumentException("无法读取完整备份：${e.message}", e) }
    }
    private fun durable(file: File, text: String) {
        FileOutputStream(file).use { it.write(text.toByteArray(Charsets.UTF_8)); it.fd.sync() }
    }
    /** A small on-disk journal makes replacement recoverable even if the process stops midway. */
    @Synchronized fun restore(context: Context, prepared: Prepared) {
        recover(context)
        val journal = File(context.noBackupFilesDir, "restore-journal")
        val currentImages = File(context.filesDir, "reading_contexts")
        ReviewStore.snapshot(context) { old ->
            check(journal.mkdirs())
            val previous = envelope(context, old).put("hadImages", currentImages.exists())
            durable(File(journal, "previous.json"), previous.toString())
            durable(File(journal, "ready"), "1")
            try {
                if (currentImages.exists()) check(currentImages.renameTo(File(journal, "previous_images"))) { "无法暂存原图片段" }
                check(File(prepared.directory, "images").renameTo(currentImages)) { "无法恢复原图片段" }
                // Invalidate callbacks from a previous in-memory review screen.
                val session = prepared.review.getJSONArray("study_session")
                for (i in 0 until session.length()) {
                    val row = session.getJSONObject(i)
                    val run = ReviewStore.parseRun(JSONObject(row.getString("data")))
                    row.put("data", ReviewStore.runJson(run.copy(id = UUID.randomUUID().toString())).toString())
                }
                ReviewStore.restoreSnapshot(context, prepared.review, prepared.words)
                durable(File(journal, "committed"), "1")
                journal.deleteRecursively()
            } catch (e: Exception) { recover(context); throw e }
        }
    }
    @Synchronized fun recover(context: Context) {
        val journal = File(context.noBackupFilesDir, "restore-journal")
        if (!journal.exists()) return
        if (File(journal, "committed").exists() || !File(journal, "ready").exists()) { journal.deleteRecursively(); return }
        val previous = JSONObject(File(journal, "previous.json").readText())
        val oldImages = File(journal, "previous_images")
        val current = File(context.filesDir, "reading_contexts")
        if (oldImages.exists()) { current.deleteRecursively(); check(oldImages.renameTo(current)) }
        else if (!previous.getBoolean("hadImages")) current.deleteRecursively()
        val words = previous.getJSONArray("words").let { a -> (0 until a.length()).map { a.getJSONObject(it).let { WordEntry(it.getString("word"), it.getString("meaning")) } } }
        ReviewStore.restoreSnapshot(context, previous.getJSONObject("review"), words)
        journal.deleteRecursively()
    }
}

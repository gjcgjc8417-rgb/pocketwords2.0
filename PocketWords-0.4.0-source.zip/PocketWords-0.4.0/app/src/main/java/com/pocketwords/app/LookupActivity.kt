package com.pocketwords.app

import android.app.Activity
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.ExifInterface
import android.media.projection.MediaProjectionManager
import android.graphics.Bitmap
import android.graphics.RectF
import android.graphics.Matrix
import android.graphics.BitmapFactory
import org.json.JSONArray
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.provider.MediaStore
import java.io.File
import java.io.FileOutputStream
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.JSONObject
import android.view.Gravity
import android.view.View
import android.widget.BaseAdapter
import android.widget.ListView
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.text.Editable
import android.text.TextWatcher
import java.util.concurrent.Executors
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.PopupMenu
import android.widget.ScrollView
import android.view.WindowManager
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.content.ContextCompat

open class LookupActivity : Activity() {
    protected val io = Executors.newSingleThreadExecutor()
    protected val mainHandler = Handler(Looper.getMainLooper())
    private var photoLookupUri: Uri? = null
    private var photoBusy = false
    private val sentenceDialogs = mutableSetOf<SentenceTranslationDialog>()
    private val lookupDialogs = mutableSetOf<AlertDialog>()
    private var restartingScreenCapture = false
    protected val isScreenLookup get() = this is ScreenLookupActivity
    private enum class ImageSource { PHOTO, SCREEN }
    protected var restorationReady = true
        private set
    protected open fun onWordsChanged() = Unit
    private fun lookupDismissed(dialog: AlertDialog) {
        lookupDialogs.remove(dialog)
        mainHandler.post { finishScreenLookupIfIdle() }
    }
    private fun finishScreenLookupIfIdle() {
        if (isScreenLookup && !isFinishing && !isDestroyed && !isChangingConfigurations && !restartingScreenCapture && !photoBusy && lookupDialogs.isEmpty() && sentenceDialogs.isEmpty()) finish()
    }
    protected fun <T> background(work: () -> T, discard: (T) -> Unit = {}, failed: () -> Unit = {}, done: (T) -> Unit) {
        if (io.isShutdown) return
        io.execute {
            val result = runCatching(work)
            mainHandler.post {
                if (isFinishing || isDestroyed) result.onSuccess(discard)
                else result.fold(done) {
                    failed()
                    Toast.makeText(this, it.message ?: "操作失败，请重试。", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val recovery=runCatching { FullBackup.recover(applicationContext) }
        if (recovery.isFailure) {
            restorationReady=false
            AlertDialog.Builder(this).setTitle("资料恢复尚未完成").setMessage("原资料已保留。请释放可用空间后重新打开应用重试，暂时不要清除应用数据。")
                .setCancelable(false).setPositiveButton("关闭") { _,_ -> finish() }.show()
            return
        }
        photoLookupUri = savedInstanceState?.getString(KEY_PHOTO_LOOKUP_URI)?.let { Uri.parse(it) }
        if (isScreenLookup) {
            setContentView(FrameLayout(this).apply { setBackgroundColor(android.graphics.Color.TRANSPARENT) })
            handleIntent(intent)
        }
    }
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        photoLookupUri?.let { outState.putString(KEY_PHOTO_LOOKUP_URI, it.toString()) }
    }

    override fun onDestroy() {
        sentenceDialogs.toList().forEach { it.dismiss() }
        lookupDialogs.toList().forEach { it.dismiss() }
        io.shutdown()
        super.onDestroy()
    }
    protected fun column() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    protected fun lp(top: Int = 0) = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(top) }

    protected fun dp(value: Int) = BrandUi.dp(this, value)
    private fun handleIntent(intent: Intent?) {
        if (isScreenLookup && intent?.action == CaptureService.ACTION_OCR_RESULT) {
            showWordSelection(intent.getStringExtra(CaptureService.EXTRA_TEXT).orEmpty(), intent.getStringExtra(CaptureService.EXTRA_IMAGE_PATH).orEmpty(),
                intent.getStringExtra(CaptureService.EXTRA_WORD_BOXES).orEmpty(), intent.getIntExtra(CaptureService.EXTRA_IMAGE_WIDTH, 0), intent.getIntExtra(CaptureService.EXTRA_IMAGE_HEIGHT, 0))
            finishScreenLookupIfIdle()
        } else if (intent?.action == OverlayService.ACTION_CAPTURE) {
            restartingScreenCapture = true
            if (isScreenLookup) finish() else moveTaskToBack(true)
            ScreenCaptureFlow.request(this)
        }
    }

    @Deprecated("Activity results")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CAMERA && resultCode == RESULT_OK) {
            val uri = photoLookupUri
            val thumbnail: Bitmap? = data?.let {
                if (Build.VERSION.SDK_INT >= 33) it.getParcelableExtra("data", Bitmap::class.java)
                else @Suppress("DEPRECATION") it.getParcelableExtra("data")
            }
            photoBusy = true
            background({ OriginalPhoto.load(applicationContext,uri,thumbnail) }, discard = { it.first?.recycle() }, failed = { photoBusy = false }) { (bitmap, original) ->
                photoBusy = false
                if (bitmap != null) recognizePhoto(bitmap, original = original)
                else Toast.makeText(this, "没有取得照片，请重试。", Toast.LENGTH_SHORT).show()
            }
        }
    }
    protected fun takePhotoForLookup() {
        if (photoBusy) return
        val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        if (cameraIntent.resolveActivity(packageManager) == null) {
            Toast.makeText(this, "没有找到可用的相机应用。", Toast.LENGTH_LONG).show()
            return
        }
        // Ask the camera app to write a full-size photo to our cache file.
        // Without EXTRA_OUTPUT, most camera apps only return a small
        // thumbnail in "data", which is the old clarity problem.
        try {
            val photoFile = File(cacheDir, "pocketwords-photo-lookup.jpg")
            if (photoFile.exists()) photoFile.delete()
            val outputUri = androidx.core.content.FileProvider.getUriForFile(
                this, "$packageName.fileprovider", photoFile
            )
            photoLookupUri = outputUri
            cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, outputUri)
            cameraIntent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        } catch (_: Exception) {
            // Fall back to the thumbnail path if FileProvider setup fails.
            photoLookupUri = null
        }
        try { startActivityForResult(cameraIntent, REQUEST_CAMERA) }
        catch (_: Exception) { Toast.makeText(this, "无法打开相机，请稍后重试。", Toast.LENGTH_LONG).show() }
    }

    private fun scaleBitmapForOcr(bitmap: Bitmap): Bitmap {
        val maxSide = maxOf(bitmap.width, bitmap.height)
        if (maxSide <= PHOTO_MAX_SIDE) return bitmap
        val scale = PHOTO_MAX_SIDE.toFloat() / maxSide.toFloat()
        return Bitmap.createScaledBitmap(
            bitmap, (bitmap.width * scale).toInt(), (bitmap.height * scale).toInt(), true
        )
    }

    private fun recognizePhoto(inputBitmap: Bitmap, source: ImageSource = ImageSource.PHOTO, forTranslation: Boolean = false, original: OriginalPhoto? = null, photoArea: RectF = RectF(0f,0f,1f,1f)) {
        if (photoBusy) { inputBitmap.recycle(); return }
        photoBusy = true
        Toast.makeText(this, "正在识别英文…", Toast.LENGTH_SHORT).show()
        background({
            try {
                val bitmap = scaleBitmapForOcr(inputBitmap)
                if (bitmap !== inputBitmap) inputBitmap.recycle()
                val imageFile = File.createTempFile("lookup-", ".png", cacheDir)
                try {
                    FileOutputStream(imageFile).use { check(bitmap.compress(Bitmap.CompressFormat.PNG, 100, it)) }
                } catch (e: Exception) { bitmap.recycle(); imageFile.delete(); throw e }
                bitmap to imageFile
            } catch (e: Exception) {
                mainHandler.post { photoBusy = false }
                throw e
            }
        }, discard = { (bitmap, imageFile) -> bitmap.recycle(); imageFile.delete() }, failed = {
            photoBusy = false; finishScreenLookupIfIdle()
        }) { (bitmap, imageFile) ->
            val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            recognizer.process(InputImage.fromBitmap(bitmap, 0))
                .addOnSuccessListener { result ->
                    if (isFinishing || isDestroyed) return@addOnSuccessListener
                    val recognizedText = result.textBlocks.joinToString("\n\n") { it.text }
                    val boxes = JSONArray()
                    result.textBlocks.forEachIndexed { blockIndex, block ->
                        var contextWritten = false
                        block.lines.forEach { line ->
                        line.elements.forEach { element ->
                            val rect = element.boundingBox
                            if (element.text.any { it.isLetter() } && rect != null) {
                                boxes.put(JSONObject().put("text", element.text).put("left", rect.left).put("top", rect.top).put("right", rect.right).put("bottom", rect.bottom).put("block", blockIndex).apply {
                                    if (!contextWritten) { put("context", block.text); contextWritten = true }
                                })
                            }
                        }
                    } }
                    if (result.text.isBlank()) {
                        Toast.makeText(this, "没有识别到英文。请让文字更清晰后重试。", Toast.LENGTH_LONG).show()
                    } else if (forTranslation) {
                        showRecognizedTranslation(recognizedText)
                    } else {
                        showWordSelection(recognizedText, imageFile.absolutePath, boxes.toString(), bitmap.width, bitmap.height, source, original, photoArea)
                    }
                }
                .addOnFailureListener {
                    if (!isDestroyed) Toast.makeText(this, "识别失败，请重试。", Toast.LENGTH_LONG).show()
                }
                .addOnCompleteListener {
                    photoBusy = false; bitmap.recycle(); imageFile.delete(); recognizer.close()
                    finishScreenLookupIfIdle()
                }
        }
    }

    private fun showWordSelection(text: String, imagePath: String, boxesJson: String, imageWidth: Int, imageHeight: Int, source: ImageSource = ImageSource.SCREEN) =
        showWordSelection(text,imagePath,boxesJson,imageWidth,imageHeight,source,
            if (imagePath.isNotBlank()) OriginalPhoto(applicationContext,Uri.fromFile(File(imagePath))) else null,RectF(0f,0f,1f,1f))

    private fun showWordSelection(text: String, imagePath: String, boxesJson: String, imageWidth: Int, imageHeight: Int, source: ImageSource,
        original: OriginalPhoto?, photoArea: RectF) {
        if (text.isBlank() || imagePath.isBlank()) {
            Toast.makeText(this, "没有识别到清晰文字。请放大英文内容、换个页面后重试。", Toast.LENGTH_LONG).show()
            return
        }
        val bitmap = try { BitmapFactory.decodeFile(imagePath) } catch (_: Exception) { null }
        if (bitmap == null) { showRecognizedTextFallback(text); return }
        val boxes = mutableListOf<WordBox>()
        try {
            val arr = JSONArray(boxesJson)
            val blockContexts = buildMap<Int, String> {
                for (i in 0 until arr.length()) {
                    val item = arr.getJSONObject(i)
                    if (item.has("block") && item.has("context")) put(item.getInt("block"), item.optString("context"))
                }
            }
            for (i in 0 until arr.length()) {
                val item = arr.getJSONObject(i)
                boxes.add(WordBox(item.optString("text"), item.optInt("left"), item.optInt("top"), item.optInt("right"), item.optInt("bottom"),
                    if (item.has("block")) blockContexts[item.getInt("block")].orEmpty() else item.optString("context")))
            }
        } catch (_: Exception) {}
        val sourceKey = java.util.UUID.randomUUID().toString()
        lateinit var selectionView: WordSelectionView
        selectionView = WordSelectionView(this, bitmap, boxes, imageWidth.takeIf { it > 0 } ?: bitmap.width,
            imageHeight.takeIf { it > 0 } ?: bitmap.height) {
                val context=OcrText.merge(selectionView.selectedBox?.context.orEmpty())
                val area=selectionView.contextArea()?.let { child -> OriginalPhoto.compose(photoArea,child) }
                showSelectedWordDialog(it,context,null,sourceKey) {
                    if (original != null && area != null) original.crop(area) else selectionView.cropContext()
                }
            }.apply {
            background = BrandUi.shape(this@LookupActivity, BrandUi.Cream, 16)
            clipToOutline = true
        }
        val container = column().apply {
            setPadding(dp(8), dp(4), dp(8), dp(8))
            addView(BrandUi.label(this@LookupActivity, if (boxes.isEmpty()) "识别完成，可手动补充单词" else "找到 ${boxes.size} 个可点选的词", 13f, bold = true))
        }
        val hint = BrandUi.label(this, "拖动查看图片，双指或双击放大，轻点词框查词。", 12f, BrandUi.Muted)
        container.addView(hint, lp(top = 4))
        container.addView(selectionView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f).apply { topMargin = dp(8) })
        val dialog = AlertDialog.Builder(this).setTitle(if (source == ImageSource.PHOTO) "照片里的单词" else "屏幕里的单词")
            .setView(container).setNegativeButton("完成", null)
            .setNeutralButton(if (source == ImageSource.PHOTO) "重新拍照" else "重新截屏", null).create()
        val controls = column()
        fun row(): LinearLayout = LinearLayout(this).also { controls.addView(it, lp(top = 8)) }
        fun button(row: LinearLayout, title: String, color: Int = BrandUi.Cream, action: () -> Unit): Button =
            BrandUi.compactAction(this, title, color).apply {
                setOnClickListener { action() }
                row.addView(this, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f).apply {
                    if (row.childCount > 0) marginStart = dp(8)
                })
            }
        fun recognizeArea(area: RectF?, translate: Boolean) {
            if (area == null) { Toast.makeText(this,"请先拖选要翻译的文字",Toast.LENGTH_SHORT).show(); return }
            if (photoBusy) return
            val composed=OriginalPhoto.compose(photoArea,area)
            photoBusy=true
            background({ original?.crop(composed) ?: if (translate) selectionView.cropSelection() else selectionView.cropVisible() },discard={it?.recycle()},failed={photoBusy=false;finishScreenLookupIfIdle()}) { cropped ->
                photoBusy=false
                if (cropped == null) Toast.makeText(this,"选区太小，请重新框选",Toast.LENGTH_SHORT).show()
                else { dialog.dismiss(); recognizePhoto(cropped,source,translate,original,composed) }
            }
        }
        var regionMode = false
        lateinit var regionButton: Button
        lateinit var regionConfirm: Button
        fun styleMode(button: Button, selected: Boolean) {
            button.background = BrandUi.ripple(this, if (selected) BrandUi.Forest else BrandUi.SoftGreen, 16)
            button.setTextColor(if (selected) BrandUi.Paper else BrandUi.Forest)
            button.isSelected = selected
        }
        fun leaveRegionMode() {
            regionMode = false; selectionView.setRegionSelectionEnabled(false)
            regionButton.text = "框选翻译"
            regionConfirm.visibility=View.GONE; styleMode(regionButton, false)
            hint.text = "拖动查看图片，双指或双击放大，轻点词框查词。"
        }
        val zoomRow = row()
        button(zoomRow,"缩小 −",BrandUi.Tint) { selectionView.zoomBy(1f/1.5f) }
        button(zoomRow,"放大 ＋",BrandUi.Tint) { selectionView.zoomBy(1.5f) }
        val translateRow=row()
        regionButton=button(translateRow,"框选翻译",BrandUi.SoftGreen) {
            if (regionMode) leaveRegionMode()
            else {
                regionMode=true; selectionView.setRegionSelectionEnabled(true); regionButton.text="取消框选"
                styleMode(regionButton,true)
                hint.text="拖出矩形后点“翻译选区”，也可以重新拖选。"
                regionConfirm.visibility=View.VISIBLE
            }
        }
        button(translateRow,"翻译全文",BrandUi.SoftGreen) { showRecognizedTranslation(text) }.tag="ocr_translate_all"
        val moreRow=row()
        button(moreRow,"更多") {
            PopupMenu(this,moreRow).apply {
                menu.add(0,1,1,"适宽").setOnMenuItemClickListener { selectionView.fitWidth(); true }
                menu.add(0,2,2,"全图").setOnMenuItemClickListener { selectionView.fitImage(); true }
                menu.add(0,3,3,"逐行选择").setOnMenuItemClickListener { showOcrLineSelection(text); true }
                menu.add(0,4,4,"识别当前区域").setOnMenuItemClickListener { recognizeArea(selectionView.visibleArea(),false); true }
                menu.add(0,5,5,"手动输入").setOnMenuItemClickListener { showAddDialog(""); true }
            }.show()
        }.tag="ocr_more"
        regionConfirm=button(moreRow,"翻译选区",BrandUi.Forest) { recognizeArea(selectionView.selectionArea(),true) }.apply {
            setTextColor(BrandUi.Paper); visibility=View.GONE; tag="ocr_region_translate"
        }
        // Keep controls scrollable on short landscape screens while preserving image space.
        container.addView(ScrollView(this).apply { addView(controls) }, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, minOf(dp(156), (resources.displayMetrics.heightPixels * 0.28f).toInt())))
        lookupDialogs.add(dialog)
        dialog.setOnDismissListener { lookupDismissed(dialog); bitmap.recycle() }
        dialog.show()
        dialog.getButton(AlertDialog.BUTTON_NEGATIVE).apply {
            backgroundTintList = null; stateListAnimator = null; elevation = 0f
            background = BrandUi.ripple(this@LookupActivity, BrandUi.Forest, 16)
            setTextColor(BrandUi.Paper); minHeight = dp(44)
            setPadding(dp(20), dp(10), dp(20), dp(10))
        }
        dialog.getButton(AlertDialog.BUTTON_NEUTRAL).apply {
            backgroundTintList = null; stateListAnimator = null; elevation = 0f
            background = BrandUi.ripple(this@LookupActivity, BrandUi.Cream, 16, BrandUi.Line)
            setTextColor(BrandUi.Forest); minHeight = dp(44)
            setPadding(dp(20), dp(10), dp(20), dp(10))
        }
        dialog.window?.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        selectionView.post { if (dialog.isShowing) selectionView.fitWidth() }
        dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
            if (source == ImageSource.SCREEN) restartingScreenCapture = true
            dialog.dismiss()
            if (source == ImageSource.PHOTO) takePhotoForLookup() else handleIntent(Intent(OverlayService.ACTION_CAPTURE))
        }
    }

    private fun showSelectedWordDialog(word: String) = showSelectedWordDialog(word, "", null, "")

    private fun showSelectedWordDialog(word: String, originalSentence: String, contextImage: Bitmap?, source: String) =
        showSelectedWordDialog(word,originalSentence,contextImage,source,null)
    private fun showSelectedWordDialog(word: String, originalSentence: String, contextImage: Bitmap?, source: String, imageLoader: (() -> Bitmap?)?) {
        var snapshot = contextImage
        val clean = WordForms.clean(word)
        if (clean.isBlank() && source.isNotBlank()) { snapshot?.recycle(); return }
        var lookupGeneration = 0
        var meaningEdited = false
        var settingMeaning = false
        val wordInput = BrandUi.field(this, "识别不准时可直接修改").apply { tag = "word_input"; setText(clean) }
        val meaningInput = BrandUi.field(this, "正在查询释义…", false).apply { tag = "meaning_input"; minLines = 2 }
        val phonetic = BrandUi.label(this, "正在查询音标…", 14f, BrandUi.Muted).apply { tag = "word_phonetic" }
        val encounterStatus = BrandUi.label(this, "", 12f, BrandUi.Muted)
        var existingRevealed = false
        val revealExisting = BrandUi.compactAction(this, "先回想，再查看释义", BrandUi.SoftGreen).apply {
            tag = "word_reveal_existing"; visibility = View.GONE
            setOnClickListener { existingRevealed = true; meaningInput.visibility = View.VISIBLE; visibility = View.GONE }
        }
        val sentenceInput = BrandUi.field(this, "原句（可选，用于以后填空复习）", false).apply { setText(originalSentence); tag = "word_context" }
        val noteInput = BrandUi.field(this, "记忆笔记（可选）", false).apply { tag = "word_note" }
        val saveImage = android.widget.CheckBox(this).apply { text = "保存这段原图，复习时作为提示"; tag="word_save_image"; isChecked = false; visibility = if (snapshot == null && imageLoader == null) View.GONE else View.VISIBLE; setTextColor(BrandUi.Forest) }
        val inputs = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(4), dp(20), dp(8))
            addView(BrandUi.label(this@LookupActivity, "英文单词", 12f, BrandUi.Muted))
            addView(wordInput, lp(top = 7))
            addView(phonetic, lp(top = 8))
            addView(encounterStatus, lp(top = 6))
            addView(revealExisting, lp(top = 6))
            addView(BrandUi.label(this@LookupActivity, "中文释义 · 可以自己补充", 12f, BrandUi.Muted), lp(top = 16))
            addView(meaningInput, lp(top = 7))
            val extras=column().apply { visibility=View.GONE; addView(sentenceInput,lp(top=7)); addView(noteInput,lp(top=8)); addView(saveImage,lp(top=6)) }
            addView(BrandUi.compactAction(this@LookupActivity,"阅读记录（可选）").apply {
                tag="word_extras"; setOnClickListener { extras.visibility=if (extras.visibility==View.VISIBLE) View.GONE else View.VISIBLE; text=if (extras.visibility==View.VISIBLE) "收起阅读记录" else "阅读记录（可选）" }
            },lp(top=10))
            addView(extras,lp())
        }
        val dialog = AlertDialog.Builder(this).setTitle("确认单词和释义").setView(ScrollView(this).apply { addView(inputs) })
            .setNegativeButton("取消", null).setPositiveButton("收藏单词", null).create()
        var open = true
        fun lookup() {
            val generation = ++lookupGeneration
            val value = wordInput.text.toString()
            if (value.isBlank()) { phonetic.text="输入英文后自动查释义和音标"; return }
            background({
                val old = WordStore.allEntries(applicationContext).firstOrNull { it.word.equals(WordForms.clean(value), true) }
                Triple(old?.meaning ?: WordStore.lookupMeaning(applicationContext, value),
                    ReviewStore.profile(applicationContext, value).phonetic.ifBlank { WordStore.lookupPhonetic(applicationContext, value) }, old != null)
            }) { (meaning, ipa, existing) ->
                if (open && generation == lookupGeneration && !meaningEdited) {
                    settingMeaning = true; meaningInput.setText(meaning); settingMeaning = false
                }
                if (open && generation == lookupGeneration) {
                    phonetic.text = ipa.ifBlank { "暂无音标，可收藏后在档案中补充" }
                    encounterStatus.text = if (existing) "这个词已经收藏过：先回想一下意思。再次保存会追加这次阅读记录。" else ""
                    val hidden = existing && !existingRevealed && !meaningEdited
                    meaningInput.visibility = if (hidden) View.GONE else View.VISIBLE
                    revealExisting.visibility = if (hidden) View.VISIBLE else View.GONE
                }
            }
        }
        meaningInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { if (!settingMeaning) meaningEdited = true }
            override fun afterTextChanged(s: Editable?) {}
        })
        val relookup = Runnable { lookup() }
        wordInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                lookupGeneration++; meaningEdited = false
                existingRevealed = false; revealExisting.visibility = View.GONE; meaningInput.visibility = View.VISIBLE
                settingMeaning = true; meaningInput.setText(""); settingMeaning = false
                mainHandler.removeCallbacks(relookup); mainHandler.postDelayed(relookup, 300)
            }
            override fun afterTextChanged(s: Editable?) {}
        })
        lookupDialogs.add(dialog)
        dialog.setOnDismissListener { lookupDismissed(dialog); open = false; lookupGeneration++; mainHandler.removeCallbacks(relookup); snapshot?.recycle(); snapshot = null }
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val corrected = WordForms.clean(wordInput.text.toString())
                if (corrected.isBlank()) { wordInput.error = "请输入单词"; return@setOnClickListener }
                val meaning = meaningInput.text.toString().trim()
                val sentence = sentenceInput.text.toString(); val note = noteInput.text.toString()
                val wantsImage=saveImage.isChecked
                val image = if (wantsImage) snapshot else null
                if (!saveImage.isChecked) snapshot?.recycle()
                snapshot = null
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).isEnabled = false
                background({
                    try {
                        val added = WordStore.add(applicationContext, corrected, meaning.ifBlank { WordStore.lookupMeaning(applicationContext, corrected) })
                        if (!added && meaning.isNotBlank()) WordStore.updateMeaning(applicationContext, corrected, meaning)
                        if (!added) ReviewStore.markSeen(applicationContext,corrected)
                        val loaded=image ?: if (wantsImage) runCatching { imageLoader?.invoke() }.getOrNull() else null
                        try { ReviewStore.recordEncounter(applicationContext, corrected, sentence, note, source, loaded) }
                        finally { if (loaded !== image) loaded?.recycle() }
                        added
                    } finally { image?.recycle() }
                }, failed = { dialog.getButton(AlertDialog.BUTTON_POSITIVE).isEnabled = true }) { added ->
                    Toast.makeText(this, if (added) "已收藏：$corrected" else "已更新这次阅读记录：$corrected", Toast.LENGTH_SHORT).show()
                    dialog.dismiss(); onWordsChanged()
                }
            }
        }
        dialog.show(); lookup()
    }

    private fun showOcrLineSelection(text: String) {
        val dialog = OcrLineSelectionDialog.show(this, text) { showSentenceTranslation(it) }
        lookupDialogs.add(dialog); dialog.setOnDismissListener { lookupDismissed(dialog) }
    }

    private fun showRecognizedTranslation(text: String) {
        val merged = OcrText.merge(text)
        if (merged.length > SentenceTranslationDialog.MAX_LENGTH) {
            Toast.makeText(this, "文字超过 3000 字符，请选择部分文字分段翻译。", Toast.LENGTH_LONG).show()
            showOcrLineSelection(text)
        } else showSentenceTranslation(merged)
    }

    protected fun showSentenceTranslation(text: String) {
        val sheet = SentenceTranslationDialog(this)
        sentenceDialogs.add(sheet)
        sheet.show(text) { sentenceDialogs.remove(sheet); finishScreenLookupIfIdle() }
    }

    private fun showRecognizedTextFallback(text: String) {
        val input = BrandUi.field(this, "只保留你想收藏的单词", false).apply { setText(text) }
        val dialog = AlertDialog.Builder(this).setTitle("识别结果（备用方式）").setView(input)
            .setNeutralButton("选择句子翻译") { _, _ -> showOcrLineSelection(input.text.toString()) }
            .setNegativeButton("取消", null).setPositiveButton("继续") { _, _ -> showSelectedWordDialog(input.text.toString()) }.create()
        lookupDialogs.add(dialog); dialog.setOnDismissListener { lookupDismissed(dialog) }; dialog.show()
    }

    protected fun showAddDialog(initial: String) { showSelectedWordDialog(initial) }

    companion object {
        private const val REQUEST_CAMERA = 4103
        private const val KEY_PHOTO_LOOKUP_URI = "photo_lookup_uri"
        private const val PHOTO_MAX_SIDE = 2048
    }
}

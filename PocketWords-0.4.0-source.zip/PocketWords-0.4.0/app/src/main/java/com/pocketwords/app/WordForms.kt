package com.pocketwords.app

import java.util.Locale

object WordForms {
    fun clean(word: String): String = word.trim().replace(Regex("\\s+"), " ")
        .trim('.', ',', ';', ':', '!', '?', '(', ')', '[', ']', '"', '\'')

    fun key(word: String): String = clean(word).lowercase(Locale.ROOT)

    fun candidates(word: String): List<String> {
        val key = key(word)
        val forms = linkedSetOf(key)
        if (key.contains(' ')) return forms.toList()
        if (key.endsWith("ies") && key.length > 4) forms.add(key.dropLast(3) + "y")
        if (key.endsWith("es") && key.length > 4) {
            forms.add(key.dropLast(2)); forms.add(key.dropLast(1))
        }
        if (key.endsWith("s") && key.length > 3) forms.add(key.dropLast(1))
        if (key.endsWith("ied") && key.length > 4) forms.add(key.dropLast(3) + "y")
        for (suffix in listOf("ed", "ing")) {
            if (key.endsWith(suffix) && key.length > suffix.length + 2) {
                val stem = key.dropLast(suffix.length)
                forms.add(stem)
                forms.add(stem + "e")
                if (stem.length > 2 && stem.last() == stem[stem.length - 2]) forms.add(stem.dropLast(1))
            }
        }
        return forms.toList()
    }

    fun lookup(word: String, dictionary: (String) -> String?, fallback: (String) -> String?): String? {
        for (candidate in candidates(word)) {
            dictionary(candidate)?.let { return it }
            fallback(candidate)?.let { return it }
        }
        return null
    }
}

package com.pocketwords.app

import android.content.Context
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout

/** The same colors and stroke icons as the home screen, kept compact over reading content. */
class OverlayBubbleView(context: Context) : LinearLayout(context) {
    init {
        orientation = HORIZONTAL; gravity = Gravity.CENTER
        setPadding(BrandUi.dp(context, 12), 0, BrandUi.dp(context, 12), 0)
        background = BrandUi.ripple(context, BrandUi.Forest, 18, BrandUi.Paper)
        elevation = BrandUi.dp(context, 6).toFloat()
        isClickable = true; isFocusable = true; isLongClickable = true
        contentDescription = "屏幕取词；轻点识别，拖动移位，长按关闭"
        addView(BrandUi.icon(context, R.drawable.ic_capture, BrandUi.Citron), LayoutParams(BrandUi.dp(context, 22), BrandUi.dp(context, 22)).apply { marginEnd = BrandUi.dp(context, 7) })
        addView(BrandUi.label(context, "取词", 13f, BrandUi.Paper, true).apply {
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        })
    }
}

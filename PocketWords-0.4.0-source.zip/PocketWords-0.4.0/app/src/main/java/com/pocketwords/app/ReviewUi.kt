package com.pocketwords.app

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.SpannableString
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.*
import java.time.Instant
import java.time.ZoneId
import java.util.concurrent.Executors

/** All question sources, scheduling and saved progress stay on the device. */
internal class ReviewUi(private val activity: Activity, private val changed: () -> Unit) {
    private val io = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private val dialogs = mutableSetOf<AlertDialog>()
    private var sessionDialog: AlertDialog? = null
    private var saveSession: (() -> Unit)? = null
    private var closed = false
    private var closing = false
    private var preparing = false
    private fun dp(n: Int) = BrandUi.dp(activity, n)
    private fun space(top: Int = 8) = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(top) }
    private fun column() = LinearLayout(activity).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(4), dp(20), dp(16)) }
    private fun label(body: LinearLayout, text: String, size: Float = 14f, bold: Boolean = false): TextView = BrandUi.label(activity, text, size, bold = bold).also { body.addView(it, space()) }
    private fun button(body: LinearLayout, text: String, color: Int = BrandUi.SoftGreen, tag: String? = null, action: () -> Unit): Button =
        BrandUi.compactAction(activity, text, color, if (color == BrandUi.Forest) BrandUi.Paper else BrandUi.Forest).apply {
            this.tag = tag; setOnClickListener { action() }; body.addView(this, space())
        }
    private fun show(title: String, body: View): AlertDialog {
        val dialog = AlertDialog.Builder(activity).setTitle(title)
            .setView(ScrollView(activity).apply { addView(body) }).setNegativeButton("关闭", null).create()
        dialogs.add(dialog); dialog.setOnDismissListener { dialogs.remove(dialog) }; dialog.show()
        return dialog
    }
    private fun configureAnswerInput(dialog: AlertDialog, body: View) {
        val window = dialog.window ?: return
        // AlertDialog sets ALT_FOCUSABLE_IM when first shown without an editor.
        // Review questions add/remove their editor later, so update the window explicitly.
        window.clearFlags(WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE)
        val input = body.findViewWithTag<EditText>("review_answer")
        val keyboard = activity.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        if (input == null) {
            window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE or WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN)
            keyboard.hideSoftInputFromWindow(window.decorView.windowToken, 0)
            return
        }
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE or WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE)
        input.isFocusableInTouchMode = true
        input.showSoftInputOnFocus = true
        input.requestFocus()
        input.post {
            if (dialog.isShowing && input.isAttachedToWindow && input.hasFocus()) {
                keyboard.showSoftInput(input, InputMethodManager.SHOW_IMPLICIT)
            }
        }
    }
    private fun <T> work(job: () -> T, failed: () -> Unit = {}, done: (T) -> Unit = {}) {
        if (closed) return
        io.execute {
            val result = runCatching(job)
            main.post {
                if (closed || activity.isDestroyed || activity.isFinishing) {
                    (result.getOrNull() as? Bitmap)?.recycle()
                } else result.fold(done) { failed(); Toast.makeText(activity, it.message ?: "操作失败，请重试", Toast.LENGTH_LONG).show() }
            }
        }
    }
    private fun load() = ReviewStore.cards(activity, WordStore.resolvedEntries(activity), details = false)
    fun startToday() {
        if (preparing) return
        preparing=true
        work({ load() to ReviewStore.loadRun(activity) },failed={preparing=false}) { (cards,saved) ->
            if (saved != null && !saved.finished) session(cards,saved)
            else start(cards,ReviewScope.DUE,ReviewMode.MIXED,10,false)
        }
    }
    fun open() = work({ Triple(load(), ReviewStore.loadRun(activity), ReviewStore.statistics(activity)) }) { (cards, saved, stats) ->
        val now = System.currentTimeMillis()
        val active = cards.filter { !it.profile.paused && ReviewEngine.hasMeaning(it) }
        val due = active.count { it.profile.meaning.due <= now || it.profile.spelling.due <= now }
        val body = column()
        label(body, "今天待复习 $due 词", 22f, true)
        label(body, "题目来自你的收藏、原句和本地词典。无需联网生成题目。", 12f)
        if (cards.isEmpty()) label(body, "先从阅读中收藏几个单词，再来开始复习。")
        if (cards.any { !ReviewEngine.hasMeaning(it) }) label(body, "释义待补充的词暂不出题，可在单词档案中补充。", 12f)
        val home = show("我的复习", body)
        if (saved != null) button(body, if (saved.finished) "查看上次结果" else "继续上次复习 · 已完成 ${saved.answered} 题", BrandUi.Forest, "review_resume") {
            home.dismiss(); work({ load() to ReviewStore.loadRun(activity) }) { (fresh, run) -> if (run != null) session(fresh, run) }
        }
        button(body, "自定义复习", BrandUi.Cream, "review_start") { home.dismiss(); setup(cards) }
        button(body, "复习 3 分钟", tag = "review_short") { home.dismiss(); start(cards, ReviewScope.DUE, ReviewMode.MIXED, 10, true) }
        button(body, "易混词组", BrandUi.Cream) { groups(cards) }
        button(body, "学习统计", BrandUi.Cream) { statistics(cards, stats) }
        label(body, "认词与拼写分开记录；隔天仍能独立答对，才逐步延长间隔。提示后答对不计为独立掌握。", 12f)
        label(body, "完整备份包含学习记录与图片；CSV 用于交换词表。", 11f)
    }
    private fun setup(cards: List<ReviewCard>, source: String = "") {
        val body = column()
        val scopes = ReviewScope.entries.filter { it != ReviewScope.SOURCE || source.isNotEmpty() }
        label(body, "复习范围", bold = true)
        val scope = Spinner(activity).apply { tag = "review_scope"; adapter = ArrayAdapter(activity, android.R.layout.simple_spinner_dropdown_item, scopes.map { it.title }) }
        body.addView(scope, space())
        if (source.isNotEmpty()) scope.setSelection(scopes.indexOf(ReviewScope.SOURCE))
        label(body, "练习方式", bold = true)
        val mode = Spinner(activity).apply { tag = "review_mode"; adapter = ArrayAdapter(activity, android.R.layout.simple_spinner_dropdown_item, ReviewMode.entries.map { it.title }) }
        body.addView(mode, space())
        label(body, "每轮词数", bold = true)
        val amount = Spinner(activity).apply { adapter = ArrayAdapter(activity, android.R.layout.simple_spinner_dropdown_item, listOf("10 词", "20 词", "30 词")) }
        body.addView(amount, space())
        label(body, "混合练习先认词，再穿插拼写与原句填空；没有对应原句的词不会编造填空题。最近收藏指建立档案后的 7 天内。", 12f)
        val dialog = show("安排这一轮", body)
        button(body, "开始复习", BrandUi.Forest, "review_begin") {
            start(cards, scopes[scope.selectedItemPosition], ReviewMode.entries[mode.selectedItemPosition], (amount.selectedItemPosition + 1) * 10, false, source) { dialog.dismiss() }
        }
    }
    private fun start(cards: List<ReviewCard>, scope: ReviewScope, mode: ReviewMode, amount: Int, short: Boolean, source: String = "", started: () -> Unit = {}) {
        sessionDialog?.dismiss()
        work({
            val candidates = if (mode == ReviewMode.MIXED || mode == ReviewMode.CLOZE || scope == ReviewScope.SOURCE) ReviewStore.withContexts(activity, cards) else cards
            val tasks = ReviewEngine.plan(candidates, scope, mode, System.currentTimeMillis(), amount, source)
            check(tasks.isNotEmpty()) { if (mode == ReviewMode.CLOZE) "暂无含目标词的原句，可以先选认词或拼写。" else "这个范围暂无到期单词，可在自定义复习中选择全部。" }
            ReviewRun(tasks.toMutableList(), short = short).also { ReviewStore.saveRun(activity, it, replace = true) }
        },failed={preparing=false}) { run -> started(); session(cards, run) }
    }
    private fun session(cards: List<ReviewCard>, initial: ReviewRun) {
        val keys = initial.tasks.map { WordForms.key(it.word) }.toSet()
        work({ ReviewStore.hydrate(activity, cards.filter { WordForms.key(it.entry.word) in keys }) },failed={preparing=false}) { hydrated -> preparing=false;showSession(hydrated, initial) }
    }
    private fun showSession(cards: List<ReviewCard>, initial: ReviewRun) {
        sessionDialog?.dismiss()
        if (initial.finished) { summary(cards, initial); return }
        var run = initial
        val byWord = cards.associateBy { WordForms.key(it.entry.word) }.toMutableMap()
        val body = column()
        val dialog = AlertDialog.Builder(activity).setTitle("阅读词库 · 复习")
            .setView(ScrollView(activity).apply { addView(body) })
            .setNegativeButton("稍后继续", null).setNeutralButton("结束本轮", null).create()
        var busy = false
        var mark = SystemClock.elapsedRealtime()
        var revealed = run.pendingRevealed
        var hinted = run.pendingHinted
        var typed = run.pendingTyped
        var spellingCorrect = run.tasks.getOrNull(run.index)?.let { ReviewEngine.isCorrect(typed, it.word) } ?: false
        var progress: TextView? = null
        fun checkpoint() {
            val now = SystemClock.elapsedRealtime(); run.elapsed += (now - mark).coerceAtLeast(0); mark = now
            run.pendingHinted = hinted; run.pendingRevealed = revealed; run.pendingTyped = typed
        }
        lateinit var render: () -> Unit
        fun grade(rating: Int) {
            if (busy) return
            checkpoint(); busy = true
            body.isEnabled = false
            val applied = if (hinted) minOf(1, rating) else rating
            work({ ReviewStore.answer(activity, run, applied) }, failed = { busy = false; body.isEnabled = true }) { (saved, profile) ->
                run = saved; byWord[WordForms.key(profile.word)]?.let { byWord[WordForms.key(profile.word)] = it.copy(profile = profile) }
                busy = false; body.isEnabled = true; mark = SystemClock.elapsedRealtime()
                if (dialog.isShowing) {
                    if (run.finished) { dialog.dismiss(); summary(byWord.values.toList(), run) }
                    else { revealed = false; hinted = false; typed = ""; render() }
                }
            }
        }
        fun hint(message: String) { hinted = true; Toast.makeText(activity, message, Toast.LENGTH_LONG).show() }
        render = render@{
            val previousIndex = run.index
            while (run.index < run.tasks.size && byWord[WordForms.key(run.tasks[run.index].word)]?.let { !it.profile.paused && ReviewEngine.hasMeaning(it) } != true) run.index++
            if (run.index != previousIndex) {
                revealed = false; hinted = false; typed = ""
                run.pendingRevealed = false; run.pendingHinted = false; run.pendingTyped = ""
                val snapshot = ReviewStore.parseRun(ReviewStore.runJson(run))
                work({ ReviewStore.saveRun(activity, snapshot) })
            }
            if (run.index >= run.tasks.size) { dialog.dismiss(); summary(byWord.values.toList(), run); return@render }
            val task = run.tasks[run.index]
            val card = byWord.getValue(WordForms.key(task.word))
            body.removeAllViews()
            progress = label(body, "${run.index + 1} / ${run.tasks.size} · ${task.kind.title}${if (task.retry) " · 错词重练" else ""}", 12f)
            val context = if (task.kind == QuizKind.CLOZE) card.clozeContext else card.contexts.firstOrNull { it.sentence.isNotEmpty() }
            val prompt = when (task.kind) {
                QuizKind.RECALL -> card.entry.word
                QuizKind.SPELL -> ReviewEngine.promptMeaning(card.entry.meaning)
                QuizKind.CLOZE -> context?.let { ReviewEngine.cloze(it.sentence, card.entry.word) } ?: card.entry.meaning
            }
            label(body, prompt, if (task.kind == QuizKind.RECALL) 30f else 20f, true).tag = "review_question"
            if (!revealed) {
                if (task.kind != QuizKind.RECALL) label(body, "填写收藏时的英文 · ${card.entry.word.length} 个字符", 12f)
                if (task.kind == QuizKind.RECALL) {
                    label(body, "先在心里回想意思，再查看答案。", 12f)
                    button(body, "查看释义", BrandUi.Forest, "review_reveal") { if (!busy) { revealed = true; render() } }
                } else {
                    val input = BrandUi.field(activity, "输入英文，大小写不影响判定").apply {
                        tag = "review_answer"; setText(typed)
                        inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
                        imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_DONE
                        setSelection(text.length)
                    }
                    body.addView(input, space())
                    input.addTextChangedListener(object : android.text.TextWatcher {
                        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
                        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { typed = s.toString() }
                        override fun afterTextChanged(s: android.text.Editable?) = Unit
                    })
                    fun check() {
                        if (busy) return
                        typed = input.text.toString()
                        if (typed.isBlank()) { input.error = "请输入答案，或点击“想不起来”"; return }
                        spellingCorrect = ReviewEngine.isCorrect(typed, card.entry.word)
                        revealed = true
                        (activity.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(input.windowToken, 0)
                        render()
                    }
                    input.setOnEditorActionListener { _, _, _ -> check(); true }
                    button(body, "核对答案", BrandUi.Forest, "review_check") { check() }
                    button(body, "想不起来", BrandUi.Cream) { if (!busy) { typed = ""; spellingCorrect = false; revealed = true; render() } }
                }
                button(body, "提示", BrandUi.Cream, "review_hint") {
                    PopupMenu(activity, body.findViewWithTag<View>("review_hint")).apply {
                        if (task.kind != QuizKind.RECALL) menu.add(0, 1, 0, "首字母").setOnMenuItemClickListener { hint("首字母：${card.entry.word.firstOrNull() ?: '—'}"); true }
                        if (task.kind == QuizKind.CLOZE) menu.add("中文释义").setOnMenuItemClickListener { hint(card.entry.meaning); true }
                        if (context != null && task.kind != QuizKind.CLOZE) menu.add("原句").setOnMenuItemClickListener { hint(context.sentence); true }
                        card.contexts.firstOrNull { it.image.isNotEmpty() }?.let { reading ->
                            menu.add("原图片段").setOnMenuItemClickListener { hinted = true; image(reading.image); true }
                        }
                        if (menu.size() == 0) menu.add("暂无额外提示").isEnabled = false
                    }.show()
                }
            } else {
                label(body, card.entry.word, 25f, true)
                label(body, card.phonetic.ifBlank { "暂无音标，可在档案中补充" }, 15f).tag = "review_phonetic"
                label(body, card.entry.meaning, 18f).tag = "review_solution"
                context?.let { label(body, it.sentence, 14f) }
                card.contexts.firstOrNull { it.note.isNotEmpty() }?.let { label(body, "笔记：${it.note}", 13f) }
                if (hinted) label(body, "本题使用了提示，最多记为“有点印象”。", 12f)
                if (task.kind == QuizKind.RECALL) {
                    button(body, "记住了", BrandUi.Forest, "review_good") { grade(2) }
                    button(body, "有点印象") { grade(1) }
                    button(body, "忘记了", BrandUi.Cream, "review_again") { grade(0) }
                } else {
                    if (typed.isNotEmpty()) label(body, "你的答案：", 12f).also {
                        val value = SpannableString(typed)
                        typed.indices.forEach { index ->
                            if (index >= card.entry.word.length || !typed[index].equals(card.entry.word[index], true))
                                value.setSpan(ForegroundColorSpan(0xFFB34532.toInt()), index, index + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                        }
                        label(body, "").text = value
                    }
                    label(body, if (spellingCorrect) "拼写正确" else "还没拼对，对照上方单词再记一次。", 14f, true)
                    button(body, "下一题", BrandUi.Forest, "review_good") { grade(if (spellingCorrect) 2 else 0) }
                }
            }
            button(body, "更多", BrandUi.Cream, "review_more") {
                PopupMenu(activity, body.findViewWithTag<View>("review_more")).apply {
                    menu.add("编辑词条 / 暂停复习").setOnMenuItemClickListener {
                        if (!busy) word(card.entry.word) { updated -> byWord[WordForms.key(updated.entry.word)] = updated; if (dialog.isShowing) render() }
                        true
                    }
                }.show()
            }
            configureAnswerInput(dialog, body)
        }
        val clock = object : Runnable {
            override fun run() {
                if (!dialog.isShowing) return
                if (!busy) checkpoint()
                if (run.short) progress?.text = "${run.index + 1} / ${run.tasks.size} · ${if (run.elapsed >= 180_000) "3 分钟已到，完成本题即可结束" else "剩余 ${(180_000 - run.elapsed) / 1000} 秒"}"
                main.postDelayed(this, 1000)
            }
        }
        dialogs.add(dialog); sessionDialog = dialog
        fun persist() {
            if (!busy) {
                checkpoint()
                val snapshot = ReviewStore.parseRun(ReviewStore.runJson(run))
                work({ ReviewStore.saveRun(activity, snapshot) })
            }
        }
        saveSession = { persist() }
        dialog.setCanceledOnTouchOutside(false)
        dialog.setOnDismissListener {
            main.removeCallbacks(clock); dialogs.remove(dialog)
            if (sessionDialog === dialog) { sessionDialog = null; saveSession = null }
            persist()
            if (!closing && !closed && !activity.isDestroyed) changed()
        }
        dialog.show()
        dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
            if (!busy) { checkpoint(); run.index = run.tasks.size; dialog.dismiss(); summary(byWord.values.toList(), run) }
        }
        dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener { if (!busy) dialog.dismiss() }
        render(); if (dialog.isShowing) main.post(clock)
    }
    private fun summary(cards: List<ReviewCard>, run: ReviewRun) {
        val body = column()
        label(body, "这一轮完成了 ${run.answered} 题", 23f, true)
        label(body, "独立记住或答对 ${run.correct} 题 · ${run.wrong.size} 词需要巩固\n用时 ${run.elapsed / 60_000} 分 ${(run.elapsed / 1000) % 60} 秒")
        label(body, "认词和拼写各自安排下次复习；同一天重复答对不会连续升级。", 12f)
        val dialog = show("本轮回顾", body)
        cards.filter { WordForms.key(it.entry.word) in run.wrong }.forEach { label(body, "${it.entry.word} · ${it.entry.meaning}", 13f) }
        if (run.wrong.isNotEmpty()) button(body, "只重练这些词", BrandUi.Forest) {
            val subset = cards.filter { WordForms.key(it.entry.word) in run.wrong }
            dialog.dismiss(); start(subset, ReviewScope.ALL, ReviewMode.MIXED, 30, false)
        }
        button(body, "继续选一组") { dialog.dismiss(); open() }
    }
    fun word(word: String, updated: (ReviewCard) -> Unit = {}) = work({
        val entries = WordStore.resolvedEntries(activity).filter { it.word.equals(word, true) }
        ReviewStore.cards(activity, entries).firstOrNull()
    }) { card ->
        if (card == null) { Toast.makeText(activity, "这个词已从单词本移除", Toast.LENGTH_SHORT).show(); return@work }
        val body = column()
        label(body, "${card.profile.stage}", 12f)
        label(body, card.phonetic.ifBlank { "词典暂无音标，可在下方补充" }, 18f)
        val meaning = BrandUi.field(activity, "中文释义", false).apply { setText(card.entry.meaning); minLines = 2 }
        label(body, "中文释义 · 可修改", 12f); body.addView(meaning, space())
        val phonetic = BrandUi.field(activity, "手动音标（留空使用离线词典）").apply { setText(card.profile.phonetic) }
        body.addView(phonetic, space())
        val latest = card.contexts.firstOrNull { it.sentence.isNotEmpty() || it.note.isNotEmpty() }
        val sentence = BrandUi.field(activity, "补充原句，必须包含这个词才能用于填空", false).apply { setText(latest?.sentence.orEmpty()); minLines = 2 }
        label(body, "原句", 12f); body.addView(sentence, space())
        val note = BrandUi.field(activity, "写一句帮助自己记忆的笔记", false).apply { setText(latest?.note.orEmpty()) }
        label(body, "记忆笔记", 12f); body.addView(note, space())
        val dialog = show("单词档案 · ${card.entry.word}", body)
        button(body, "保存修改", BrandUi.Forest) {
            val m = meaning.text.toString(); val p = phonetic.text.toString(); val s = sentence.text.toString(); val n = note.text.toString()
            work({
                WordStore.updateMeaning(activity, card.entry.word, m)
                ReviewStore.setPhonetic(activity, card.entry.word, p)
                if (s != latest?.sentence.orEmpty() || n != latest?.note.orEmpty()) {
                    if (latest != null) ReviewStore.updateContext(activity, card.entry.word, latest.id, s, n)
                    else ReviewStore.recordEncounter(activity, card.entry.word, s, n, "")
                }
                ReviewStore.hydrate(activity, load().filter { it.entry.word.equals(card.entry.word, true) }).first()
            }) { fresh -> dialog.dismiss(); changed(); updated(fresh) }
        }
        button(body, if (card.profile.paused) "恢复复习" else "暂停这个词", BrandUi.Cream) {
            work({ ReviewStore.setPaused(activity, card.entry.word, !card.profile.paused); ReviewStore.hydrate(activity, load().filter { it.entry.word.equals(card.entry.word, true) }).first() }) {
                dialog.dismiss(); changed(); updated(it)
            }
        }
        button(body, "今天又遇到了", BrandUi.Cream) {
            work({ ReviewStore.markSeen(activity, card.entry.word) }) { Toast.makeText(activity, "已记下这次遇见，不会直接提高掌握度。", Toast.LENGTH_SHORT).show() }
        }
        button(body, "加入易混词组", BrandUi.Cream) { work({ load() }) { createGroup(it, card.entry.word) } }
        if (card.contexts.isNotEmpty()) label(body, "阅读记录 · 最近 ${card.contexts.size} 条", 16f, true)
        card.contexts.forEach { reading ->
            label(body, Instant.ofEpochMilli(reading.created).atZone(ZoneId.systemDefault()).toLocalDate().toString(), 11f)
            if (reading.sentence.isNotEmpty()) label(body, reading.sentence, 13f)
            if (reading.note.isNotEmpty()) label(body, "笔记：${reading.note}", 12f)
            if (reading.image.isNotEmpty()) button(body, "查看这次的原图片段", BrandUi.Cream) { image(reading.image) }
        }
        card.contexts.firstOrNull { it.source.isNotEmpty() }?.let { reading ->
            button(body, "复习这次取词的单词", BrandUi.Cream) { work({ load() }) { setup(it, reading.source) } }
        }
    }
    private fun image(name: String) = work({ BitmapFactory.decodeFile(ReviewStore.imageFile(activity, name).path) }) { bitmap ->
        if (bitmap == null) { Toast.makeText(activity, "原图片段已不可用", Toast.LENGTH_SHORT).show(); return@work }
        val view = WordSelectionView(activity, bitmap, emptyList(), bitmap.width, bitmap.height) {}
        val body = column().apply { addView(view, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (activity.resources.displayMetrics.heightPixels * 0.55f).toInt())) }
        val dialog = show("阅读时的原图片段 · 双指可放大", body)
        dialog.setOnDismissListener { dialogs.remove(dialog); bitmap.recycle() }
    }
    private fun statistics(cards: List<ReviewCard>, days: List<ReviewStore.Daily>) {
        val body = column()
        label(body, "${cards.count { it.profile.mastered }} 词已掌握 · ${cards.count { it.profile.paused }} 词已暂停", 20f, true)
        for (stage in listOf("新收藏", "学习中", "待巩固")) label(body, "$stage：${cards.count { it.profile.stage == stage }} 词")
        label(body, "最近 7 天", 18f, true)
        if (days.isEmpty()) label(body, "完成第一次复习后，这里会记录你的学习情况。")
        days.forEach { day -> label(body, "${day.day} · ${day.words} 词 / ${day.answers} 次作答\n忘记意思 ${day.meaningErrors} 次 · 拼写错误 ${day.spellingErrors} 次", 13f) }
        show("学习统计", body)
    }
    private fun groups(cards: List<ReviewCard>): Unit = work({ ReviewStore.groups(activity) }) { groups ->
        val body = column()
        label(body, "自己把易混的词放在一起，配上区分笔记。", 13f)
        val dialog = show("易混词组", body)
        button(body, "新建易混词组", BrandUi.Forest) { createGroup(cards, saved = { dialog.dismiss(); groups(cards) }) }
        groups.forEach { group -> button(body, group.title, BrandUi.Cream) {
            val compare = column()
            val members = cards.filter { card -> group.words.any { it.equals(card.entry.word, true) } }
            members.forEach { label(compare, "${it.entry.word} ${it.phonetic}\n${it.entry.meaning}", 16f, true) }
            val note = BrandUi.field(activity, "写下这些词的区别", false).apply { setText(group.note); minLines = 3 }
            compare.addView(note, space())
            val sheet = show(group.title, compare)
            button(compare, "保存区分笔记") { val value = note.text.toString(); work({ ReviewStore.saveGroup(activity, group.title, value, group.words, group.id) }) { sheet.dismiss() } }
            button(compare, "复习本组", BrandUi.Forest) { start(members, ReviewScope.ALL, ReviewMode.MIXED, 30, false) { sheet.dismiss(); dialog.dismiss() } }
            button(compare, "删除这个组（保留单词）", BrandUi.Cream) {
                AlertDialog.Builder(activity).setMessage("删除易混词组“${group.title}”？单词和学习记录会保留。")
                    .setNegativeButton("取消", null).setPositiveButton("删除") { _, _ -> work({ ReviewStore.deleteGroup(activity, group.id) }) { sheet.dismiss(); dialog.dismiss() } }.show()
            }
        } }
    }
    private fun createGroup(cards: List<ReviewCard>, selectedWord: String = "", saved: () -> Unit = {}) {
        if (cards.size < 2) { Toast.makeText(activity, "至少收藏两个词后才能建立易混词组", Toast.LENGTH_SHORT).show(); return }
        val choices = BooleanArray(cards.size) { cards[it].entry.word.equals(selectedWord, true) }
        val dialog = AlertDialog.Builder(activity).setTitle("选择至少两个易混词")
            .setMultiChoiceItems(cards.map { it.entry.word }.toTypedArray(), choices) { _, index, checked -> choices[index] = checked }
            .setNegativeButton("取消", null).setPositiveButton("下一步", null).create()
        dialogs.add(dialog); dialog.setOnDismissListener { dialogs.remove(dialog) }; dialog.show()
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val words = cards.filterIndexed { i, _ -> choices[i] }.map { it.entry.word }
            if (words.size < 2) Toast.makeText(activity, "请至少选择两个词", Toast.LENGTH_SHORT).show()
            else {
                dialog.dismiss()
                val body = column()
                val title = BrandUi.field(activity, "词组名称").apply { setText(words.take(4).joinToString(" / ")) }; body.addView(title, space())
                val note = BrandUi.field(activity, "这几个词有什么区别？", false).apply { minLines = 3 }; body.addView(note, space())
                val edit = show("新建易混词组", body)
                button(body, "保存词组", BrandUi.Forest) {
                    val name = title.text.toString().trim(); val value = note.text.toString()
                    if (name.isEmpty()) title.error = "请输入词组名称" else work({ ReviewStore.saveGroup(activity, name, value, words) }) { edit.dismiss(); saved() }
                }
            }
        }
    }
    fun pause() { saveSession?.invoke(); sessionDialog?.dismiss() }
    fun awaitClosed() { check(io.awaitTermination(30,java.util.concurrent.TimeUnit.SECONDS)) { "上一个学习操作尚未结束，请稍后重试" } }
    fun close() {
        closing = true
        saveSession?.invoke()
        dialogs.toList().forEach { it.dismiss() }
        closed = true; io.shutdown()
    }
}

package com.pocketwords.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionConfig
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast

/** Capture the source app first; the vocabulary activity is never a capture trampoline. */
internal object ScreenCaptureFlow {
    fun request(context: Context) {
        if (CaptureService.sessionActive) {
            context.startService(Intent(context, CaptureService::class.java).setAction(CaptureService.ACTION_CAPTURE_ONCE))
        } else {
            context.startActivity(Intent(context, ScreenCaptureConsentActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP))
        }
    }
    fun consentIntent(context: Context): Intent {
        val manager = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        // Capture the display, rather than accidentally granting only PocketWords' app window.
        return if (Build.VERSION.SDK_INT >= 34) manager.createScreenCaptureIntent(MediaProjectionConfig.createConfigForDefaultDisplay())
        else manager.createScreenCaptureIntent()
    }
}

/** A separate, transparent task hosts system consent, then immediately returns to the source. */
class ScreenCaptureConsentActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState == null) {
            try { startActivityForResult(ScreenCaptureFlow.consentIntent(this), REQUEST_CAPTURE) }
            catch (_: RuntimeException) {
                Toast.makeText(this, "无法请求屏幕共享，请稍后重试。", Toast.LENGTH_LONG).show(); finish()
            }
        }
    }
    @Deprecated("MediaProjection consent uses an activity result")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQUEST_CAPTURE) return
        try {
            if (resultCode == RESULT_OK && data != null) {
                val service = Intent(this, CaptureService::class.java)
                    .putExtra(CaptureService.EXTRA_RESULT_CODE, resultCode)
                    .putExtra(CaptureService.EXTRA_RESULT_DATA, data)
                startForegroundService(service)
            } else Toast.makeText(this, "已取消屏幕取词，再点悬浮按钮可以重新授权。", Toast.LENGTH_SHORT).show()
        } catch (_: RuntimeException) {
            Toast.makeText(this, "无法启动屏幕取词，请重新授权后重试。", Toast.LENGTH_LONG).show()
        } finally { finish() }
    }
    companion object { internal const val REQUEST_CAPTURE = 4102 }
}

/** Reuses the lookup controls in a transient task, without exposing the vocabulary home page. */
class ScreenLookupActivity : MainActivity() {
    override fun onResume() {
        super.onResume()
        OverlayService.setLookupVisible(this, true)
    }
    override fun onStop() {
        OverlayService.setLookupVisible(this, false)
        super.onStop()
        // Switching back to the source must not leave an old result task intercepting the next lookup.
        if (!isChangingConfigurations) finish()
    }
    override fun onDestroy() {
        super.onDestroy()
        if (!isChangingConfigurations) {
            runCatching {
                val file = intent?.getStringExtra(CaptureService.EXTRA_IMAGE_PATH)?.let { java.io.File(it) }
                if (file != null && file.parentFile?.canonicalPath == cacheDir.canonicalPath && file.name.startsWith("screen-")) file.delete()
            }
        }
    }
}

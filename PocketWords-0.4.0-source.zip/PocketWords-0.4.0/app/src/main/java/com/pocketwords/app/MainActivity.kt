package com.pocketwords.app

import android.app.Activity
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.ExifInterface
import android.media.projection.MediaProjectionManager
import android.graphics.Bitmap
import android.graphics.Matrix
import android.graphics.BitmapFactory
import org.json.JSONArray
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.provider.MediaStore
import java.io.File
import java.io.FileOutputStream
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.JSONObject
import android.view.Gravity
import android.view.View
import android.widget.BaseAdapter
import android.widget.ListView
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.text.Editable
import android.text.TextWatcher
import java.util.concurrent.Executors
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.PopupMenu
import android.widget.ScrollView
import android.view.WindowManager
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.content.ContextCompat

class MainActivity : LookupActivity() {
    private lateinit var wordList: ListView
    private lateinit var countLabel: TextView
    private lateinit var countBadge: TextView
    private lateinit var screenAction: LinearLayout
    private lateinit var wordsAdapter: BaseAdapter
    private val visibleWords = mutableListOf<WordEntry>()
    private var searchQuery = ""
    private var loadedWords = emptyList<WordEntry>()
    private var loadedCards = emptyList<ReviewCard>()
    private var bookFilter = BookFilter.ALL
    private var bookSort = BookSort.NEWEST
    private lateinit var bookToolsButton: Button
    private var backupProgress: AlertDialog? = null
    private var refreshGeneration = 0
    private var refreshBookOnResume = false
    private var backupBusy = false
    private var rescueExport = false
    private var pendingRestore: FullBackup.Prepared? = null
    private var restoreDialog: AlertDialog? = null
    private var reviewUi: ReviewUi? = null
    private lateinit var reviewStatus: TextView
    private fun reviews() = reviewUi ?: ReviewUi(this) { refreshWords() }.also { reviewUi = it }

    private val captureReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) { if (::screenAction.isInitialized) refreshOverlayLabel() }
    }
    override fun onWordsChanged() { refreshWords() }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!restorationReady) return
        initializeHome()
        savedInstanceState?.let {
            bookFilter = BookFilter.valueOf(it.getString("book_filter", BookFilter.ALL.name))
            bookSort = BookSort.valueOf(it.getString("book_sort", BookSort.NEWEST.name))
        }

    }

    override fun onRestorationComplete() { initializeHome() }
    private fun initializeHome() {
        buildUi(); prepareDictionary(); refreshWords()
        val filter = IntentFilter(OverlayService.ACTION_STATE_CHANGED)
        ContextCompat.registerReceiver(this, captureReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
        refreshOverlayLabel()
    }
    private fun prepareDictionary() {
        background({ WordStore.prepareDictionary(applicationContext) }) { refreshWords() }
    }
    override fun onSaveInstanceState(outState: Bundle) {
        outState.putString("book_filter", bookFilter.name); outState.putString("book_sort", bookSort.name)
        super.onSaveInstanceState(outState)
    }
    private fun beginBackup(message: String) {
        backupBusy = true
        backupProgress = AlertDialog.Builder(this).setTitle(message).setMessage("正在处理，请稍候…")
            .setView(android.widget.ProgressBar(this)).setCancelable(false).show()
    }
    private fun backupStep(message: String) { runOnUiThread { backupProgress?.setMessage(message) } }
    private fun endBackup() { backupBusy = false; backupProgress?.dismiss(); backupProgress = null }
    override fun onResume() {
        super.onResume()
        if (::screenAction.isInitialized) refreshOverlayLabel()
        if (refreshBookOnResume) { refreshBookOnResume = false; refreshWords() }
    }

    override fun onPause() {
        if (!isScreenLookup) refreshBookOnResume = true
        reviewUi?.pause()
        super.onPause()
    }

    private fun refreshOverlayLabel() {
        val title = if (OverlayService.active) "关闭屏幕取词" else "开启屏幕取词"
        (screenAction.getChildAt(1) as TextView).text = title
        screenAction.contentDescription = title
    }

    override fun onDestroy() {
        try { unregisterReceiver(captureReceiver) } catch (_: Exception) {}
        reviewUi?.close()
        restoreDialog?.dismiss(); pendingRestore?.close(); backupProgress?.dismiss()
        super.onDestroy()
    }

    private fun buildUi() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = android.graphics.Color.TRANSPARENT
        window.navigationBarColor = if (Build.VERSION.SDK_INT >= 27) BrandUi.Paper else BrandUi.Forest
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE or WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN)
        val root = FrameLayout(this).apply {
            setBackgroundColor(BrandUi.Paper); isFocusableInTouchMode = true
        }
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout() or WindowInsetsCompat.Type.ime())
            view.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }
        wordList = ListView(this).apply {
            id = R.id.word_list
            divider = null; dividerHeight = 0; isVerticalScrollBarEnabled = false
            setSelector(android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT))
            overScrollMode = View.OVER_SCROLL_NEVER
            itemsCanFocus = true
        }
        val header = column().apply { setPadding(dp(20), dp(16), dp(20), dp(8)) }
        val brand = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        brand.addView(ImageView(this).apply {
            setImageResource(R.mipmap.ic_launcher); contentDescription = "PocketWords 折页取词"
            isFocusable = true
            setOnClickListener {
                AlertDialog.Builder(this@MainActivity).setMessage("祝你开心，幸福")
                    .setPositiveButton("好的", null).show()
            }
        }, LinearLayout.LayoutParams(dp(46), dp(46)).apply { marginEnd = dp(12) })
        val title = column()
        title.addView(BrandUi.label(this, "随身单词本", 21f, bold = true))
        title.addView(BrandUi.label(this, "PocketWords", 11f, BrandUi.Muted).apply { letterSpacing = 0.08f }, lp(top = 5))
        brand.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bookToolsButton = BrandUi.compactAction(this, "更多", BrandUi.Tint).apply {
            tag = "book_tools"; contentDescription = "更多：筛选、排序及设置"
            setPadding(dp(10), dp(8), dp(10), dp(8)); setOnClickListener { bookTools() }
        }
        brand.addView(bookToolsButton)
        header.addView(brand, lp())

        screenAction = BrandUi.action(this,"开启屏幕取词",R.drawable.ic_capture).apply {
            minimumHeight = dp(80)
            setPadding(dp(22), dp(20), dp(22), dp(20))
            background = BrandUi.ripple(this@MainActivity, BrandUi.Forest, 22)
            getChildAt(0).layoutParams = (getChildAt(0).layoutParams as LinearLayout.LayoutParams).apply {
                width = dp(30); height = dp(30); marginEnd = dp(12)
            }
            (getChildAt(1) as TextView).textSize = 19f
            tag="screen_lookup"; setOnClickListener { enableOverlay() }
        }
        header.addView(screenAction,lp(top=12))
        val quick = LinearLayout(this)
        quick.addView(quickAction("拍照查词","点词或框选翻译",R.drawable.ic_camera) { takePhotoForLookup() },
            LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1f).apply { marginEnd=dp(10) })
        quick.addView(quickAction("今日复习","默认混合练习 · 10词",R.drawable.ic_restore) { reviews().startToday() }.apply { tag="review_today" },
            LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1f))
        header.addView(quick,lp(top=12))
        reviewStatus=BrandUi.label(this,"根据收藏安排今日复习",12f,BrandUi.Muted)
        header.addView(reviewStatus,lp(top=8))
        val secondary = LinearLayout(this)
        fun tool(text: String, tag: String, action: () -> Unit) = BrandUi.compactAction(this, text).apply {
            this.tag = tag; minimumHeight = dp(48); minHeight = dp(48)
            setOnClickListener { action() }
        }
        secondary.addView(tool("复习与统计", "review_open") { reviews().open() },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = dp(8) })
        secondary.addView(tool("整句翻译", "sentence_translate") { showSentenceTranslation("") },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = dp(8) })
        secondary.addView(tool("＋ 记词", "word_add") { showAddDialog("") },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(secondary, lp(top = 12))

        val sectionTitle = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        countLabel = BrandUi.label(this, "我的单词本", 19f, bold = true)
        sectionTitle.addView(countLabel)
        countBadge = BrandUi.label(this, "0 词", 11f).apply {
            background = BrandUi.shape(this@MainActivity, BrandUi.Tint, 10)
            setPadding(dp(8), dp(4), dp(8), dp(4)); gravity = Gravity.CENTER
        }
        sectionTitle.addView(countBadge, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginStart = dp(8) })
        sectionTitle.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        sectionTitle.addView(BrandUi.compactAction(this, "备份与恢复", BrandUi.Tint).apply {
            textSize = 12f
            tag = "backup_open"
            setOnClickListener { showBackupDialog() }
        })
        header.addView(sectionTitle, lp(top = 18))
        val searchRow = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; background = BrandUi.shape(this@MainActivity, BrandUi.Cream, 16, BrandUi.Line)
            setPadding(dp(14), 0, dp(8), 0)
        }
        searchRow.addView(BrandUi.icon(this, R.drawable.ic_search, BrandUi.Muted), LinearLayout.LayoutParams(dp(19), dp(19)))
        val search = BrandUi.field(this, "查找英文或中文释义").apply {
            id = R.id.word_search; tag = "word_search"; background = null; textSize = 14f
            setPadding(dp(10), dp(12), dp(4), dp(12))
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { searchQuery = s.toString(); filterWords() }
                override fun afterTextChanged(s: Editable?) {}
            })
        }
        searchRow.addView(search, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(searchRow, lp(top = 4))
        wordList.addHeaderView(header, null, false)
        val footer = column().apply { setPadding(dp(20), dp(4), dp(20), dp(24)) }
        footer.addView(BrandUi.label(this, "悬浮按钮：轻点取词 · 拖动移位 · 长按关闭", 10f, BrandUi.Muted).apply { gravity = Gravity.CENTER }, lp(top = 15))
        wordList.addFooterView(footer, null, false)
        wordsAdapter = object : BaseAdapter() {
            override fun getCount() = visibleWords.size.coerceAtLeast(1)
            override fun getItem(position: Int): WordEntry? = visibleWords.getOrNull(position)
            override fun getItemId(position: Int) = position.toLong()
            override fun isEnabled(position: Int) = false
            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                if (visibleWords.isEmpty()) return emptyWordsView()
                val entry = visibleWords[position]
                val holder = (convertView?.tag as? WordRowHolder) ?: createWordRow()
                holder.word.text = entry.word
                holder.meaning.text = entry.meaning
                holder.card.setOnClickListener { showWordDetails(entry) }
                holder.menu.setOnClickListener {
                    PopupMenu(this@MainActivity, holder.menu).apply {
                        menu.add("编辑释义").setOnMenuItemClickListener { editMeaning(entry.word, entry.meaning); true }
                        menu.add("记忆档案与音标").setOnMenuItemClickListener { reviews().word(entry.word); true }
                        menu.add("删除单词").setOnMenuItemClickListener { confirmDeleteWord(entry.word); true }
                    }.show()
                }
                return holder.root
            }
        }
        wordList.adapter = wordsAdapter
        root.addView(wordList, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)
        WindowCompat.getInsetsController(window, root).apply {
            isAppearanceLightStatusBars = !BrandUi.dark; isAppearanceLightNavigationBars = !BrandUi.dark
        }
        ViewCompat.requestApplyInsets(root)
        root.requestFocus()
    }

    private fun quickAction(title: String, description: String, icon: Int, click: () -> Unit): View = column().apply {
        background = BrandUi.ripple(this@MainActivity, BrandUi.Cream, 20, BrandUi.Line)
        setPadding(dp(14), dp(12), dp(12), dp(12)); minimumHeight = dp(72)
        isClickable = true; isFocusable = true; contentDescription = "$title，$description"
        val row = LinearLayout(this@MainActivity).apply { gravity = Gravity.CENTER_VERTICAL }
        row.addView(BrandUi.icon(this@MainActivity, icon), LinearLayout.LayoutParams(dp(20), dp(20)).apply { marginEnd = dp(8) })
        row.addView(BrandUi.label(this@MainActivity, title, 14f, bold = true))
        addView(row)
        addView(BrandUi.label(this@MainActivity, description, 10f, BrandUi.Muted), lp(top = 8))
        setOnClickListener { click() }
    }

    private fun showBackupDialog() {
        val body=column().apply { setPadding(dp(18),0,dp(18),dp(12)) }
        body.addView(BrandUi.label(this,"完整备份包含单词、复习进度、原句、笔记、音标、词组和图片。",12f,BrandUi.Muted),lp(top=8))
        body.addView(BrandUi.action(this,"保存完整备份",R.drawable.ic_backup).apply { tag="backup_full_export"; setOnClickListener { exportFullBackup() } },lp(top=12))
        body.addView(BrandUi.action(this,"恢复完整备份",R.drawable.ic_restore,BrandUi.SoftGreen,BrandUi.Forest).apply { tag="backup_full_import"; setOnClickListener { importFullBackup() } },lp(top=8))
        body.addView(BrandUi.compactAction(this, "图片缺失时：导出救援备份").apply {
            setOnClickListener {
                AlertDialog.Builder(this@MainActivity).setTitle("保存救援备份？")
                    .setMessage("保留单词与学习资料，跳过已缺失的图片。备份内会记录缺失数量，不会修改本机资料。")
                    .setNegativeButton("取消", null).setPositiveButton("选择保存位置") { _, _ -> exportFullBackup(rescue = true) }.show()
            }
        }, lp(top = 8))
        val lastBackup = getSharedPreferences("backup_status", MODE_PRIVATE).getLong("last", 0)
        body.addView(BrandUi.label(this, if (lastBackup == 0L) "尚无完整备份记录" else "上次保存：${java.text.DateFormat.getDateTimeInstance().format(java.util.Date(lastBackup))}", 12f), lp(top = 8))
        body.addView(BrandUi.label(this,"CSV 仅交换单词和释义，导入会合并并跳过重复词。",12f,BrandUi.Muted),lp(top=16))
        body.addView(BrandUi.compactAction(this,"导出词表 CSV").apply { tag="backup_export"; setOnClickListener { exportCsv() } },lp(top=8))
        body.addView(BrandUi.compactAction(this,"导入词表 CSV").apply { tag="backup_import"; setOnClickListener { importCsv() } },lp(top=8))
        AlertDialog.Builder(this).setTitle("备份与恢复").setView(ScrollView(this).apply { addView(body) }).setNegativeButton("关闭",null).show()
    }
    private fun backupAvailable(): Boolean {
        if (!backupBusy) return true
        Toast.makeText(this,"正在处理备份，请稍候",Toast.LENGTH_SHORT).show();return false
    }
    private fun exportFullBackup(rescue: Boolean = false) {
        if (!backupAvailable()) return
        rescueExport = rescue
        startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type="application/zip"
            putExtra(Intent.EXTRA_TITLE,"PocketWords-完整备份-${java.time.LocalDate.now()}.zip")
        }, REQUEST_FULL_EXPORT)
    }
    private fun importFullBackup() {
        if (!backupAvailable()) return
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type="*/*"; putExtra(Intent.EXTRA_MIME_TYPES,arrayOf("application/zip","application/octet-stream"))
        }, REQUEST_FULL_IMPORT)
    }
    private fun emptyWordsView(): View = FrameLayout(this).apply {
        setPadding(dp(20), dp(6), dp(20), dp(14))
        val card = column().apply {
            gravity = Gravity.CENTER; background = BrandUi.shape(this@MainActivity, BrandUi.Cream, 22, BrandUi.Line)
            setPadding(dp(20), dp(22), dp(20), dp(20))
            addView(ImageView(this@MainActivity).apply {
                setImageResource(R.drawable.ic_launcher_monochrome); setColorFilter(BrandUi.Muted); alpha = 0.55f
                importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            }, LinearLayout.LayoutParams(dp(58), dp(58)))
            addView(BrandUi.label(this@MainActivity, when {
                searchQuery.isBlank() -> "把第一个生词收进口袋"
                else -> "没有找到匹配的单词"
            }, 15f, bold = true).apply { gravity = Gravity.CENTER }, lp(top = 6))
            addView(BrandUi.label(this@MainActivity, when {
                searchQuery.isBlank() -> "从屏幕或书页中，收集你想记住的词。"
                else -> "试试其他英文拼写或中文释义。"
            }, 11f, BrandUi.Muted).apply { gravity = Gravity.CENTER }, lp(top = 8))
            if (searchQuery.isBlank()) addView(BrandUi.label(this@MainActivity, "+ 记下第一个单词", 12f, BrandUi.Forest, true).apply {
                gravity = Gravity.CENTER; minimumHeight = dp(44); isClickable = true; isFocusable = true
                setOnClickListener { showAddDialog("") }
            }, lp(top = 6))
        }
        addView(card, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    }

    private data class WordRowHolder(val root: FrameLayout, val card: LinearLayout, val word: TextView, val meaning: TextView, val menu: ImageView)
    private fun createWordRow(): WordRowHolder {
        val root = FrameLayout(this).apply { setPadding(dp(20), dp(4), dp(20), dp(4)) }
        val card = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; background = BrandUi.ripple(this@MainActivity, BrandUi.Cream, 16, BrandUi.Line)
            setPadding(dp(14), dp(10), dp(14), dp(10)); isClickable = true; isFocusable = true
        }
        val texts = column()
        val word = BrandUi.label(this, "", 18f, bold = true).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END }
        val meaning = BrandUi.label(this, "", 12f, BrandUi.Muted).apply { maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END }
        texts.addView(word); texts.addView(meaning, lp(top = 4))
        card.addView(texts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val menu = BrandUi.icon(this, R.drawable.ic_more, BrandUi.Muted).apply {
            setPadding(dp(11), dp(11), dp(11), dp(11)); contentDescription = "单词操作：编辑或删除"
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_YES; isClickable = true; isFocusable = true
        }
        card.addView(menu, LinearLayout.LayoutParams(dp(48), dp(48)))
        root.addView(card, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        return WordRowHolder(root, card, word, meaning, menu).also { root.tag = it }
    }

    private fun showWordDetails(entry: WordEntry) {
        reviews().word(entry.word)
    }

    private fun enableOverlay() {
        if (OverlayService.active) {
            stopService(Intent(this, CaptureService::class.java))
            stopService(Intent(this, OverlayService::class.java))
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            Toast.makeText(this, "请允许‘随身单词本’显示在其他应用上层，然后返回再点一次。", Toast.LENGTH_LONG).show()
            return
        }
        startService(Intent(this, OverlayService::class.java))
        Toast.makeText(this, "正在开启屏幕取词：轻点取词，拖动移位，长按关闭。", Toast.LENGTH_LONG).show()
    }

    @Deprecated("Android screen-capture consent uses activity result")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == RESULT_OK && (requestCode == REQUEST_FULL_EXPORT || requestCode == REQUEST_FULL_IMPORT)) {
            val uri=data?.data ?: return
            beginBackup(if (requestCode == REQUEST_FULL_EXPORT) "正在保存完整备份" else "正在读取备份")
            if (requestCode == REQUEST_FULL_EXPORT) background({
                contentResolver.openOutputStream(uri,"wt")?.use { FullBackup.write(applicationContext,it, rescue = rescueExport, progress = ::backupStep) } ?: error("无法写入备份文件")
            }, failed={endBackup()}) { endBackup(); rescueExport = false
                getSharedPreferences("backup_status", MODE_PRIVATE).edit().putLong("last", System.currentTimeMillis()).apply()
                Toast.makeText(this,"备份已保存",Toast.LENGTH_LONG).show() }
            else background({ contentResolver.openInputStream(uri)?.use { FullBackup.read(applicationContext,it, ::backupStep) } ?: error("无法打开备份") },discard={it.close()},failed={endBackup()}) { prepared ->
                backupProgress?.dismiss(); backupProgress = null
                pendingRestore=prepared
                var restoring=false
                restoreDialog=AlertDialog.Builder(this).setTitle("恢复 ${prepared.words.size} 个词的完整资料？")
                    .setMessage("这会替换本机单词和学习记录。取消则保留现有资料。建议先保存当前完整备份。${if (prepared.missingImages > 0) "\n此为救援备份，缺失 ${prepared.missingImages} 张原图。" else ""}")
                    .setNegativeButton("取消",null).setPositiveButton("恢复") { _,_ ->
                        restoring=true; pendingRestore=null; beginBackup("正在恢复完整资料")
                        val previousReview=reviewUi; previousReview?.close(); reviewUi=null
                        background({ try { previousReview?.awaitClosed();FullBackup.restore(applicationContext,prepared) } finally { prepared.close() } },failed={endBackup()}) {
                            endBackup();refreshWords(); Toast.makeText(this,"完整资料已恢复",Toast.LENGTH_LONG).show()
                        }
                    }.create().apply { setOnDismissListener { if (!restoring) { prepared.close();endBackup() }; pendingRestore=null; restoreDialog=null }; show() }
            }
            return
        }
        if (resultCode == RESULT_OK && (requestCode == REQUEST_IMPORT || requestCode == REQUEST_EXPORT)) {
            val uri = data?.data ?: return
            if (requestCode == REQUEST_EXPORT) {
                background({
                    val entries = WordStore.resolvedEntries(applicationContext)
                    contentResolver.openOutputStream(uri, "wt")?.bufferedWriter(Charsets.UTF_8)?.use { WordCsv.write(entries, it) }
                        ?: error("无法写入所选文件。")
                }) { Toast.makeText(this, "词表 CSV 已导出（仅单词和释义）", Toast.LENGTH_LONG).show() }
            } else {
                background({
                    contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { WordCsv.read(it) }
                        ?: error("无法读取所选文件。")
                }) { entries ->
                    AlertDialog.Builder(this).setTitle("导入 ${entries.size} 个单词？")
                        .setMessage("将合并到现有单词本，重复单词会跳过，已有释义会保留。")
                        .setNegativeButton("取消", null)
                        .setPositiveButton("恢复单词") { _, _ ->
                            background({ WordStore.importEntries(applicationContext, entries) }) { result ->
                                Toast.makeText(this, "已导入 ${result.added} 个单词，跳过 ${result.skipped} 个重复项。", Toast.LENGTH_LONG).show()
                                refreshWords()
                            }
                        }.show()
                }
            }
        }
    }

    private fun refreshWords() {
        if (!::wordList.isInitialized || isDestroyed || isFinishing) return
        val generation = ++refreshGeneration
        background({
            val all = WordStore.resolvedEntries(applicationContext)
            Triple(all, ReviewStore.overview(applicationContext, all), ReviewStore.cards(applicationContext, all, details = false))
        }) { (all, overview, cards) ->
            if (generation != refreshGeneration) return@background
            loadedWords = all; loadedCards = cards
            reviewStatus.text = if (all.isEmpty()) "收藏单词后，即可离线认词、拼写和原句填空" else "${overview.first} 词待复习 · ${overview.second} 词已掌握"
            filterWords()
        }
    }

    private fun filterWords() {
        if (!::countLabel.isInitialized) return
        val query = searchQuery.trim()
        val matches = WordBookQuery.apply(loadedCards, query, bookFilter, bookSort, System.currentTimeMillis())
        renderWords(matches, loadedWords.size)
    }

    private fun renderWords(words: List<WordEntry>, total: Int) {
        countLabel.text = if (searchQuery.isNotBlank()) "查找结果" else if (bookFilter == BookFilter.ALL) "我的单词本" else bookFilter.title
        countBadge.text = when {
            searchQuery.isBlank() -> "$total 词"
            else -> "${words.size} / $total"
        }
        visibleWords.clear(); visibleWords.addAll(words)
        wordsAdapter.notifyDataSetChanged()
    }

    private fun bookTools() {
        AlertDialog.Builder(this).setTitle("更多").setItems(arrayOf("筛选单词", "排序方式", "批量操作", "外观", "发音与语音包", "重新准备词典")) { _, which ->
            when (which) {
                0 -> AlertDialog.Builder(this).setTitle("筛选单词").setSingleChoiceItems(BookFilter.entries.map { it.title }.toTypedArray(), bookFilter.ordinal) { d, index ->
                    bookFilter = BookFilter.entries[index]; filterWords(); d.dismiss()
                }.show()
                1 -> AlertDialog.Builder(this).setTitle("排序方式").setSingleChoiceItems(BookSort.entries.map { it.title }.toTypedArray(), bookSort.ordinal) { d, index ->
                    bookSort = BookSort.entries[index]; filterWords(); d.dismiss()
                }.show()
                2 -> batchWords()
                3 -> AlertDialog.Builder(this).setTitle("外观").setSingleChoiceItems(arrayOf("跟随系统", "浅色", "深色"), getSharedPreferences("appearance", MODE_PRIVATE).getInt("theme", 0)) { d, index ->
                    getSharedPreferences("appearance", MODE_PRIVATE).edit().putInt("theme", index).apply(); d.dismiss(); recreate()
                }.show()
                4 -> showPronunciationSettings()
                5 -> prepareDictionary()
            }
        }.setNegativeButton("关闭", null).show()
    }
    private fun batchWords() {
        val entries = visibleWords.toList()
        if (entries.isEmpty()) { Toast.makeText(this, "当前没有可操作的单词", Toast.LENGTH_SHORT).show(); return }
        val checked = BooleanArray(entries.size)
        val dialog = AlertDialog.Builder(this).setTitle("选择单词")
            .setMultiChoiceItems(entries.map { it.word }.toTypedArray(), checked) { _, i, selected -> checked[i] = selected }
            .setNegativeButton("取消", null).setPositiveButton("选择操作", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val words = entries.filterIndexed { i, _ -> checked[i] }.map { it.word }
                if (words.isEmpty()) { Toast.makeText(this, "请至少选择一个词", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
                AlertDialog.Builder(this).setTitle("操作 ${words.size} 个词").setItems(arrayOf("暂停复习", "恢复复习", "加入易混词组", "删除单词及学习记录")) { _, action ->
                    if (action == 2) {
                        if (words.size < 2) Toast.makeText(this, "请至少选择两个词", Toast.LENGTH_SHORT).show()
                        else {
                            val title = BrandUi.field(this, "词组名称")
                            AlertDialog.Builder(this).setTitle("新建易混词组").setView(title).setNegativeButton("取消", null)
                                .setPositiveButton("保存") { _, _ ->
                                    val name = title.text.toString().trim().ifEmpty { words.take(3).joinToString(" / ") }
                                    background({ ReviewStore.saveGroup(applicationContext, name, "", words) }) { dialog.dismiss() }
                                }.show()
                        }
                    } else {
                        val apply = {
                            background({
                                ReviewStore.atomic(applicationContext) {
                                    words.forEach { if (action == 3) WordStore.delete(applicationContext, it) else ReviewStore.setPaused(applicationContext, it, action == 0) }
                                }
                                ReviewStore.cleanupImages(applicationContext)
                            }) { dialog.dismiss(); refreshWords() }
                        }
                        if (action == 3) AlertDialog.Builder(this).setTitle("删除 ${words.size} 个词？").setMessage("将删除所选词、阅读记录与复习历史。请先备份重要资料。")
                            .setNegativeButton("取消", null).setPositiveButton("删除") { _, _ -> apply() }.show()
                        else apply()
                    }
                }.show()
            }
        }
        dialog.show()
    }

    private fun confirmDeleteWord(word: String) {
        AlertDialog.Builder(this)
            .setTitle("删除单词？")
            .setMessage("确定要删除「$word」吗？将同时删除这个词的阅读记录和复习历史，请先备份重要资料。")
            .setNegativeButton("返回", null)
            .setPositiveButton("删除") { _, _ ->
                background({ WordStore.delete(applicationContext, word); ReviewStore.cleanupImages(applicationContext) }) { refreshWords() }
            }
            .show()
    }

    private fun editMeaning(word: String, current: String) {
        val input = BrandUi.field(this, "填写你想记住的中文释义", false).apply { setText(current); minLines = 3 }
        AlertDialog.Builder(this).setTitle(word)
            .setView(column().apply { setPadding(dp(20), dp(4), dp(20), dp(8)); addView(input) })
            .setNegativeButton("取消", null)
            .setPositiveButton("保存释义") { _, _ ->
                val meaning = input.text.toString().trim()
                background({ WordStore.updateMeaning(applicationContext, word, meaning) }) { refreshWords() }
            }.show()
    }

    private fun importCsv() {
        if (!backupAvailable()) return
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("text/csv", "text/comma-separated-values", "text/plain", "application/octet-stream"))
        }, REQUEST_IMPORT)
    }

    private fun exportCsv() {
        if (!backupAvailable()) return
        startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "text/csv"
            putExtra(Intent.EXTRA_TITLE, "PocketWords-词表-${java.time.LocalDate.now()}.csv")
        }, REQUEST_EXPORT)
    }


    companion object {
        private const val REQUEST_FULL_EXPORT = 4107
        private const val REQUEST_FULL_IMPORT = 4108
        private const val REQUEST_IMPORT = 4104
        private const val REQUEST_EXPORT = 4105
    }
}

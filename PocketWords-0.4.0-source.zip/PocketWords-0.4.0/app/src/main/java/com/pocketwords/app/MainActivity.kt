package com.pocketwords.app

import android.app.Activity
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.ExifInterface
import android.media.projection.MediaProjectionManager
import android.graphics.Bitmap
import android.graphics.Matrix
import android.graphics.BitmapFactory
import org.json.JSONArray
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.provider.MediaStore
import java.io.File
import java.io.FileOutputStream
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.JSONObject
import android.view.Gravity
import android.view.View
import android.widget.BaseAdapter
import android.widget.ListView
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.text.Editable
import android.text.TextWatcher
import java.util.concurrent.Executors
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.PopupMenu
import android.widget.ScrollView
import android.view.WindowManager
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.content.ContextCompat

class MainActivity : Activity() {
    private lateinit var wordList: ListView
    private lateinit var countLabel: TextView
    private lateinit var countBadge: TextView
    private lateinit var screenAction: LinearLayout
    private lateinit var wordsAdapter: BaseAdapter
    private val visibleWords = mutableListOf<WordEntry>()
    private var photoLookupUri: Uri? = null
    private lateinit var dictionaryStatus: TextView
    private val io = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())
    private var searchQuery = ""
    private var loadedWords = emptyList<WordEntry>()
    private var refreshGeneration = 0
    private var photoBusy = false
    private val sentenceDialogs = mutableSetOf<SentenceTranslationDialog>()
    private enum class ImageSource { PHOTO, SCREEN }

    private fun <T> background(work: () -> T, discard: (T) -> Unit = {}, failed: () -> Unit = {}, done: (T) -> Unit) {
        io.execute {
            val result = runCatching(work)
            mainHandler.post {
                if (isFinishing || isDestroyed) result.onSuccess(discard)
                else result.fold(done) {
                    failed()
                    Toast.makeText(this, it.message ?: "操作失败，请重试。", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private val captureReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val text = intent?.getStringExtra(CaptureService.EXTRA_TEXT).orEmpty()
            val imagePath = intent?.getStringExtra(CaptureService.EXTRA_IMAGE_PATH).orEmpty()
            val boxes = intent?.getStringExtra(CaptureService.EXTRA_WORD_BOXES).orEmpty()
            val width = intent?.getIntExtra(CaptureService.EXTRA_IMAGE_WIDTH, 0) ?: 0
            val height = intent?.getIntExtra(CaptureService.EXTRA_IMAGE_HEIGHT, 0) ?: 0
            runOnUiThread { showWordSelection(text, imagePath, boxes, width, height) }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        photoLookupUri = savedInstanceState?.getString(KEY_PHOTO_LOOKUP_URI)?.let { Uri.parse(it) }
        buildUi()
        background({
            runCatching { WordStore.prepareDictionary(applicationContext) }.isSuccess
        }) { ready ->
            dictionaryStatus.text = if (ready) "离线可用" else "词典暂不可用"
        }
        refreshWords()
        val filter = IntentFilter(CaptureService.ACTION_OCR_RESULT)
        ContextCompat.registerReceiver(this, captureReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
        handleIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        if (::screenAction.isInitialized) refreshOverlayLabel()
    }

    private fun refreshOverlayLabel() {
        val title = if (OverlayService.active) "悬浮取词已开启" else "开启屏幕取词"
        (screenAction.getChildAt(1) as TextView).text = title
        screenAction.contentDescription = title
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        photoLookupUri?.let { outState.putString(KEY_PHOTO_LOOKUP_URI, it.toString()) }
    }

    override fun onDestroy() {
        try { unregisterReceiver(captureReceiver) } catch (_: Exception) {}
        sentenceDialogs.toList().forEach { it.dismiss() }
        io.shutdown()
        super.onDestroy()
    }

    private fun buildUi() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = android.graphics.Color.TRANSPARENT
        window.navigationBarColor = if (Build.VERSION.SDK_INT >= 27) BrandUi.Paper else BrandUi.Forest
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE or WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN)
        val root = FrameLayout(this).apply {
            setBackgroundColor(BrandUi.Paper); isFocusableInTouchMode = true
        }
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout() or WindowInsetsCompat.Type.ime())
            view.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }
        wordList = ListView(this).apply {
            id = R.id.word_list
            divider = null; dividerHeight = 0; isVerticalScrollBarEnabled = false
            setSelector(android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT))
            overScrollMode = View.OVER_SCROLL_NEVER
            itemsCanFocus = true
        }
        val header = column().apply { setPadding(dp(20), dp(16), dp(20), dp(8)) }
        val brand = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        brand.addView(ImageView(this).apply {
            setImageResource(R.mipmap.ic_launcher); contentDescription = "PocketWords 折页取词"
            isFocusable = true
            setOnClickListener {
                AlertDialog.Builder(this@MainActivity).setMessage("祝你开心，幸福")
                    .setPositiveButton("好的", null).show()
            }
        }, LinearLayout.LayoutParams(dp(46), dp(46)).apply { marginEnd = dp(12) })
        val title = column()
        title.addView(BrandUi.label(this, "随身单词本", 21f, bold = true))
        title.addView(BrandUi.label(this, "PocketWords", 11f, BrandUi.Muted).apply { letterSpacing = 0.08f }, lp(top = 5))
        brand.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        dictionaryStatus = BrandUi.label(this, "准备词典中", 11f).apply {
            gravity = Gravity.CENTER; background = BrandUi.ripple(this@MainActivity, BrandUi.Tint, 20)
            setPadding(dp(10), dp(9), dp(10), dp(9)); isClickable = true; isFocusable = true
            contentDescription = "离线词典状态"
            setOnClickListener {
                AlertDialog.Builder(this@MainActivity).setTitle("离线词典")
                    .setMessage(if (text == "离线可用") "词典已就绪，断网也能查释义。拍照和屏幕取词也在手机上完成。" else "词典准备完成后即可离线查词。暂不可用时仍能手动记词和编辑释义，可稍后重新打开应用重试。")
                    .setPositiveButton("知道了", null).show()
            }
        }
        brand.addView(dictionaryStatus)
        header.addView(brand, lp())

        val hero = column().apply {
            background = BrandUi.shape(this@MainActivity, BrandUi.Forest, 26)
            setPadding(dp(20), dp(20), dp(18), dp(16))
        }
        val heroTop = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val heroWords = column()
        heroWords.addView(BrandUi.label(this, "把阅读里的生词，\n收进口袋。", 22f, BrandUi.Paper, true).apply { setLineSpacing(dp(4).toFloat(), 1f) })
        heroTop.addView(heroWords, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        heroTop.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_launcher_foreground)
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        }, LinearLayout.LayoutParams(dp(66), dp(66)))
        hero.addView(heroTop)
        screenAction = BrandUi.action(this, "开启屏幕取词", R.drawable.ic_capture, BrandUi.SoftGreen, BrandUi.Forest).apply {
            tag = "screen_lookup"; setOnClickListener { enableOverlay() }
        }
        hero.addView(screenAction, lp(top = 14))
        hero.addView(BrandUi.label(this, "开启后，点屏幕上的悬浮按钮即可取词", 10f, 0xFFB7C7BD.toInt()).apply { gravity = Gravity.CENTER }, lp(top = 9))
        header.addView(hero, lp(top = 20))
        val quick = LinearLayout(this)
        quick.addView(quickAction("拍照查词", "纸书里的生词也能记", R.drawable.ic_camera) { takePhotoForLookup() },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = dp(10) })
        quick.addView(quickAction("手动记词", "随时补充想记的词", R.drawable.ic_add) { showAddDialog("") },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(quick, lp(top = 12))
        header.addView(quickAction("整句翻译", "输入或粘贴英文，翻译成中文", R.drawable.ic_translate) {
            showSentenceTranslation("")
        }.apply { tag = "sentence_translate" }, lp(top = 10))

        val sectionTitle = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        countLabel = BrandUi.label(this, "我的单词本", 19f, bold = true)
        sectionTitle.addView(countLabel)
        countBadge = BrandUi.label(this, "0 词", 11f).apply {
            background = BrandUi.shape(this@MainActivity, BrandUi.Tint, 10)
            setPadding(dp(8), dp(4), dp(8), dp(4)); gravity = Gravity.CENTER
        }
        sectionTitle.addView(countBadge, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginStart = dp(8) })
        sectionTitle.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        sectionTitle.addView(BrandUi.label(this, "备份与恢复", 12f, BrandUi.Muted).apply {
            minimumHeight = dp(44); gravity = Gravity.CENTER; setPadding(dp(8), 0, 0, 0)
            tag = "backup_open"; isClickable = true; isFocusable = true
            setOnClickListener { showBackupDialog() }
        })
        header.addView(sectionTitle, lp(top = 18))
        val searchRow = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; background = BrandUi.shape(this@MainActivity, BrandUi.Cream, 16, BrandUi.Line)
            setPadding(dp(14), 0, dp(8), 0)
        }
        searchRow.addView(BrandUi.icon(this, R.drawable.ic_search, BrandUi.Muted), LinearLayout.LayoutParams(dp(19), dp(19)))
        val search = BrandUi.field(this, "查找英文或中文释义").apply {
            id = R.id.word_search; tag = "word_search"; background = null; textSize = 14f
            setPadding(dp(10), dp(12), dp(4), dp(12))
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { searchQuery = s.toString(); filterWords() }
                override fun afterTextChanged(s: Editable?) {}
            })
        }
        searchRow.addView(search, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(searchRow, lp(top = 4))
        wordList.addHeaderView(header, null, false)
        val footer = column().apply { setPadding(dp(20), dp(4), dp(20), dp(24)) }
        footer.addView(backupCard())
        footer.addView(BrandUi.label(this, "悬浮按钮：轻点取词 · 拖动移位 · 长按关闭", 10f, BrandUi.Muted).apply { gravity = Gravity.CENTER }, lp(top = 15))
        wordList.addFooterView(footer, null, false)
        wordsAdapter = object : BaseAdapter() {
            override fun getCount() = visibleWords.size.coerceAtLeast(1)
            override fun getItem(position: Int): WordEntry? = visibleWords.getOrNull(position)
            override fun getItemId(position: Int) = position.toLong()
            override fun isEnabled(position: Int) = false
            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                if (visibleWords.isEmpty()) return emptyWordsView()
                val entry = visibleWords[position]
                val holder = (convertView?.tag as? WordRowHolder) ?: createWordRow()
                holder.word.text = entry.word
                holder.meaning.text = entry.meaning
                holder.card.setOnClickListener { showWordDetails(entry) }
                holder.menu.setOnClickListener {
                    PopupMenu(this@MainActivity, holder.menu).apply {
                        menu.add("编辑释义").setOnMenuItemClickListener { editMeaning(entry.word, entry.meaning); true }
                        menu.add("删除单词").setOnMenuItemClickListener { confirmDeleteWord(entry.word); true }
                    }.show()
                }
                return holder.root
            }
        }
        wordList.adapter = wordsAdapter
        root.addView(wordList, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)
        WindowCompat.getInsetsController(window, root).apply {
            isAppearanceLightStatusBars = true; isAppearanceLightNavigationBars = true
        }
        ViewCompat.requestApplyInsets(root)
        root.requestFocus()
    }

    private fun column() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    private fun lp(top: Int = 0) = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(top) }

    private fun quickAction(title: String, description: String, icon: Int, click: () -> Unit): View = column().apply {
        background = BrandUi.ripple(this@MainActivity, BrandUi.Cream, 20, BrandUi.Line)
        setPadding(dp(14), dp(14), dp(12), dp(14)); minimumHeight = dp(76)
        isClickable = true; isFocusable = true; contentDescription = "$title，$description"
        val row = LinearLayout(this@MainActivity).apply { gravity = Gravity.CENTER_VERTICAL }
        row.addView(BrandUi.icon(this@MainActivity, icon), LinearLayout.LayoutParams(dp(20), dp(20)).apply { marginEnd = dp(8) })
        row.addView(BrandUi.label(this@MainActivity, title, 14f, bold = true))
        addView(row)
        addView(BrandUi.label(this@MainActivity, description, 10f, BrandUi.Muted), lp(top = 8))
        setOnClickListener { click() }
    }

    private fun backupCard(): View = column().apply {
        background = BrandUi.shape(this@MainActivity, BrandUi.Tint, 22)
        setPadding(dp(16), dp(16), dp(16), dp(14))
        val heading = LinearLayout(this@MainActivity).apply { gravity = Gravity.CENTER_VERTICAL }
        heading.addView(BrandUi.label(this@MainActivity, "让单词本安心留存", 15f, bold = true), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        heading.addView(BrandUi.icon(this@MainActivity, R.drawable.ic_help, BrandUi.Muted).apply {
            minimumWidth = dp(44); minimumHeight = dp(44); setPadding(dp(12), dp(12), dp(12), dp(12))
            isClickable = true; isFocusable = true; contentDescription = "备份和恢复是什么意思"
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_YES
            setOnClickListener { showBackupHelp() }
        }, LinearLayout.LayoutParams(dp(36), dp(36)))
        addView(heading)
        addView(BrandUi.label(this@MainActivity, "保存一份到手机，换手机时也能找回来。", 12f, BrandUi.Muted), lp(top = 2))
        val actions = LinearLayout(this@MainActivity)
        actions.addView(BrandUi.action(this@MainActivity, "恢复单词本", R.drawable.ic_restore, BrandUi.Cream, BrandUi.Forest).apply {
            tag = "backup_import"; setOnClickListener { importCsv() }
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = dp(8) })
        actions.addView(BrandUi.action(this@MainActivity, "保存备份", R.drawable.ic_backup, BrandUi.Forest, BrandUi.Paper).apply {
            tag = "backup_export"; setOnClickListener { exportCsv() }
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        addView(actions, lp(top = 13))
        addView(BrandUi.label(this@MainActivity, "恢复：从备份文件添加单词。保存：把单词和释义存为文件。", 12f, BrandUi.Muted), lp(top = 10))
    }

    private fun showBackupDialog() {
        AlertDialog.Builder(this).setTitle("单词本备份与恢复")
            .setView(column().apply { setPadding(dp(18), 0, dp(18), dp(8)); addView(backupCard()) })
            .setNegativeButton("关闭", null).setNeutralButton("文件格式说明") { _, _ -> showBackupHelp() }.show()
    }

    private fun showBackupHelp() {
        AlertDialog.Builder(this).setTitle("备份和恢复是什么意思？")
            .setMessage("保存备份：把你的英文单词和中文释义保存成一份表格文件，方便留存或换手机。不会删除单词本里的内容。\n\n恢复单词本：选择之前保存的备份文件，把其中的单词加回来。重复单词会跳过，现有释义会保留。\n\n备份采用 CSV 表格格式，可用 WPS 或 Excel 打开。导入其他表格时，第一行需为 word,meaning（单词、释义）。")
            .setPositiveButton("明白了", null).show()
    }

    private fun emptyWordsView(): View = FrameLayout(this).apply {
        setPadding(dp(20), dp(6), dp(20), dp(14))
        val card = column().apply {
            gravity = Gravity.CENTER; background = BrandUi.shape(this@MainActivity, BrandUi.Cream, 22, BrandUi.Line)
            setPadding(dp(20), dp(22), dp(20), dp(20))
            addView(ImageView(this@MainActivity).apply {
                setImageResource(R.drawable.ic_launcher_monochrome); setColorFilter(BrandUi.Muted); alpha = 0.55f
                importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            }, LinearLayout.LayoutParams(dp(58), dp(58)))
            addView(BrandUi.label(this@MainActivity, when {
                isNameEasterEgg() -> "gjc"
                searchQuery.isBlank() -> "把第一个生词收进口袋"
                else -> "没有找到匹配的单词"
            }, 15f, bold = true).apply { gravity = Gravity.CENTER }, lp(top = 6))
            addView(BrandUi.label(this@MainActivity, when {
                isNameEasterEgg() -> "顾家铖"
                searchQuery.isBlank() -> "从屏幕或书页中，收集你想记住的词。"
                else -> "试试其他英文拼写或中文释义。"
            }, 11f, BrandUi.Muted).apply { gravity = Gravity.CENTER }, lp(top = 8))
            if (searchQuery.isBlank()) addView(BrandUi.label(this@MainActivity, "+ 记下第一个单词", 12f, BrandUi.Forest, true).apply {
                gravity = Gravity.CENTER; minimumHeight = dp(44); isClickable = true; isFocusable = true
                setOnClickListener { showAddDialog("") }
            }, lp(top = 6))
        }
        addView(card, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    }

    private data class WordRowHolder(val root: FrameLayout, val card: LinearLayout, val word: TextView, val meaning: TextView, val menu: ImageView)
    private fun createWordRow(): WordRowHolder {
        val root = FrameLayout(this).apply { setPadding(dp(20), dp(5), dp(20), dp(5)) }
        val card = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; background = BrandUi.ripple(this@MainActivity, BrandUi.Cream, 20, BrandUi.Line)
            setPadding(dp(16), dp(16), dp(6), dp(16)); isClickable = true; isFocusable = true
        }
        val texts = column()
        val word = BrandUi.label(this, "", 20f, bold = true).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END }
        val meaning = BrandUi.label(this, "", 13f, BrandUi.Muted).apply { maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END }
        texts.addView(word); texts.addView(meaning, lp(top = 7))
        card.addView(texts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val menu = BrandUi.icon(this, R.drawable.ic_more, BrandUi.Muted).apply {
            setPadding(dp(11), dp(11), dp(11), dp(11)); contentDescription = "单词操作：编辑或删除"
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_YES; isClickable = true; isFocusable = true
        }
        card.addView(menu, LinearLayout.LayoutParams(dp(44), dp(44)))
        root.addView(card, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        return WordRowHolder(root, card, word, meaning, menu).also { root.tag = it }
    }

    private fun showWordDetails(entry: WordEntry) {
        AlertDialog.Builder(this).setTitle(entry.word).setMessage(entry.meaning)
            .setPositiveButton("编辑释义") { _, _ -> editMeaning(entry.word, entry.meaning) }
            .setNeutralButton("删除单词") { _, _ -> confirmDeleteWord(entry.word) }
            .setNegativeButton("关闭", null).show()
    }

    private fun enableOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            Toast.makeText(this, "请允许‘随身单词本’显示在其他应用上层，然后返回再点一次。", Toast.LENGTH_LONG).show()
            return
        }
        startService(Intent(this, OverlayService::class.java))
        Toast.makeText(this, "悬浮取词已开启：轻点取词，拖动移位，长按关闭。", Toast.LENGTH_LONG).show()
        mainHandler.postDelayed({ if (!isDestroyed) refreshOverlayLabel() }, 250)
    }

    private fun handleIntent(intent: Intent?) {
        if (intent?.action == OverlayService.ACTION_CAPTURE) {
            if (CaptureService.sessionActive) {
                // Reuse the existing MediaProjection session for another OCR request.
                startService(Intent(this, CaptureService::class.java).setAction(CaptureService.ACTION_CAPTURE_ONCE))
            } else {
                val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_CAPTURE)
            }
        }
    }

    @Deprecated("Android screen-capture consent uses activity result")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == RESULT_OK && (requestCode == REQUEST_IMPORT || requestCode == REQUEST_EXPORT)) {
            val uri = data?.data ?: return
            if (requestCode == REQUEST_EXPORT) {
                background({
                    val entries = WordStore.resolvedEntries(applicationContext)
                    contentResolver.openOutputStream(uri, "wt")?.bufferedWriter(Charsets.UTF_8)?.use { WordCsv.write(entries, it) }
                        ?: error("无法写入所选文件。")
                }) { Toast.makeText(this, "备份已保存，可用于留存或换手机恢复。", Toast.LENGTH_LONG).show() }
            } else {
                background({
                    contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { WordCsv.read(it) }
                        ?: error("无法读取所选文件。")
                }) { entries ->
                    AlertDialog.Builder(this).setTitle("恢复 ${entries.size} 个单词？")
                        .setMessage("将合并到现有单词本，重复单词会跳过，已有释义会保留。")
                        .setNegativeButton("取消", null)
                        .setPositiveButton("恢复单词") { _, _ ->
                            background({ WordStore.importEntries(applicationContext, entries) }) { result ->
                                Toast.makeText(this, "已恢复 ${result.added} 个单词，跳过 ${result.skipped} 个重复项。", Toast.LENGTH_LONG).show()
                                refreshWords()
                            }
                        }.show()
                }
            }
        } else if (requestCode == REQUEST_CAMERA && resultCode == RESULT_OK) {
            val uri = photoLookupUri
            val thumbnail: Bitmap? = data?.let {
                if (Build.VERSION.SDK_INT >= 33) it.getParcelableExtra("data", Bitmap::class.java)
                else @Suppress("DEPRECATION") it.getParcelableExtra("data")
            }
            photoBusy = true
            background({ uri?.let { decodePhotoLookupBitmap(it) } ?: thumbnail }, discard = { it?.recycle() }, failed = { photoBusy = false }) { bitmap ->
                photoBusy = false
                if (bitmap != null) recognizePhoto(bitmap)
                else Toast.makeText(this, "没有取得照片，请重试。", Toast.LENGTH_SHORT).show()
            }
        } else if (requestCode == REQUEST_CAPTURE && resultCode == RESULT_OK && data != null) {
            val service = Intent(this, CaptureService::class.java).apply {
                putExtra(CaptureService.EXTRA_RESULT_CODE, resultCode)
                putExtra(CaptureService.EXTRA_RESULT_DATA, data)
            }
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(service) else startService(service)
        } else if (requestCode == REQUEST_CAPTURE) {
            Toast.makeText(this, "你取消了屏幕捕获。", Toast.LENGTH_SHORT).show()
        }
    }

    private fun takePhotoForLookup() {
        if (photoBusy) return
        val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        if (cameraIntent.resolveActivity(packageManager) == null) {
            Toast.makeText(this, "没有找到可用的相机应用。", Toast.LENGTH_LONG).show()
            return
        }
        // Ask the camera app to write a full-size photo to our cache file.
        // Without EXTRA_OUTPUT, most camera apps only return a small
        // thumbnail in "data", which is the old clarity problem.
        try {
            val photoFile = File(cacheDir, "pocketwords-photo-lookup.jpg")
            if (photoFile.exists()) photoFile.delete()
            val outputUri = androidx.core.content.FileProvider.getUriForFile(
                this, "$packageName.fileprovider", photoFile
            )
            photoLookupUri = outputUri
            cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, outputUri)
            cameraIntent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        } catch (_: Exception) {
            // Fall back to the thumbnail path if FileProvider setup fails.
            photoLookupUri = null
        }
        try { startActivityForResult(cameraIntent, REQUEST_CAMERA) }
        catch (_: Exception) { Toast.makeText(this, "无法打开相机，请稍后重试。", Toast.LENGTH_LONG).show() }
    }

    private fun decodePhotoLookupBitmap(uri: Uri): Bitmap? {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sampleSize = 1
            while (maxOf(bounds.outWidth, bounds.outHeight) / sampleSize > PHOTO_MAX_SIDE) sampleSize *= 2
            val options = BitmapFactory.Options().apply { inSampleSize = sampleSize }
            val decoded = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, options) }
                ?: return null
            val orientation = try {
                contentResolver.openInputStream(uri)?.use {
                    ExifInterface(it).getAttributeInt(
                        ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL
                    )
                } ?: ExifInterface.ORIENTATION_NORMAL
            } catch (_: Exception) { ExifInterface.ORIENTATION_NORMAL }
            val rotation = when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
            if (rotation == 0f) decoded else {
                val matrix = Matrix().apply { postRotate(rotation) }
                Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, matrix, true).also {
                    if (it !== decoded) decoded.recycle()
                }
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun scaleBitmapForOcr(bitmap: Bitmap): Bitmap {
        val maxSide = maxOf(bitmap.width, bitmap.height)
        if (maxSide <= PHOTO_MAX_SIDE) return bitmap
        val scale = PHOTO_MAX_SIDE.toFloat() / maxSide.toFloat()
        return Bitmap.createScaledBitmap(
            bitmap, (bitmap.width * scale).toInt(), (bitmap.height * scale).toInt(), true
        )
    }

    private fun recognizePhoto(inputBitmap: Bitmap, source: ImageSource = ImageSource.PHOTO) {
        if (photoBusy) { inputBitmap.recycle(); return }
        photoBusy = true
        Toast.makeText(this, "正在识别英文…", Toast.LENGTH_SHORT).show()
        background({
            try {
                val bitmap = scaleBitmapForOcr(inputBitmap)
                if (bitmap !== inputBitmap) inputBitmap.recycle()
                val imageFile = File.createTempFile("lookup-", ".jpg", cacheDir)
                try {
                    FileOutputStream(imageFile).use { check(bitmap.compress(Bitmap.CompressFormat.JPEG, 92, it)) }
                } catch (e: Exception) { bitmap.recycle(); imageFile.delete(); throw e }
                bitmap to imageFile
            } catch (e: Exception) {
                mainHandler.post { photoBusy = false }
                throw e
            }
        }, discard = { (bitmap, imageFile) -> bitmap.recycle(); imageFile.delete() }) { (bitmap, imageFile) ->
            val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            recognizer.process(InputImage.fromBitmap(bitmap, 0))
                .addOnSuccessListener { result ->
                    if (isFinishing || isDestroyed) return@addOnSuccessListener
                    val boxes = JSONArray()
                    result.textBlocks.forEach { block -> block.lines.forEach { line ->
                        line.elements.forEach { element ->
                            val rect = element.boundingBox
                            if (element.text.any { it.isLetter() } && rect != null) {
                                boxes.put(JSONObject().put("text", element.text).put("left", rect.left).put("top", rect.top).put("right", rect.right).put("bottom", rect.bottom))
                            }
                        }
                    } }
                    if (result.text.isBlank()) {
                        Toast.makeText(this, "没有识别到英文。请让文字更清晰后重试。", Toast.LENGTH_LONG).show()
                    } else {
                        showWordSelection(result.text, imageFile.absolutePath, boxes.toString(), bitmap.width, bitmap.height, source)
                    }
                }
                .addOnFailureListener {
                    if (!isDestroyed) Toast.makeText(this, "识别失败，请重试。", Toast.LENGTH_LONG).show()
                }
                .addOnCompleteListener {
                    photoBusy = false; bitmap.recycle(); imageFile.delete(); recognizer.close()
                }
        }
    }

    private fun showWordSelection(text: String, imagePath: String, boxesJson: String, imageWidth: Int, imageHeight: Int, source: ImageSource = ImageSource.SCREEN) {
        if (text.isBlank() || imagePath.isBlank()) {
            Toast.makeText(this, "没有识别到清晰文字。请放大英文内容、换个页面后重试。", Toast.LENGTH_LONG).show()
            return
        }
        val bitmap = try { BitmapFactory.decodeFile(imagePath) } catch (_: Exception) { null }
        if (bitmap == null) { showRecognizedTextFallback(text); return }
        val boxes = mutableListOf<WordBox>()
        try {
            val arr = JSONArray(boxesJson)
            for (i in 0 until arr.length()) {
                val item = arr.getJSONObject(i)
                boxes.add(WordBox(item.optString("text"), item.optInt("left"), item.optInt("top"), item.optInt("right"), item.optInt("bottom")))
            }
        } catch (_: Exception) {}
        val selectionView = WordSelectionView(this, bitmap, boxes, imageWidth.takeIf { it > 0 } ?: bitmap.width,
            imageHeight.takeIf { it > 0 } ?: bitmap.height) { showSelectedWordDialog(it) }.apply {
            background = BrandUi.shape(this@MainActivity, BrandUi.Cream, 16)
            clipToOutline = true
        }
        val container = column().apply {
            setPadding(dp(18), dp(4), dp(18), dp(8))
            addView(BrandUi.label(this@MainActivity, if (boxes.isEmpty()) "识别完成，可手动补充单词" else "找到 ${boxes.size} 个可点选的词", 13f, bold = true))
            addView(BrandUi.label(this@MainActivity, "双指放大图片，轻点词框查看释义。", 12f, BrandUi.Muted), lp(top = 6))
            addView(selectionView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                minOf(dp(340), (resources.displayMetrics.heightPixels * 0.38f).toInt())).apply { topMargin = dp(14) })
        }
        val dialog = AlertDialog.Builder(this).setTitle(if (source == ImageSource.PHOTO) "照片里的单词" else "屏幕里的单词")
            .setView(ScrollView(this).apply { addView(container) }).setNegativeButton("完成", null)
            .setNeutralButton(if (source == ImageSource.PHOTO) "重新拍照" else "重新截屏", null).create()
        val actions = LinearLayout(this)
        actions.addView(BrandUi.action(this, "手动输入", R.drawable.ic_add, BrandUi.Cream, BrandUi.Forest).apply {
            setOnClickListener { showAddDialog("") }
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = dp(8) })
        actions.addView(BrandUi.action(this, "识别此区域", R.drawable.ic_capture, BrandUi.Tint, BrandUi.Forest).apply {
            setOnClickListener {
                val cropped = selectionView.cropVisible()
                dialog.dismiss(); recognizePhoto(cropped, source)
            }
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        container.addView(actions, lp(top = 12))
        container.addView(BrandUi.action(this, "选择句子翻译", R.drawable.ic_translate, BrandUi.SoftGreen, BrandUi.Forest).apply {
            tag = "ocr_translate"; setOnClickListener { showOcrLineSelection(text) }
        }, lp(top = 10))
        dialog.setOnDismissListener { bitmap.recycle() }
        dialog.show()
        dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
            dialog.dismiss()
            if (source == ImageSource.PHOTO) takePhotoForLookup() else handleIntent(Intent(OverlayService.ACTION_CAPTURE))
        }
    }

    private fun showSelectedWordDialog(word: String) {
        val clean = WordForms.clean(word)
        if (clean.isBlank()) return
        var lookupGeneration = 0
        var meaningEdited = false
        var settingMeaning = false
        val wordInput = BrandUi.field(this, "识别不准时可直接修改").apply { tag = "word_input"; setText(clean) }
        val meaningInput = BrandUi.field(this, "正在查询释义…", false).apply { tag = "meaning_input"; minLines = 2 }
        val inputs = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(4), dp(20), dp(8))
            addView(BrandUi.label(this@MainActivity, "英文单词", 12f, BrandUi.Muted))
            addView(wordInput, lp(top = 7))
            addView(BrandUi.label(this@MainActivity, "中文释义 · 可以自己补充", 12f, BrandUi.Muted), lp(top = 16))
            addView(meaningInput, lp(top = 7))
        }
        val dialog = AlertDialog.Builder(this).setTitle("确认单词和释义").setView(inputs)
            .setNegativeButton("取消", null).setPositiveButton("收藏单词", null).create()
        var open = true
        fun lookup() {
            val generation = ++lookupGeneration
            val value = wordInput.text.toString()
            background({ WordStore.lookupMeaning(applicationContext, value) }) { meaning ->
                if (open && generation == lookupGeneration && !meaningEdited) {
                    settingMeaning = true; meaningInput.setText(meaning); settingMeaning = false
                }
            }
        }
        meaningInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { if (!settingMeaning) meaningEdited = true }
            override fun afterTextChanged(s: Editable?) {}
        })
        val relookup = Runnable { lookup() }
        wordInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                lookupGeneration++; meaningEdited = false
                settingMeaning = true; meaningInput.setText(""); settingMeaning = false
                mainHandler.removeCallbacks(relookup); mainHandler.postDelayed(relookup, 300)
            }
            override fun afterTextChanged(s: Editable?) {}
        })
        dialog.setOnDismissListener { open = false; lookupGeneration++; mainHandler.removeCallbacks(relookup) }
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val corrected = WordForms.clean(wordInput.text.toString())
                if (corrected.isBlank()) { wordInput.error = "请输入单词"; return@setOnClickListener }
                val meaning = meaningInput.text.toString().trim()
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).isEnabled = false
                background({
                    WordStore.add(applicationContext, corrected, meaning.ifBlank { WordStore.lookupMeaning(applicationContext, corrected) })
                }, failed = { dialog.getButton(AlertDialog.BUTTON_POSITIVE).isEnabled = true }) { added ->
                    Toast.makeText(this, if (added) "已收藏：$corrected" else "这个单词已经在单词本里了", Toast.LENGTH_SHORT).show()
                    dialog.dismiss(); refreshWords()
                }
            }
        }
        dialog.show(); lookup()
    }

    private fun showOcrLineSelection(text: String) {
        OcrLineSelectionDialog.show(this, text) { showSentenceTranslation(it) }
    }

    private fun showSentenceTranslation(text: String) {
        val sheet = SentenceTranslationDialog(this)
        sentenceDialogs.add(sheet)
        sheet.show(text) { sentenceDialogs.remove(sheet) }
    }

    private fun showRecognizedTextFallback(text: String) {
        val input = BrandUi.field(this, "只保留你想收藏的单词", false).apply { setText(text) }
        AlertDialog.Builder(this).setTitle("识别结果（备用方式）").setView(input)
            .setNeutralButton("选择句子翻译") { _, _ -> showOcrLineSelection(input.text.toString()) }
            .setNegativeButton("取消", null).setPositiveButton("继续") { _, _ -> showSelectedWordDialog(input.text.toString()) }.show()
    }

    private fun showAddDialog(initial: String) {
        val input = BrandUi.field(this, "例如：consistent").apply { setText(initial) }
        AlertDialog.Builder(this).setTitle("记下一个新单词")
            .setMessage("输入英文后，下一步会自动查询中文释义。")
            .setView(column().apply { setPadding(dp(20), dp(4), dp(20), dp(8)); addView(input) })
            .setNegativeButton("取消", null)
            .setPositiveButton("查看释义") { _, _ ->
                val word = input.text.toString().trim()
                if (word.isNotBlank()) showSelectedWordDialog(word)
                else Toast.makeText(this, "请输入单词", Toast.LENGTH_SHORT).show()
            }.show()
    }

    private fun refreshWords() {
        if (!::wordList.isInitialized) return
        val generation = ++refreshGeneration
        background({ WordStore.resolvedEntries(applicationContext) }) { all ->
            if (generation != refreshGeneration) return@background
            loadedWords = all
            filterWords()
        }
    }

    private fun isNameEasterEgg() = searchQuery.trim().equals("gjc", ignoreCase = true)

    private fun filterWords() {
        if (!::countLabel.isInitialized) return
        val query = searchQuery.trim()
        val matches = if (isNameEasterEgg()) emptyList() else loadedWords.filter {
            it.word.contains(query, true) || it.meaning.contains(query, true)
        }
        renderWords(matches, loadedWords.size)
    }

    private fun renderWords(words: List<WordEntry>, total: Int) {
        countLabel.text = if (searchQuery.isBlank()) "我的单词本" else "查找结果"
        countBadge.text = when {
            isNameEasterEgg() -> "彩蛋"
            searchQuery.isBlank() -> "$total 词"
            else -> "${words.size} / $total"
        }
        visibleWords.clear(); visibleWords.addAll(words)
        wordsAdapter.notifyDataSetChanged()
    }

    private fun confirmDeleteWord(word: String) {
        AlertDialog.Builder(this)
            .setTitle("删除单词？")
            .setMessage("确定要删除「$word」吗？删除后将从单词本中移除。")
            .setNegativeButton("返回", null)
            .setPositiveButton("删除") { _, _ ->
                background({ WordStore.delete(applicationContext, word) }) { refreshWords() }
            }
            .show()
    }

    private fun editMeaning(word: String, current: String) {
        val input = BrandUi.field(this, "填写你想记住的中文释义", false).apply { setText(current); minLines = 3 }
        AlertDialog.Builder(this).setTitle(word)
            .setView(column().apply { setPadding(dp(20), dp(4), dp(20), dp(8)); addView(input) })
            .setNegativeButton("取消", null)
            .setPositiveButton("保存释义") { _, _ ->
                val meaning = input.text.toString().trim()
                background({ WordStore.updateMeaning(applicationContext, word, meaning) }) { refreshWords() }
            }.show()
    }

    private fun importCsv() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("text/csv", "text/comma-separated-values", "text/plain", "application/octet-stream"))
        }, REQUEST_IMPORT)
    }

    private fun exportCsv() {
        startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "text/csv"
            putExtra(Intent.EXTRA_TITLE, "PocketWords-单词备份-${java.time.LocalDate.now()}.csv")
        }, REQUEST_EXPORT)
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    companion object {
        private const val REQUEST_CAPTURE = 4102
        private const val REQUEST_CAMERA = 4103
        private const val REQUEST_IMPORT = 4104
        private const val REQUEST_EXPORT = 4105
        private const val KEY_PHOTO_LOOKUP_URI = "photo_lookup_uri"
        private const val PHOTO_MAX_SIDE = 2048
    }
}

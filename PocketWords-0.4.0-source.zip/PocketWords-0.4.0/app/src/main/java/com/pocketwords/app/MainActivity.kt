package com.pocketwords.app

import android.app.Activity
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.ExifInterface
import android.media.projection.MediaProjectionManager
import android.graphics.Bitmap
import android.graphics.Matrix
import android.graphics.BitmapFactory
import org.json.JSONArray
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.provider.MediaStore
import java.io.File
import java.io.FileOutputStream
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.JSONObject
import android.view.Gravity
import android.view.View
import android.widget.BaseAdapter
import android.widget.ListView
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.text.Editable
import android.text.TextWatcher
import java.util.concurrent.Executors
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.core.content.ContextCompat

class MainActivity : Activity() {
    private lateinit var wordList: ListView
    private lateinit var countLabel: TextView
    private var photoLookupUri: Uri? = null
    private lateinit var dictionaryStatus: TextView
    private val io = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())
    private var searchQuery = ""
    private var loadedWords = emptyList<WordEntry>()
    private var refreshGeneration = 0
    private var photoBusy = false
    private enum class ImageSource { PHOTO, SCREEN }

    private fun <T> background(work: () -> T, discard: (T) -> Unit = {}, failed: () -> Unit = {}, done: (T) -> Unit) {
        io.execute {
            val result = runCatching(work)
            mainHandler.post {
                if (isFinishing || isDestroyed) result.onSuccess(discard)
                else result.fold(done) {
                    failed()
                    Toast.makeText(this, it.message ?: "操作失败，请重试。", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private val captureReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val text = intent?.getStringExtra(CaptureService.EXTRA_TEXT).orEmpty()
            val imagePath = intent?.getStringExtra(CaptureService.EXTRA_IMAGE_PATH).orEmpty()
            val boxes = intent?.getStringExtra(CaptureService.EXTRA_WORD_BOXES).orEmpty()
            val width = intent?.getIntExtra(CaptureService.EXTRA_IMAGE_WIDTH, 0) ?: 0
            val height = intent?.getIntExtra(CaptureService.EXTRA_IMAGE_HEIGHT, 0) ?: 0
            runOnUiThread { showWordSelection(text, imagePath, boxes, width, height) }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        photoLookupUri = savedInstanceState?.getString(KEY_PHOTO_LOOKUP_URI)?.let { Uri.parse(it) }
        buildUi()
        background({
            runCatching { WordStore.prepareDictionary(applicationContext) }.isSuccess
        }) { ready ->
            dictionaryStatus.text = if (ready) "离线词典已就绪" else "离线词典暂不可用，可手动填写释义；重启后重试"
        }
        refreshWords()
        val filter = IntentFilter(CaptureService.ACTION_OCR_RESULT)
        ContextCompat.registerReceiver(this, captureReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        photoLookupUri?.let { outState.putString(KEY_PHOTO_LOOKUP_URI, it.toString()) }
    }

    override fun onDestroy() {
        try { unregisterReceiver(captureReceiver) } catch (_: Exception) {}
        io.shutdown()
        super.onDestroy()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(16))
            setBackgroundColor(0xFFF5F5F5.toInt())
        }
        val brandRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val brandMark = TextView(this).apply {
            text = "Aa"; textSize = 23f; gravity = Gravity.CENTER
            setTextColor(0xFFFFFFFF.toInt()); typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD)
            background = rounded(0xFF111111.toInt(), 16)
        }
        brandRow.addView(brandMark, LinearLayout.LayoutParams(dp(54), dp(54)))
        val heading = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
        heading.addView(TextView(this).apply { text = "PocketWords"; textSize = 25f; setTextColor(0xFF111111.toInt()); typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD) })
        heading.addView(TextView(this).apply { text = "屏幕取词 · 离线释义"; textSize = 13f; setTextColor(0xFF777777.toInt()); setPadding(0, dp(2), 0, 0) })
        brandRow.addView(heading, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(brandRow)
        root.addView(TextView(this).apply { text = "遇见生词，随手收藏。"; textSize = 15f; setTextColor(0xFF666666.toInt()); setPadding(0, dp(18), 0, dp(16)) })

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        actions.addView(Button(this).apply {
            text = "开启悬浮取词"; isAllCaps = false; textSize = 14f; setTextColor(0xFFFFFFFF.toInt())
            background = rounded(0xFF111111.toInt(), 14)
            setOnClickListener { enableOverlay() }
        }, LinearLayout.LayoutParams(0, dp(50), 1f).apply { rightMargin = dp(8) })
        actions.addView(Button(this).apply {
            text = "+ 添加单词"; isAllCaps = false; textSize = 14f; setTextColor(0xFF111111.toInt())
            background = rounded(0xFFFFFFFF.toInt(), 14)
            setOnClickListener { showAddDialog("") }
        }, LinearLayout.LayoutParams(dp(132), dp(50)))
        root.addView(actions)
        root.addView(Button(this).apply {
            text = "\uD83D\uDCF7 拍照查词"; isAllCaps = false; textSize = 14f
            setTextColor(0xFF111111.toInt()); background = rounded(0xFFEAEAEA.toInt(), 14)
            setOnClickListener { takePhotoForLookup() }
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)).apply { topMargin = dp(10) })

        dictionaryStatus = TextView(this).apply {
            text = "正在准备离线词典…"; textSize = 12f; setPadding(0, dp(8), 0, dp(8))
        }
        root.addView(dictionaryStatus)
        val libraryActions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        libraryActions.addView(Button(this).apply { text = "导入 CSV"; setOnClickListener { importCsv() } }, LinearLayout.LayoutParams(0, dp(44), 1f))
        libraryActions.addView(Button(this).apply { text = "导出 CSV"; setOnClickListener { exportCsv() } }, LinearLayout.LayoutParams(0, dp(44), 1f))
        root.addView(libraryActions)
        val search = EditText(this).apply {
            hint = "搜索单词或中文释义"; setSingleLine(true)
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { searchQuery = s.toString(); filterWords() }
                override fun afterTextChanged(s: Editable?) {}
            })
        }
        root.addView(search)
        val section = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(14), dp(16), dp(12)); background = rounded(0xFFFFFFFF.toInt(), 18) }
        countLabel = TextView(this).apply { textSize = 18f; setTextColor(0xFF111111.toInt()); typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD); setPadding(0, 0, 0, dp(10)) }
        section.addView(countLabel)
        wordList = ListView(this).apply { divider = null; dividerHeight = dp(8) }
        section.addView(wordList, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(section, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f).apply { topMargin = dp(18) })
        root.addView(TextView(this).apply { text = "提示  ·  首次使用需授权屏幕捕获；点选截图中的单词即可查看释义并收藏。"; textSize = 12f; setTextColor(0xFF888888.toInt()); setPadding(dp(2), dp(12), dp(2), 0) })
        setContentView(root)
    }

    private fun enableOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            Toast.makeText(this, "请允许‘随身单词本’显示在其他应用上层，然后返回再点一次。", Toast.LENGTH_LONG).show()
            return
        }
        startService(Intent(this, OverlayService::class.java))
        Toast.makeText(this, "悬浮球已开启，可打开英文页面后点击它。", Toast.LENGTH_LONG).show()
    }

    private fun handleIntent(intent: Intent?) {
        if (intent?.action == OverlayService.ACTION_CAPTURE) {
            if (CaptureService.sessionActive) {
                // Reuse the existing MediaProjection session for another OCR request.
                startService(Intent(this, CaptureService::class.java).setAction(CaptureService.ACTION_CAPTURE_ONCE))
            } else {
                val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_CAPTURE)
            }
        }
    }

    @Deprecated("Android screen-capture consent uses activity result")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == RESULT_OK && (requestCode == REQUEST_IMPORT || requestCode == REQUEST_EXPORT)) {
            val uri = data?.data ?: return
            if (requestCode == REQUEST_EXPORT) {
                background({
                    val entries = WordStore.resolvedEntries(applicationContext)
                    contentResolver.openOutputStream(uri, "wt")?.bufferedWriter(Charsets.UTF_8)?.use { WordCsv.write(entries, it) }
                        ?: error("无法写入所选文件。")
                }) { Toast.makeText(this, "CSV 已导出。", Toast.LENGTH_LONG).show() }
            } else {
                background({
                    contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { WordCsv.read(it) }
                        ?: error("无法读取所选文件。")
                }) { entries ->
                    AlertDialog.Builder(this).setTitle("导入 ${entries.size} 个单词？")
                        .setMessage("将合并到现有单词本，重复单词会跳过，已有释义会保留。")
                        .setNegativeButton("取消", null)
                        .setPositiveButton("导入") { _, _ ->
                            background({ WordStore.importEntries(applicationContext, entries) }) { result ->
                                Toast.makeText(this, "已导入 ${result.added} 个，跳过 ${result.skipped} 个重复单词。", Toast.LENGTH_LONG).show()
                                refreshWords()
                            }
                        }.show()
                }
            }
        } else if (requestCode == REQUEST_CAMERA && resultCode == RESULT_OK) {
            val uri = photoLookupUri
            val thumbnail: Bitmap? = data?.let {
                if (Build.VERSION.SDK_INT >= 33) it.getParcelableExtra("data", Bitmap::class.java)
                else @Suppress("DEPRECATION") it.getParcelableExtra("data")
            }
            photoBusy = true
            background({ uri?.let { decodePhotoLookupBitmap(it) } ?: thumbnail }, discard = { it?.recycle() }, failed = { photoBusy = false }) { bitmap ->
                photoBusy = false
                if (bitmap != null) recognizePhoto(bitmap)
                else Toast.makeText(this, "没有取得照片，请重试。", Toast.LENGTH_SHORT).show()
            }
        } else if (requestCode == REQUEST_CAPTURE && resultCode == RESULT_OK && data != null) {
            val service = Intent(this, CaptureService::class.java).apply {
                putExtra(CaptureService.EXTRA_RESULT_CODE, resultCode)
                putExtra(CaptureService.EXTRA_RESULT_DATA, data)
            }
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(service) else startService(service)
        } else if (requestCode == REQUEST_CAPTURE) {
            Toast.makeText(this, "你取消了屏幕捕获。", Toast.LENGTH_SHORT).show()
        }
    }

    private fun takePhotoForLookup() {
        if (photoBusy) return
        val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        if (cameraIntent.resolveActivity(packageManager) == null) {
            Toast.makeText(this, "没有找到可用的相机应用。", Toast.LENGTH_LONG).show()
            return
        }
        // Ask the camera app to write a full-size photo to our cache file.
        // Without EXTRA_OUTPUT, most camera apps only return a small
        // thumbnail in "data", which is the old clarity problem.
        try {
            val photoFile = File(cacheDir, "pocketwords-photo-lookup.jpg")
            if (photoFile.exists()) photoFile.delete()
            val outputUri = androidx.core.content.FileProvider.getUriForFile(
                this, "$packageName.fileprovider", photoFile
            )
            photoLookupUri = outputUri
            cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, outputUri)
            cameraIntent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        } catch (_: Exception) {
            // Fall back to the thumbnail path if FileProvider setup fails.
            photoLookupUri = null
        }
        try { startActivityForResult(cameraIntent, REQUEST_CAMERA) }
        catch (_: Exception) { Toast.makeText(this, "无法打开相机，请稍后重试。", Toast.LENGTH_LONG).show() }
    }

    private fun decodePhotoLookupBitmap(uri: Uri): Bitmap? {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sampleSize = 1
            while (maxOf(bounds.outWidth, bounds.outHeight) / sampleSize > PHOTO_MAX_SIDE) sampleSize *= 2
            val options = BitmapFactory.Options().apply { inSampleSize = sampleSize }
            val decoded = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, options) }
                ?: return null
            val orientation = try {
                contentResolver.openInputStream(uri)?.use {
                    ExifInterface(it).getAttributeInt(
                        ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL
                    )
                } ?: ExifInterface.ORIENTATION_NORMAL
            } catch (_: Exception) { ExifInterface.ORIENTATION_NORMAL }
            val rotation = when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
            if (rotation == 0f) decoded else {
                val matrix = Matrix().apply { postRotate(rotation) }
                Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, matrix, true).also {
                    if (it !== decoded) decoded.recycle()
                }
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun scaleBitmapForOcr(bitmap: Bitmap): Bitmap {
        val maxSide = maxOf(bitmap.width, bitmap.height)
        if (maxSide <= PHOTO_MAX_SIDE) return bitmap
        val scale = PHOTO_MAX_SIDE.toFloat() / maxSide.toFloat()
        return Bitmap.createScaledBitmap(
            bitmap, (bitmap.width * scale).toInt(), (bitmap.height * scale).toInt(), true
        )
    }

    private fun recognizePhoto(inputBitmap: Bitmap, source: ImageSource = ImageSource.PHOTO) {
        if (photoBusy) { inputBitmap.recycle(); return }
        photoBusy = true
        Toast.makeText(this, "正在识别英文…", Toast.LENGTH_SHORT).show()
        background({
            try {
                val bitmap = scaleBitmapForOcr(inputBitmap)
                if (bitmap !== inputBitmap) inputBitmap.recycle()
                val imageFile = File.createTempFile("lookup-", ".jpg", cacheDir)
                try {
                    FileOutputStream(imageFile).use { check(bitmap.compress(Bitmap.CompressFormat.JPEG, 92, it)) }
                } catch (e: Exception) { bitmap.recycle(); imageFile.delete(); throw e }
                bitmap to imageFile
            } catch (e: Exception) {
                mainHandler.post { photoBusy = false }
                throw e
            }
        }, discard = { (bitmap, imageFile) -> bitmap.recycle(); imageFile.delete() }) { (bitmap, imageFile) ->
            val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            recognizer.process(InputImage.fromBitmap(bitmap, 0))
                .addOnSuccessListener { result ->
                    if (isFinishing || isDestroyed) return@addOnSuccessListener
                    val boxes = JSONArray()
                    result.textBlocks.forEach { block -> block.lines.forEach { line ->
                        line.elements.forEach { element ->
                            val rect = element.boundingBox
                            if (element.text.any { it.isLetter() } && rect != null) {
                                boxes.put(JSONObject().put("text", element.text).put("left", rect.left).put("top", rect.top).put("right", rect.right).put("bottom", rect.bottom))
                            }
                        }
                    } }
                    if (result.text.isBlank()) {
                        Toast.makeText(this, "没有识别到英文。请让文字更清晰后重试。", Toast.LENGTH_LONG).show()
                    } else {
                        showWordSelection(result.text, imageFile.absolutePath, boxes.toString(), bitmap.width, bitmap.height, source)
                    }
                }
                .addOnFailureListener {
                    if (!isDestroyed) Toast.makeText(this, "识别失败，请重试。", Toast.LENGTH_LONG).show()
                }
                .addOnCompleteListener {
                    photoBusy = false; bitmap.recycle(); imageFile.delete(); recognizer.close()
                }
        }
    }

    private fun showWordSelection(text: String, imagePath: String, boxesJson: String, imageWidth: Int, imageHeight: Int, source: ImageSource = ImageSource.SCREEN) {
        if (text.isBlank() || imagePath.isBlank()) {
            Toast.makeText(this, "没有识别到清晰文字。请放大英文内容、换个页面后重试。", Toast.LENGTH_LONG).show()
            return
        }
        val bitmap = try { BitmapFactory.decodeFile(imagePath) } catch (_: Exception) { null }
        if (bitmap == null) {
            showRecognizedTextFallback(text)
            return
        }
        val boxes = mutableListOf<WordBox>()
        try {
            val arr = JSONArray(boxesJson)
            for (i in 0 until arr.length()) {
                val item = arr.getJSONObject(i)
                boxes.add(WordBox(item.optString("text"), item.optInt("left"), item.optInt("top"), item.optInt("right"), item.optInt("bottom")))
            }
        } catch (_: Exception) {}
        val selectionView = WordSelectionView(this, bitmap, boxes, imageWidth.takeIf { it > 0 } ?: bitmap.width, imageHeight.takeIf { it > 0 } ?: bitmap.height) { selected ->
            showSelectedWordDialog(selected)
        }
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(4))
            addView(TextView(this@MainActivity).apply {
                this.text = "双指放大、拖动图片，点绿色框查词；双击恢复或放大。"
                textSize = 14f; setTextColor(0xFF53645C.toInt()); setPadding(dp(4), dp(4), dp(4), dp(10))
            })
            addView(selectionView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, minOf(dp(360), (resources.displayMetrics.heightPixels * 0.42f).toInt())))
            addView(Button(this@MainActivity).apply { this.text = "没找到？手动输入单词"; setOnClickListener { showAddDialog("") } }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)))
        }
        val dialog = AlertDialog.Builder(this).setTitle("点选要收藏的单词")
            .setView(container).setNegativeButton("关闭", null)
            .setNeutralButton(if (source == ImageSource.PHOTO) "重新拍照" else "重新截屏", null)
            .show().also { dialog ->
                dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                    dialog.dismiss()
                    if (source == ImageSource.PHOTO) takePhotoForLookup()
                    else handleIntent(Intent(OverlayService.ACTION_CAPTURE))
                }
            }
        container.addView(Button(this).apply {
            this.text = "裁剪当前可见区域并识别"
            setOnClickListener {
                val cropped = selectionView.cropVisible()
                dialog.dismiss()
                recognizePhoto(cropped, source)
            }
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44)))
        dialog.setOnDismissListener { bitmap.recycle() }
    }

    private fun showSelectedWordDialog(word: String) {
        val clean = WordForms.clean(word)
        if (clean.isBlank()) return
        var lookupGeneration = 0
        var meaningEdited = false
        var settingMeaning = false
        val wordInput = EditText(this).apply { hint = "英文单词（可修正识别结果）"; setSingleLine(true); setText(clean) }
        val meaningInput = EditText(this).apply { hint = "正在查询释义…"; minLines = 2 }
        val inputs = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(16), 0, dp(16), 0)
            addView(wordInput); addView(meaningInput)
        }
        val dialog = AlertDialog.Builder(this).setTitle("确认单词和释义").setView(inputs)
            .setNegativeButton("取消", null).setPositiveButton("收藏单词", null).create()
        var open = true
        fun lookup() {
            val generation = ++lookupGeneration
            val value = wordInput.text.toString()
            background({ WordStore.lookupMeaning(applicationContext, value) }) { meaning ->
                if (open && generation == lookupGeneration && !meaningEdited) {
                    settingMeaning = true; meaningInput.setText(meaning); settingMeaning = false
                }
            }
        }
        meaningInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { if (!settingMeaning) meaningEdited = true }
            override fun afterTextChanged(s: Editable?) {}
        })
        val relookup = Runnable { lookup() }
        wordInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                lookupGeneration++; meaningEdited = false
                settingMeaning = true; meaningInput.setText(""); settingMeaning = false
                mainHandler.removeCallbacks(relookup); mainHandler.postDelayed(relookup, 300)
            }
            override fun afterTextChanged(s: Editable?) {}
        })
        dialog.setOnDismissListener { open = false; lookupGeneration++; mainHandler.removeCallbacks(relookup) }
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val corrected = WordForms.clean(wordInput.text.toString())
                if (corrected.isBlank()) { wordInput.error = "请输入单词"; return@setOnClickListener }
                val meaning = meaningInput.text.toString().trim()
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).isEnabled = false
                background({
                    WordStore.add(applicationContext, corrected, meaning.ifBlank { WordStore.lookupMeaning(applicationContext, corrected) })
                }, failed = { dialog.getButton(AlertDialog.BUTTON_POSITIVE).isEnabled = true }) { added ->
                    Toast.makeText(this, if (added) "已收藏：$corrected" else "这个单词已经在单词本里了", Toast.LENGTH_SHORT).show()
                    dialog.dismiss(); refreshWords()
                }
            }
        }
        dialog.show(); lookup()
    }

    private fun showRecognizedTextFallback(text: String) {
        val input = EditText(this).apply { setText(text); hint = "输入要收藏的单词" }
        AlertDialog.Builder(this).setTitle("识别结果（备用方式）").setView(input)
            .setNegativeButton("取消", null).setPositiveButton("继续") { _, _ -> showSelectedWordDialog(input.text.toString()) }.show()
    }

    private fun showAddDialog(initial: String) {
        val input = EditText(this).apply { hint = "例如：consistent"; setText(initial) }
        AlertDialog.Builder(this).setTitle("添加单词").setView(input)
            .setNegativeButton("取消", null)
            .setPositiveButton("收藏") { _, _ ->
                val word = input.text.toString().trim()
                if (word.isNotBlank()) showSelectedWordDialog(word)
                else Toast.makeText(this, "请输入单词", Toast.LENGTH_SHORT).show()
            }.show()
    }

    private fun refreshWords() {
        if (!::wordList.isInitialized) return
        val generation = ++refreshGeneration
        background({ WordStore.resolvedEntries(applicationContext) }) { all ->
            if (generation != refreshGeneration) return@background
            loadedWords = all
            filterWords()
        }
    }

    private fun filterWords() {
        if (!::countLabel.isInitialized) return
        val query = searchQuery.trim()
        renderWords(loadedWords.filter { it.word.contains(query, true) || it.meaning.contains(query, true) }, loadedWords.size)
    }

    private fun renderWords(words: List<WordEntry>, total: Int) {
        countLabel.text = if (searchQuery.isBlank()) "我的单词本   $total" else "找到 ${words.size} / $total 个单词"
        wordList.adapter = object : BaseAdapter() {
            override fun getCount() = words.size.coerceAtLeast(1)
            override fun getItem(position: Int): WordEntry? = words.getOrNull(position)
            override fun getItemId(position: Int) = position.toLong()
            override fun isEnabled(position: Int) = words.isNotEmpty()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                if (words.isEmpty()) return TextView(this@MainActivity).apply {
                    text = if (searchQuery.isBlank()) "这里将收纳你遇到的生词" else "没有匹配的单词"
                    textSize = 14f; gravity = Gravity.CENTER; setPadding(dp(12), dp(34), dp(12), dp(34))
                }
                val entry = words[position]
                val card = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), dp(10), dp(8), dp(10)); background = rounded(0xFFF7F7F7.toInt(), 14) }
                val wordsText = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(3), 0, dp(3)) }
                wordsText.addView(TextView(this@MainActivity).apply { text = entry.word; textSize = 18f; setTextColor(0xFF111111.toInt()); typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD) })
                wordsText.addView(TextView(this@MainActivity).apply { text = entry.meaning; textSize = 13f; setTextColor(0xFF777777.toInt()); setPadding(0, dp(4), 0, 0) })
                card.addView(wordsText, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                val editButton = Button(this@MainActivity).apply {
                    text = "编辑"; isAllCaps = false; textSize = 12f
                    setTextColor(0xFF111111.toInt())
                    background = rounded(0xFFFFFFFF.toInt(), 9)
                    minWidth = 0; minimumWidth = 0; minHeight = 0; minimumHeight = 0
                    setPadding(dp(8), 0, dp(8), 0)
                    setOnClickListener { editMeaning(entry.word, entry.meaning) }
                }
                val editParams = LinearLayout.LayoutParams(dp(62), dp(36))
                editParams.leftMargin = dp(4)
                card.addView(editButton, editParams)
                val deleteButton = Button(this@MainActivity).apply {
                    text = "删除"; isAllCaps = false; textSize = 12f
                    setTextColor(0xFF666666.toInt())
                    background = rounded(0xFFEAEAEA.toInt(), 9)
                    minWidth = 0; minimumWidth = 0; minHeight = 0; minimumHeight = 0
                    setPadding(dp(8), 0, dp(8), 0)
                    setOnClickListener { confirmDeleteWord(entry.word) }
                }
                val deleteParams = LinearLayout.LayoutParams(dp(62), dp(36))
                deleteParams.leftMargin = dp(4)
                card.addView(deleteButton, deleteParams)
                return card
            }
        }
    }

    private fun confirmDeleteWord(word: String) {
        AlertDialog.Builder(this)
            .setTitle("删除单词？")
            .setMessage("确定要删除「$word」吗？删除后将从单词本中移除。")
            .setNegativeButton("返回", null)
            .setPositiveButton("删除") { _, _ ->
                background({ WordStore.delete(applicationContext, word) }) { refreshWords() }
            }
            .show()
    }

    private fun rounded(color: Int, radiusDp: Int): android.graphics.drawable.GradientDrawable =
        android.graphics.drawable.GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radiusDp).toFloat()
        }

    private fun editMeaning(word: String, current: String) {
        val input = EditText(this).apply { setText(current); hint = "中文释义"; minLines = 2 }
        AlertDialog.Builder(this).setTitle(word).setView(input).setNegativeButton("取消", null)
            .setPositiveButton("保存释义") { _, _ ->
                val meaning = input.text.toString().trim()
                background({ WordStore.updateMeaning(applicationContext, word, meaning) }) { refreshWords() }
            }.show()
    }

    private fun importCsv() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("text/csv", "text/comma-separated-values", "text/plain", "application/octet-stream"))
        }, REQUEST_IMPORT)
    }

    private fun exportCsv() {
        startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "text/csv"
            putExtra(Intent.EXTRA_TITLE, "PocketWords-${java.time.LocalDate.now()}.csv")
        }, REQUEST_EXPORT)
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    companion object {
        private const val REQUEST_CAPTURE = 4102
        private const val REQUEST_CAMERA = 4103
        private const val REQUEST_IMPORT = 4104
        private const val REQUEST_EXPORT = 4105
        private const val KEY_PHOTO_LOOKUP_URI = "photo_lookup_uri"
        private const val PHOTO_MAX_SIDE = 2048
    }
}

package com.pocketwords.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapRegionDecoder
import android.graphics.Matrix
import android.graphics.Rect
import android.graphics.RectF
import android.media.ExifInterface
import android.net.Uri
import kotlin.math.ceil
import kotlin.math.floor

/** Preview uses little memory; region recognition always reopens original pixels. */
internal class OriginalPhoto(private val context: Context, val uri: Uri) {
    private fun bounds(): BitmapFactory.Options = BitmapFactory.Options().apply {
        inJustDecodeBounds = true
        context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, this) }
        check(outWidth > 0 && outHeight > 0) { "无法读取原图尺寸" }
    }
    private fun orientation(): Int = runCatching { context.contentResolver.openInputStream(uri)?.use {
        ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
    } ?: ExifInterface.ORIENTATION_NORMAL }.getOrDefault(ExifInterface.ORIENTATION_NORMAL)
    private fun orient(bitmap: Bitmap, orientation: Int): Bitmap {
        if (orientation == ExifInterface.ORIENTATION_NORMAL || orientation == ExifInterface.ORIENTATION_UNDEFINED) return bitmap
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, transform(orientation), true).also { if (it !== bitmap) bitmap.recycle() }
    }
    fun preview(maxSide: Int = 2048): Bitmap {
        val bounds = bounds()
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / sample > maxSide) sample *= 2
        val image = context.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
        } ?: error("无法读取图片")
        return orient(image, orientation())
    }
    @Suppress("DEPRECATION")
    fun crop(area: RectF, maxSide: Int = 4096): Bitmap {
        require(area.left >= 0 && area.top >= 0 && area.right <= 1 && area.bottom <= 1 && area.width() > 0 && area.height() > 0)
        val info = bounds(); val orientation = orientation()
        val rect = regionRect(info.outWidth, info.outHeight, orientation, area)
        var sample = 1
        while (maxOf(rect.width(),rect.height()) / sample > maxSide) sample *= 2
        val bitmap = context.contentResolver.openInputStream(uri)?.use { stream ->
            val decoder = checkNotNull(BitmapRegionDecoder.newInstance(stream, false))
            try { checkNotNull(decoder.decodeRegion(rect, BitmapFactory.Options().apply { inSampleSize = sample })) }
            finally { decoder.recycle() }
        } ?: error("无法读取原图区域")
        return orient(bitmap, orientation)
    }
    companion object {
        fun load(context: Context, uri: Uri?, thumbnail: Bitmap?): Pair<Bitmap?,OriginalPhoto?> {
            val original=uri?.let { OriginalPhoto(context,it) }
            val preview=original?.let { runCatching { it.preview() }.getOrNull() }
            if (preview != null) {
                if (thumbnail != null && thumbnail !== preview) thumbnail.recycle()
                return preview to original
            }
            return thumbnail to null
        }

        fun regionRect(width: Int, height: Int, orientation: Int, area: RectF): Rect {
        val matrix = transform(orientation)
        val oriented = RectF(0f,0f,width.toFloat(),height.toFloat())
        matrix.mapRect(oriented); matrix.postTranslate(-oriented.left,-oriented.top)
        val raw = RectF(area.left*oriented.width(),area.top*oriented.height(),area.right*oriented.width(),area.bottom*oriented.height())
        val inverse = Matrix(); check(matrix.invert(inverse)); inverse.mapRect(raw)
        return Rect(floor(raw.left).toInt().coerceIn(0,width-1),floor(raw.top).toInt().coerceIn(0,height-1),
            ceil(raw.right).toInt().coerceIn(1,width),ceil(raw.bottom).toInt().coerceIn(1,height))
        }

        fun compose(parent: RectF, child: RectF) = RectF(parent.left+child.left*parent.width(),parent.top+child.top*parent.height(),parent.left+child.right*parent.width(),parent.top+child.bottom*parent.height())
        fun transform(orientation: Int) = Matrix().apply {
            val values = when (orientation) {
                ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> floatArrayOf(-1f,0f,0f,0f,1f,0f,0f,0f,1f)
                ExifInterface.ORIENTATION_ROTATE_180 -> floatArrayOf(-1f,0f,0f,0f,-1f,0f,0f,0f,1f)
                ExifInterface.ORIENTATION_FLIP_VERTICAL -> floatArrayOf(1f,0f,0f,0f,-1f,0f,0f,0f,1f)
                ExifInterface.ORIENTATION_TRANSPOSE -> floatArrayOf(0f,1f,0f,1f,0f,0f,0f,0f,1f)
                ExifInterface.ORIENTATION_ROTATE_90 -> floatArrayOf(0f,-1f,0f,1f,0f,0f,0f,0f,1f)
                ExifInterface.ORIENTATION_TRANSVERSE -> floatArrayOf(0f,-1f,0f,-1f,0f,0f,0f,0f,1f)
                ExifInterface.ORIENTATION_ROTATE_270 -> floatArrayOf(0f,1f,0f,-1f,0f,0f,0f,0f,1f)
                else -> floatArrayOf(1f,0f,0f,0f,1f,0f,0f,0f,1f)
            }
            setValues(values)
        }
    }
}

package com.pocketwords.app

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.RectF
import android.net.Uri
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import java.io.File

/** Runs on Android itself: real decoder pixels and actual on-disk transactions. */
@RunWith(AndroidJUnit4::class)
class DeviceSmokeTest {
    @Test fun nativeRegionDecoderReturnsTheSelectedPixels() {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val file = File.createTempFile("device-region-", ".png", context.cacheDir)
        val bitmap = Bitmap.createBitmap(120, 60, Bitmap.Config.ARGB_8888)
        try {
            bitmap.eraseColor(Color.RED)
            for (y in 0 until 60) for (x in 60 until 120) bitmap.setPixel(x,y,Color.BLUE)
            file.outputStream().use { assertTrue(bitmap.compress(Bitmap.CompressFormat.PNG,100,it)) }
            val crop = OriginalPhoto(context, Uri.fromFile(file)).crop(RectF(.5f,0f,1f,1f))
            try { assertEquals(60, crop.width); assertEquals(Color.BLUE, crop.getPixel(30,30)) }
            finally { crop.recycle() }
        } finally { bitmap.recycle(); file.delete() }
    }
    @Test fun interruptedCollectionDoesNotLeaveHalfSavedVocabulary() {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val word = "device-test-" + java.util.UUID.randomUUID()
        try {
            try {
                ReviewStore.atomic(context) {
                    WordStore.add(context, word, "测试")
                    ReviewStore.recordEncounter(context, word, "Example.", "", "")
                    error("simulated interruption")
                }
            } catch (_: IllegalStateException) { }
            assertFalse(WordStore.allEntries(context).any { it.word == word })
            assertTrue(ReviewStore.cards(context, listOf(WordEntry(word,"测试"))).single().contexts.isEmpty())
        } finally { WordStore.delete(context, word) }
    }
}

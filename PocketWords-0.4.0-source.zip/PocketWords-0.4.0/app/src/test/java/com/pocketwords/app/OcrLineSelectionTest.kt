package com.pocketwords.app

import android.app.Activity
import android.app.AlertDialog
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [26, 35])
class OcrLineSelectionTest {
    @Test fun selectsOnlyDesiredLinesInReadingOrderIncludingDuplicateLines() {
        val controller = Robolectric.buildActivity(Activity::class.java).setup()
        val activity = controller.get()
        var result: String? = null
        val dialog = OcrLineSelectionDialog.show(activity, "Menu\n\n Read this.\nRead this.\nNext line!\nButton") { result = it }
        assertEquals(5, dialog.listView.count)
        assertFalse(dialog.getButton(AlertDialog.BUTTON_POSITIVE).isEnabled)
        fun select(index: Int) {
            dialog.listView.performItemClick(null, index, index.toLong())
        }
        select(3); select(1); select(2)
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).performClick()
        assertEquals("Read this.\nRead this.\nNext line!", result)
        controller.pause().stop().destroy()
    }
    @Test fun allCanBeClearedAndCancelDoesNotTranslate() {
        val controller = Robolectric.buildActivity(Activity::class.java).setup()
        var result: String? = null
        val dialog = OcrLineSelectionDialog.show(controller.get(), "First\nSecond") { result = it }
        val all = dialog.getButton(AlertDialog.BUTTON_NEUTRAL)
        all.performClick(); assertTrue(dialog.getButton(AlertDialog.BUTTON_POSITIVE).isEnabled)
        all.performClick(); assertFalse(dialog.getButton(AlertDialog.BUTTON_POSITIVE).isEnabled)
        dialog.getButton(AlertDialog.BUTTON_NEGATIVE).performClick(); assertNull(result)
        controller.pause().stop().destroy()
    }
    @Test fun oversizedSelectionStaysOpenWithoutSilentlyTruncating() {
        val controller = Robolectric.buildActivity(Activity::class.java).setup()
        var result: String? = null
        val dialog = OcrLineSelectionDialog.show(controller.get(), "x".repeat(3001)) { result = it }
        dialog.getButton(AlertDialog.BUTTON_NEUTRAL).performClick()
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).performClick()
        assertNull(result); assertTrue(dialog.isShowing)
        dialog.dismiss(); controller.pause().stop().destroy()
    }
}

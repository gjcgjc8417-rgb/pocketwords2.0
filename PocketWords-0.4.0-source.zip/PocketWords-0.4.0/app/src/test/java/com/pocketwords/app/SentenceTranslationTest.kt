package com.pocketwords.app

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipboardManager
import android.content.Context
import android.widget.EditText
import android.widget.TextView
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.shadows.ShadowAlertDialog

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [26, 35])
class SentenceTranslationTest {
    private val controller = Robolectric.buildActivity(Activity::class.java)
    private lateinit var activity: Activity
    private lateinit var sheet: SentenceTranslationDialog
    private lateinit var dialog: AlertDialog
    private val fake = FakeTranslator()
    private fun input() = dialog.window!!.decorView.findViewWithTag<EditText>("sentence_input")
    private fun output() = dialog.window!!.decorView.findViewWithTag<TextView>("sentence_output")
    private fun submit() = dialog.getButton(AlertDialog.BUTTON_POSITIVE).performClick()
    @Before fun setup() {
        activity = controller.setup().get()
        sheet = SentenceTranslationDialog(activity) { fake }
        sheet.show("Hello world.")
        dialog = ShadowAlertDialog.getLatestAlertDialog()
    }
    @After fun cleanup() { sheet.dismiss(); controller.pause().stop().destroy() }
    @Test fun translatesWholeInputAndCopiesChineseResult() {
        submit(); assertEquals("Hello world.", fake.request)
        fake.success("你好，世界。")
        assertEquals("你好，世界。", output().text.toString())
        dialog.getButton(AlertDialog.BUTTON_NEUTRAL).performClick()
        val clipboard = activity.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        assertEquals("你好，世界。", clipboard.primaryClip!!.getItemAt(0).text.toString())
    }
    @Test fun rejectsBlankWithoutStartingModelDownload() {
        input().setText("  \n "); submit(); assertNull(fake.request); assertNotNull(input().error)
    }
    @Test fun editingWhileTranslatingDiscardsOldResultAndAllowsNewRequest() {
        submit(); input().setText("A new sentence."); fake.success("旧译文")
        assertFalse(output().text.contains("旧译文"))
        assertTrue(dialog.getButton(AlertDialog.BUTTON_POSITIVE).isEnabled)
        assertFalse(dialog.getButton(AlertDialog.BUTTON_NEUTRAL).isEnabled)
        submit(); assertEquals("A new sentence.", fake.request)
        fake.success("一个新句子。"); assertEquals("一个新句子。", output().text.toString())
    }
    @Test fun failedDownloadCanBeRetried() {
        submit(); fake.failure(IllegalStateException("offline"))
        assertTrue(dialog.getButton(AlertDialog.BUTTON_POSITIVE).isEnabled)
        assertFalse(dialog.getButton(AlertDialog.BUTTON_NEUTRAL).isEnabled)
        submit(); fake.success("你好"); assertEquals("你好", output().text.toString())
    }
    @Test fun dismissClosesClientAndIgnoresLateCallbacks() {
        submit(); sheet.dismiss()
        org.robolectric.Shadows.shadowOf(android.os.Looper.getMainLooper()).idle()
        assertTrue(fake.closed)
        fake.success("迟到的译文"); assertFalse(output().text.contains("迟到"))
    }
    @Test fun limitsLongPastedTextAndKeepsSentencePunctuation() {
        input().setText("a".repeat(4000)); assertEquals(3000, input().text.length)
        input().setText("Don't stop. Keep going!\nIs that clear?")
        submit(); assertEquals("Don't stop. Keep going!\nIs that clear?", fake.request)
    }
    @Test fun modelDownloadIsExplicitAndFailureCanBeRetried() {
        sheet.dismiss(); org.robolectric.Shadows.shadowOf(android.os.Looper.getMainLooper()).idle()
        fake.ready = false
        sheet = SentenceTranslationDialog(activity) { fake }; sheet.show("Hello.")
        dialog = ShadowAlertDialog.getLatestAlertDialog()
        val status = dialog.window!!.decorView.findViewWithTag<TextView>("model_status")
        val download = dialog.window!!.decorView.findViewWithTag<android.widget.Button>("model_download")
        assertEquals(0, fake.downloads); assertTrue(status.text.contains("未下载"))
        assertFalse(dialog.getButton(AlertDialog.BUTTON_POSITIVE).isEnabled)
        download.performClick(); assertEquals(1, fake.downloads)
        assertTrue(status.text.contains("下载中")); assertFalse(download.isEnabled)
        fake.downloadFailure(IllegalStateException("network"))
        assertTrue(status.text.contains("下载失败")); assertEquals("重试下载", download.text.toString())
        download.performClick(); fake.ready = true; fake.downloadSuccess()
        assertTrue(status.text.contains("可离线使用"))
        assertTrue(dialog.getButton(AlertDialog.BUTTON_POSITIVE).isEnabled)
        submit(); assertEquals("Hello.", fake.request)
    }
    @Test fun localModelCheckDoesNotDownloadOrRequireTranslation() {
        assertEquals(0, fake.downloads)
        assertTrue(dialog.window!!.decorView.findViewWithTag<TextView>("model_status").text.contains("可离线使用"))
    }
    @Test fun unavailableModelCheckHasAnExplicitRetryWithoutDownloading() {
        sheet.dismiss(); org.robolectric.Shadows.shadowOf(android.os.Looper.getMainLooper()).idle()
        fake.checkFails = true
        sheet = SentenceTranslationDialog(activity) { fake }; sheet.show("Hello")
        dialog = ShadowAlertDialog.getLatestAlertDialog()
        val action = dialog.window!!.decorView.findViewWithTag<android.widget.Button>("model_download")
        assertEquals("重新检查", action.text.toString())
        assertFalse(dialog.getButton(AlertDialog.BUTTON_POSITIVE).isEnabled)
        fake.checkFails = false; action.performClick()
        assertEquals(0, fake.downloads)
        assertTrue(dialog.getButton(AlertDialog.BUTTON_POSITIVE).isEnabled)
    }
    @Test fun dismissDuringDownloadReleasesClientAndIgnoresCompletion() {
        sheet.dismiss(); org.robolectric.Shadows.shadowOf(android.os.Looper.getMainLooper()).idle()
        val downloadingFake = FakeTranslator().apply { ready = false }
        sheet = SentenceTranslationDialog(activity) { downloadingFake }; sheet.show("Hello")
        dialog = ShadowAlertDialog.getLatestAlertDialog()
        dialog.window!!.decorView.findViewWithTag<android.widget.Button>("model_download").performClick()
        val status = dialog.window!!.decorView.findViewWithTag<TextView>("model_status")
        sheet.dismiss(); org.robolectric.Shadows.shadowOf(android.os.Looper.getMainLooper()).idle()
        assertTrue(downloadingFake.closed)
        downloadingFake.ready = true; downloadingFake.downloadSuccess()
        assertFalse(status.text.contains("可离线使用"))
    }
    private class FakeTranslator : SentenceTranslator {
        var request: String? = null
        var closed = false
        lateinit var success: (String) -> Unit
        lateinit var failure: (Exception) -> Unit
        var checkFails = false
        var ready = true
        var downloads = 0
        lateinit var downloadSuccess: () -> Unit
        lateinit var downloadFailure: (Exception) -> Unit
        override fun checkModel(success: (Boolean) -> Unit, failure: (Exception) -> Unit) {
            if (checkFails) failure(IllegalStateException("model check")) else success(ready)
        }
        override fun download(success: () -> Unit, failure: (Exception) -> Unit) {
            downloads++; downloadSuccess = success; downloadFailure = failure
        }
        override fun translate(text: String, success: (String) -> Unit, failure: (Exception) -> Unit) {
            request = text; this.success = success; this.failure = failure
        }
        override fun close() { closed = true }
    }
}

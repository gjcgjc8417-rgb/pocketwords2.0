package com.pocketwords.app

import org.junit.Assert.*
import org.junit.Test
import java.time.Instant

class ReviewEngineTest {
    private val now = Instant.parse("2026-10-01T12:00:00Z").toEpochMilli()
    private fun card(word: String, p: ReviewProfile = ReviewProfile(word), sentence: String = "") =
        ReviewCard(WordEntry(word, "中文释义"), p, if (sentence.isBlank()) emptyList() else listOf(ReadingContext(sentence = sentence)))
    @Test fun sameDayPracticeDoesNotInflateMasteryAndForgettingReducesLevel() {
        val first = ReviewEngine.advance(SkillProgress(), 2, now)
        assertEquals(1, first.level); assertEquals(now + ReviewEngine.DAY, first.due)
        assertEquals(1, ReviewEngine.advance(first, 2, now + 1000).level)
        val second = ReviewEngine.advance(first, 2, now + ReviewEngine.DAY)
        assertEquals(2, second.level); assertEquals(now + 4 * ReviewEngine.DAY, second.due)
        val missed = ReviewEngine.advance(second, 0, now + 2 * ReviewEngine.DAY)
        assertEquals(1, missed.level); assertEquals(1, missed.errors)
        assertFalse(ReviewProfile("word", meaning = SkillProgress(6), spelling = SkillProgress(0)).mastered)
    }
    @Test fun pausedAndMissingMeaningNeverBecomeQuestions() {
        val entries = listOf(card("one", ReviewProfile("one", paused = true)), card("two").copy(entry = WordEntry("two", WordStore.MISSING_MEANING)), card("three"))
        assertEquals(listOf("three"), ReviewEngine.plan(entries, ReviewScope.ALL, ReviewMode.MIXED, now).map { it.word })
    }
    @Test fun dueSkillIsRespectedAndOldDueWordsPrecedeNewWords() {
        val old = card("old", ReviewProfile("old", meaning = SkillProgress(2, now - 1), spelling = SkillProgress(2, now + ReviewEngine.DAY)))
        val new = card("new")
        val plan = ReviewEngine.plan(listOf(new, old), ReviewScope.DUE, ReviewMode.MIXED, now)
        assertEquals("old", plan.first().word); assertEquals(QuizKind.RECALL, plan.first().kind)
        assertTrue(ReviewEngine.plan(listOf(old), ReviewScope.DUE, ReviewMode.SPELL, now).isEmpty())
    }
    @Test fun clozeRequiresAnExactWholeWordAndHidesEveryOccurrence() {
        assertNull(ReviewEngine.cloze("An adventure.", "vent"))
        assertEquals("An ______. Another ______!", ReviewEngine.cloze("An adventure. Another ADVENTURE!", "adventure"))
        val cards = listOf(card("adventure", sentence = "An adventure."), card("missing", sentence = "Other words."))
        assertEquals(listOf("adventure"), ReviewEngine.plan(cards, ReviewScope.ALL, ReviewMode.CLOZE, now).map { it.word })
    }
    @Test fun mixedModeMovesFromRecognitionToContextOrSpelling() {
        val learned = ReviewProfile("hello", meaning = SkillProgress(1, now + ReviewEngine.DAY))
        assertEquals(QuizKind.RECALL, ReviewEngine.plan(listOf(card("hello")), ReviewScope.ALL, ReviewMode.MIXED, now).single().kind)
        assertEquals(QuizKind.SPELL, ReviewEngine.plan(listOf(card("hello", learned)), ReviewScope.ALL, ReviewMode.MIXED, now).single().kind)
        assertEquals(QuizKind.CLOZE, ReviewEngine.plan(listOf(card("hello", learned, "Say hello.")), ReviewScope.ALL, ReviewMode.MIXED, now).single().kind)
    }
    @Test fun retriesAreInterleavedBoundedAndUseAnotherExercise() {
        val run = ReviewRun((1..5).map { ReviewTask("word$it", QuizKind.RECALL) }.toMutableList())
        run.record(0)
        assertEquals(6, run.tasks.size); assertTrue(run.tasks[4].retry); assertEquals(QuizKind.SPELL, run.tasks[4].kind)
        repeat(3) { run.record(2) }
        run.record(0)
        assertEquals(6, run.tasks.size)
        assertEquals(1, run.wrong.size)
    }
    @Test fun spellingChecksSavedWordWithoutGuessingSynonyms() {
        assertTrue(ReviewEngine.isCorrect(" Hello ", "hello"))
        assertFalse(ReviewEngine.isCorrect("world", "hello"))
        assertFalse(ReviewEngine.isCorrect("hello!", "hello"))
    }
}

package com.pocketwords.app

import org.junit.Assert.*
import org.junit.Test

class CaptureFrameBufferTest {
    private class Frame(val name: String) { var closes = 0 }
    @Test fun staticFrameAvailableDuringSettleDelayCanBeTakenWithoutWaitingForAnotherFrame() {
        val frames = CaptureFrameBuffer<Frame> { it.closes++ }
        val old = Frame("old app"); frames.offer(old)
        val sequence = frames.sequence
        assertNull(frames.takeNewerThan(sequence))
        val source = Frame("source after bubble hidden"); frames.offer(source)
        assertEquals(1, old.closes)
        // No new frame is produced after this: a still page must remain capturable.
        assertSame(source, frames.takeNewerThan(sequence))
        assertNull(frames.takeNewerThan(sequence))
        frames.clear(); assertEquals(0, source.closes) // The consumer now owns the taken image.
        val nextRequest = frames.sequence
        val second = Frame("source on the next lookup")
        assertNull(frames.takeNewerThan(nextRequest))
        frames.offer(second)
        assertSame(second, frames.takeNewerThan(nextRequest))
    }
    @Test fun onlyTheLatestFrameIsKeptAndReleaseClosesItOnce() {
        val frames = CaptureFrameBuffer<Frame> { it.closes++ }
        val first = Frame("first"); val latest = Frame("latest")
        frames.offer(first); frames.offer(latest)
        assertEquals(1, first.closes)
        frames.clear(); frames.clear()
        assertEquals(1, latest.closes)
        assertNull(frames.takeNewerThan(0))
    }
}

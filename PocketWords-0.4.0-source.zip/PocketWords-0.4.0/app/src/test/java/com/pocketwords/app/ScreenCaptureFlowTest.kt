package com.pocketwords.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.os.Looper
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.shadows.ShadowAlertDialog
import java.io.File
import java.time.Duration

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [26, 35])
class ScreenCaptureFlowTest {
    private lateinit var context: Context
    @Before fun prepare() {
        context = RuntimeEnvironment.getApplication()
        CaptureService::class.java.getDeclaredField("sessionActive").apply { isAccessible = true }.setBoolean(null, false)
    }
    @After fun reset() {
        CaptureService::class.java.getDeclaredField("sessionActive").apply { isAccessible = true }.setBoolean(null, false)
    }
    private fun resultIntent(): Intent {
        val image = File.createTempFile("screen-", ".png", context.cacheDir)
        val bitmap = Bitmap.createBitmap(200, 100, Bitmap.Config.ARGB_8888)
        image.outputStream().use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }; bitmap.recycle()
        return Intent(context, ScreenLookupActivity::class.java).setAction(CaptureService.ACTION_OCR_RESULT)
            .putExtra(CaptureService.EXTRA_TEXT, "hello").putExtra(CaptureService.EXTRA_IMAGE_PATH, image.path)
            .putExtra(CaptureService.EXTRA_WORD_BOXES, "[]").putExtra(CaptureService.EXTRA_IMAGE_WIDTH, 200).putExtra(CaptureService.EXTRA_IMAGE_HEIGHT, 100)
    }
    @Test fun resultUsesATransientHostAndClosingItKeepsTheProjectionAvailable() {
        val intent = resultIntent()
        val controller = Robolectric.buildActivity(ScreenLookupActivity::class.java, intent).setup()
        val activity = controller.get()
        CaptureService::class.java.getDeclaredField("sessionActive").apply { isAccessible = true }.setBoolean(null, true)
        assertNull(activity.window.decorView.findViewWithTag<android.view.View>("screen_lookup"))
        assertNull(shadowOf(activity).nextStartedActivity)
        ShadowAlertDialog.getLatestAlertDialog().getButton(AlertDialog.BUTTON_NEGATIVE).performClick()
        shadowOf(Looper.getMainLooper()).idle()
        assertTrue(activity.isFinishing); assertTrue(CaptureService.sessionActive)
        controller.pause().stop().destroy(); shadowOf(Looper.getMainLooper()).idle()
        assertFalse(File(intent.getStringExtra(CaptureService.EXTRA_IMAGE_PATH)!!).exists())
    }
    @Test fun leavingTheResultToReturnToTheSourceFinishesOnlyTheTemporaryTask() {
        val controller = Robolectric.buildActivity(ScreenLookupActivity::class.java, resultIntent()).setup()
        val activity = controller.get()
        controller.pause().stop()
        assertTrue(activity.isFinishing)
        assertNull(shadowOf(activity).nextStartedActivity)
        controller.destroy(); shadowOf(Looper.getMainLooper()).idle()
    }
    @Test fun retakeClosesTheResultAndRequestsConsentWithoutOpeningVocabularyHome() {
        val controller = Robolectric.buildActivity(ScreenLookupActivity::class.java, resultIntent()).setup()
        val activity = controller.get()
        ShadowAlertDialog.getLatestAlertDialog().getButton(AlertDialog.BUTTON_NEUTRAL).performClick()
        shadowOf(Looper.getMainLooper()).idle()
        assertTrue(activity.isFinishing)
        assertEquals(ScreenCaptureConsentActivity::class.java.name, shadowOf(activity).nextStartedActivity.component!!.className)
        controller.pause().stop().destroy(); shadowOf(Looper.getMainLooper()).idle()
    }
    @Test fun aChildLinePickerKeepsTheTransientHostAliveUntilItIsClosed() {
        val controller = Robolectric.buildActivity(ScreenLookupActivity::class.java, resultIntent()).setup()
        val activity = controller.get()
        val preview = ShadowAlertDialog.getLatestAlertDialog()
        preview.window!!.decorView.findViewWithTag<android.view.View>("ocr_more").performClick()
        org.robolectric.shadows.ShadowPopupMenu.getLatestPopupMenu().menu.performIdentifierAction(3,0)
        val picker = ShadowAlertDialog.getLatestAlertDialog()
        preview.dismiss(); shadowOf(Looper.getMainLooper()).idle()
        assertFalse(activity.isFinishing)
        picker.getButton(AlertDialog.BUTTON_NEGATIVE).performClick(); shadowOf(Looper.getMainLooper()).idle()
        assertTrue(activity.isFinishing)
        controller.pause().stop().destroy(); shadowOf(Looper.getMainLooper()).idle()
    }
    @Test fun cancelingConsentReturnsToTheSourceWithoutStartingCapture() {
        val controller = Robolectric.buildActivity(ScreenCaptureConsentActivity::class.java).setup()
        val activity = controller.get()
        assertNotNull(shadowOf(activity).nextStartedActivityForResult)
        ScreenCaptureConsentActivity::class.java.getDeclaredMethod("onActivityResult", Int::class.javaPrimitiveType, Int::class.javaPrimitiveType, Intent::class.java)
            .apply { isAccessible = true }.invoke(activity, ScreenCaptureConsentActivity.REQUEST_CAPTURE, Activity.RESULT_CANCELED, null)
        assertTrue(activity.isFinishing); assertNull(shadowOf(activity).nextStartedService)
        controller.pause().stop().destroy()
    }
    @Test fun consentStartsCaptureAndFinishesTheTransparentTrampoline() {
        val controller = Robolectric.buildActivity(ScreenCaptureConsentActivity::class.java).setup()
        val activity = controller.get()
        ScreenCaptureConsentActivity::class.java.getDeclaredMethod("onActivityResult", Int::class.javaPrimitiveType, Int::class.javaPrimitiveType, Intent::class.java)
            .apply { isAccessible = true }.invoke(activity, ScreenCaptureConsentActivity.REQUEST_CAPTURE, Activity.RESULT_OK, Intent("fresh-consent"))
        val started = shadowOf(activity).nextStartedService
        assertEquals(CaptureService::class.java.name, started.component!!.className)
        assertEquals(Activity.RESULT_OK, started.getIntExtra(CaptureService.EXTRA_RESULT_CODE, 0))
        assertTrue(activity.isFinishing)
        controller.pause().stop().destroy()
    }
    @Test fun aStaleCaptureRequestNeverStartsForegroundWithoutFreshConsent() {
        val controller = Robolectric.buildService(CaptureService::class.java).create()
        val service = controller.get()
        service.onStartCommand(Intent(service, CaptureService::class.java).setAction(CaptureService.ACTION_CAPTURE_ONCE), 0, 1)
        assertNull(shadowOf(service).lastForegroundNotification)
        assertTrue(shadowOf(service).isStoppedBySelf); assertFalse(CaptureService.sessionActive)
        ScreenCaptureFlow.request(service)
        assertEquals(ScreenCaptureConsentActivity::class.java.name, shadowOf(service).nextStartedActivity.component!!.className)
        controller.destroy()
    }
    @Test fun noFreshFrameTimesOutAndMakesTheNextTapAskForConsent() {
        val controller = Robolectric.buildService(CaptureService::class.java).create()
        val service = controller.get()
        CaptureService::class.java.getDeclaredField("sessionActive").apply { isAccessible = true }.setBoolean(null, true)
        CaptureService::class.java.getDeclaredMethod("requestCapture").apply { isAccessible = true }.invoke(service)
        shadowOf(Looper.getMainLooper()).idleFor(Duration.ofSeconds(6))
        assertFalse(CaptureService.sessionActive); assertTrue(shadowOf(service).isStoppedBySelf)
        ScreenCaptureFlow.request(service)
        assertEquals(ScreenCaptureConsentActivity::class.java.name, shadowOf(service).nextStartedActivity.component!!.className)
        controller.destroy()
    }
    @Test fun stoppingCaptureCancelsADelayedResultAndDeletesItsUnclaimedImage() {
        val controller = Robolectric.buildService(CaptureService::class.java).create()
        val service = controller.get()
        val file = File.createTempFile("screen-", ".png", service.cacheDir)
        var opened = false
        val pending = Runnable { opened = true }
        CaptureService::class.java.getDeclaredField("pendingResultFile").apply { isAccessible = true }.set(service, file)
        CaptureService::class.java.getDeclaredField("pendingDelivery").apply { isAccessible = true }.set(service, pending)
        val handler = CaptureService::class.java.getDeclaredField("handler").apply { isAccessible = true }.get(service) as android.os.Handler
        handler.postDelayed(pending, 100)
        service.onStartCommand(Intent(service, CaptureService::class.java).setAction(CaptureService.ACTION_STOP_CAPTURE), 0, 1)
        shadowOf(Looper.getMainLooper()).idleFor(Duration.ofSeconds(1))
        assertFalse(opened); assertFalse(file.exists())
        assertNull(shadowOf(service).nextStartedActivity)
        controller.destroy()
    }
}

package com.pocketwords.app

import org.junit.Assert.*
import org.junit.Test
import java.util.Locale

class WordFormsTest {
    @Test fun inflectedFormsUseTheFullDictionary() {
        val dictionary = mapOf("synthesize" to "合成", "stop" to "停止", "study" to "学习", "run" to "跑")
        for ((word, expected) in mapOf("synthesizing" to "合成", "stopped" to "停止", "studies" to "学习", "running" to "跑")) {
            assertEquals(expected, WordForms.lookup(word, dictionary::get) { null })
        }
    }
    @Test fun exactWordTakesPrecedenceOverStemming() {
        assertEquals("新闻", WordForms.lookup("news", mapOf("news" to "新闻", "new" to "新")::get) { null })
    }
    @Test fun normalizationDoesNotDependOnPhoneLocale() {
        val original = Locale.getDefault()
        try { Locale.setDefault(Locale.forLanguageTag("tr")); assertEquals("intelligent", WordForms.key(" INTELLIGENT! ")) }
        finally { Locale.setDefault(original) }
    }
    @Test fun unknownWordsStayUnknown() { assertNull(WordForms.lookup("zzzzing", { null }, { null })) }
    @Test fun phrasesAreNotStemmed() { assertEquals(listOf("look forward to"), WordForms.candidates("look forward to")) }
}

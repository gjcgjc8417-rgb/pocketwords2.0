package com.pocketwords.app

import org.junit.Assert.assertEquals
import org.junit.Test

class OcrTextTest {
    @Test fun joinsWrappedLinesAndKeepsParagraphs() {
        assertEquals("This is a sentence.\n\nNext paragraph.",
            OcrText.merge(" This is\r\na sentence.\r\n \t\r\nNext\r\nparagraph. "))
    }

    @Test fun joinsWordsSplitAcrossLinesWithoutRemovingOrdinaryHyphens() {
        assertEquals("international text and well-known words.",
            OcrText.merge("inter-\nnational text\nand well-known words."))
    }

    @Test fun emptyTextAndRepeatedLinesAreHandled() {
        assertEquals("", OcrText.merge(" \n\n\t"))
        assertEquals("Again. Again.", OcrText.merge("Again.\nAgain."))
    }
}

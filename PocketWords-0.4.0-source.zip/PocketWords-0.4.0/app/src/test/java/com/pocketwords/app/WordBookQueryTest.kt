package com.pocketwords.app

import org.junit.Assert.*
import org.junit.Test

class WordBookQueryTest {
    private val cards = listOf(
        ReviewCard(WordEntry("zebra", "斑马"), ReviewProfile("zebra", meaning = SkillProgress(due = 200), spelling = SkillProgress(due = 200))),
        ReviewCard(WordEntry("apple", "苹果"), ReviewProfile("apple", meaning = SkillProgress(needsWork = true))),
        ReviewCard(WordEntry("blank", WordStore.MISSING_MEANING), ReviewProfile("blank")),
        ReviewCard(WordEntry("paused", "暂停"), ReviewProfile("paused", paused = true))
    )
    @Test fun dueFilterExcludesPausedMissingAndFutureWords() {
        assertEquals(listOf("apple"), WordBookQuery.apply(cards, "", BookFilter.DUE, BookSort.NEWEST, 100).map { it.word })
    }
    @Test fun chineseSearchAndAlphabeticalSortRespectTheSelectedFilter() {
        assertEquals(listOf("apple"), WordBookQuery.apply(cards, "苹果", BookFilter.WEAK, BookSort.ALPHABETICAL, 100).map { it.word })
        assertEquals(listOf("apple", "blank", "paused", "zebra"), WordBookQuery.apply(cards, "", BookFilter.ALL, BookSort.ALPHABETICAL, 100).map { it.word })
    }
}

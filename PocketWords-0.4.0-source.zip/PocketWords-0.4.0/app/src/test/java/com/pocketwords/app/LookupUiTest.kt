package com.pocketwords.app

import android.app.AlertDialog
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.ResolveInfo
import android.database.sqlite.SQLiteDatabase
import android.graphics.Bitmap
import android.os.Looper
import android.provider.MediaStore
import android.widget.EditText
import android.widget.LinearLayout
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.android.controller.ActivityController
import org.robolectric.annotation.Config
import org.robolectric.shadows.ShadowAlertDialog
import java.io.File
import java.time.Duration
import java.util.concurrent.ExecutorService
import java.util.concurrent.TimeUnit

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [26, 31, 34, 35])
class LookupUiTest {
    private lateinit var controller: ActivityController<MainActivity>
    private lateinit var activity: MainActivity
    private lateinit var executor: ExecutorService
    @Before fun prepare() {
        val context: Context = RuntimeEnvironment.getApplication()
        shadowOf(RuntimeEnvironment.getApplication()).grantPermissions("com.pocketwords.app.DYNAMIC_RECEIVER_NOT_EXPORTED_PERMISSION")
        context.getSharedPreferences("pocket_words", Context.MODE_PRIVATE).edit().clear().commit()
        context.deleteDatabase("pocketwords_review.db")
        val field = WordStore::class.java.getDeclaredField("dictionary").apply { isAccessible = true }
        (field.get(WordStore) as? SQLiteDatabase)?.close(); field.set(WordStore, null)
        File(context.filesDir, "pocketwords_dictionary.version").writeText(
            context.assets.open("dictionary.version").bufferedReader().use { it.readText().trim() })
        val file = File(context.filesDir, "pocketwords_dictionary.db"); file.delete()
        SQLiteDatabase.openOrCreateDatabase(file, null).use {
            it.execSQL("CREATE TABLE stardict (word TEXT, translation TEXT, phonetic TEXT)")
            it.execSQL("INSERT INTO stardict VALUES ('hello', '你好', 'həˈləʊ'), ('world', '世界', 'wɜːld')")
        }
        controller = Robolectric.buildActivity(MainActivity::class.java).setup()
        activity = controller.get()
        executor = LookupActivity::class.java.getDeclaredField("io").apply { isAccessible = true }.get(activity) as ExecutorService
        awaitWork()
    }
    private fun awaitWork() {
        executor.submit {}.get(10, TimeUnit.SECONDS)
        shadowOf(Looper.getMainLooper()).idle()
    }
    private fun awaitReview() {
        val ui = MainActivity::class.java.getDeclaredField("reviewUi").apply { isAccessible = true }.get(activity)
        val worker = ReviewUi::class.java.getDeclaredField("io").apply { isAccessible = true }.get(ui) as ExecutorService
        repeat(3) { worker.submit {}.get(10, TimeUnit.SECONDS); shadowOf(Looper.getMainLooper()).idle(); awaitWork() }
    }
    private fun latest() = ShadowAlertDialog.getLatestAlertDialog()
    private fun click(tag: String) = latest().window!!.decorView.findViewWithTag<android.view.View>(tag).performClick()
    private fun inputViaIme(text: String): EditText {
        val dialog = latest()
        val blocked = android.view.WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM or android.view.WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        assertEquals("The review window must accept the input method", 0, dialog.window!!.attributes.flags and blocked)
        val input = dialog.window!!.decorView.findViewWithTag<EditText>("review_answer")
        assertTrue(input.isFocusableInTouchMode); assertTrue(input.showSoftInputOnFocus)
        assertTrue(input.hasFocus())
        val connection = checkNotNull(input.onCreateInputConnection(android.view.inputmethod.EditorInfo()))
        assertTrue(connection.commitText(text, 1))
        return input
    }
    @Test @Config(sdk = [26, 35]) fun spellingQuestionAcceptsTextFromAnInputConnection() {
        WordStore.add(activity, "hello", "你好")
        activity.window.decorView.findViewWithTag<android.view.View>("review_open").performClick(); awaitReview()
        click("review_start")
        latest().window!!.decorView.findViewWithTag<android.widget.Spinner>("review_scope").setSelection(1)
        latest().window!!.decorView.findViewWithTag<android.widget.Spinner>("review_mode").setSelection(2)
        click("review_begin"); awaitReview()
        assertEquals("HELLO", inputViaIme("HELLO").text.toString())
        click("review_check")
        assertEquals(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN,
            latest().window!!.attributes.softInputMode and android.view.WindowManager.LayoutParams.SOFT_INPUT_MASK_STATE)
        click("review_good"); awaitReview()
        assertEquals(1, ReviewStore.profile(activity, "hello").spelling.level)
    }
    @Test @Config(sdk = [26, 35]) fun switchingFromRecallToSpellingAndResumingKeepsTheEditorUsable() {
        WordStore.add(activity, "hello", "你好")
        ReviewStore.saveRun(activity, ReviewRun(mutableListOf(ReviewTask("hello", QuizKind.RECALL), ReviewTask("hello", QuizKind.SPELL))), replace = true)
        activity.window.decorView.findViewWithTag<android.view.View>("review_open").performClick(); awaitReview()
        click("review_resume"); awaitReview(); click("review_reveal"); click("review_good"); awaitReview()
        assertEquals("hel", inputViaIme("hel").text.toString())
        controller.pause(); awaitReview(); controller.resume()
        activity.window.decorView.findViewWithTag<android.view.View>("review_open").performClick(); awaitReview()
        click("review_resume"); awaitReview()
        val restored = latest().window!!.decorView.findViewWithTag<EditText>("review_answer")
        assertEquals("hel", restored.text.toString()); assertEquals(3, restored.selectionStart)
        assertEquals("hello", inputViaIme("lo").text.toString())
        click("review_check"); click("review_good"); awaitReview()
        assertEquals(1, ReviewStore.profile(activity, "hello").spelling.level)
    }
    @Test @Config(sdk = [28]) fun offlineReviewRevealsPhoneticAndSeparatelyTracksRecognition() {
        WordStore.add(activity, "hello", "你好")
        activity.window.decorView.findViewWithTag<android.view.View>("review_open").performClick(); awaitReview()
        click("review_short"); awaitReview()
        assertEquals("hello", latest().window!!.decorView.findViewWithTag<android.widget.TextView>("review_question").text.toString())
        assertNull(latest().window!!.decorView.findViewWithTag<android.widget.TextView>("review_phonetic"))
        click("review_reveal")
        assertEquals("[həˈləʊ]", latest().window!!.decorView.findViewWithTag<android.widget.TextView>("review_phonetic").text.toString())
        click("review_good"); awaitReview()
        val profile = ReviewStore.profile(activity, "hello")
        assertEquals(1, profile.meaning.level); assertEquals(0, profile.spelling.level)
        assertEquals(1, ReviewStore.loadRun(activity)!!.answered)
    }
    @Test @Config(sdk = [28]) fun spellingHintDoesNotCountAsIndependentMastery() {
        WordStore.add(activity, "hello", "你好")
        activity.window.decorView.findViewWithTag<android.view.View>("review_open").performClick(); awaitReview()
        click("review_start")
        latest().window!!.decorView.findViewWithTag<android.widget.Spinner>("review_scope").setSelection(1)
        latest().window!!.decorView.findViewWithTag<android.widget.Spinner>("review_mode").setSelection(2)
        click("review_begin"); awaitReview()
        assertNull(latest().window!!.decorView.findViewWithTag<android.widget.TextView>("review_phonetic"))
        click("review_hint")
        org.robolectric.shadows.ShadowPopupMenu.getLatestPopupMenu().menu.performIdentifierAction(1,0)
        latest().window!!.decorView.findViewWithTag<EditText>("review_answer").setText("HELLO")
        click("review_check"); click("review_good"); awaitReview()
        assertEquals(0, ReviewStore.profile(activity, "hello").spelling.level)
        assertEquals(0, ReviewStore.loadRun(activity)!!.correct)
    }
    @Test @Config(sdk = [28]) fun pausingAndResumingContinuesAfterTheLastCommittedAnswer() {
        WordStore.add(activity, "hello", "你好"); WordStore.add(activity, "world", "世界")
        activity.window.decorView.findViewWithTag<android.view.View>("review_open").performClick(); awaitReview()
        click("review_short"); awaitReview(); click("review_reveal"); click("review_good"); awaitReview()
        val next = latest().window!!.decorView.findViewWithTag<android.widget.TextView>("review_question").text.toString()
        controller.pause(); awaitReview(); controller.resume()
        assertEquals(1, ReviewStore.loadRun(activity)!!.index)
        activity.window.decorView.findViewWithTag<android.view.View>("review_open").performClick(); awaitReview()
        click("review_resume"); awaitReview()
        assertEquals(next, latest().window!!.decorView.findViewWithTag<android.widget.TextView>("review_question").text.toString())
    }
    @Test @Config(sdk = [28]) fun collectionSavesOriginalContextAndOfflinePhoneticWithoutChangingTheWord() {
        val image = Bitmap.createBitmap(100, 100, Bitmap.Config.ARGB_8888)
        LookupActivity::class.java.getDeclaredMethod("showSelectedWordDialog", String::class.java, String::class.java, Bitmap::class.java, String::class.java)
            .apply { isAccessible = true }.invoke(activity, "hello", "Say hello.", image, "capture-one")
        awaitWork()
        assertEquals("[həˈləʊ]", latest().window!!.decorView.findViewWithTag<android.widget.TextView>("word_phonetic").text.toString())
        latest().window!!.decorView.findViewWithTag<android.widget.CheckBox>("word_save_image").isChecked=true
        latest().getButton(AlertDialog.BUTTON_POSITIVE).performClick(); awaitWork()
        val card = ReviewStore.cards(activity, WordStore.allEntries(activity)).single()
        assertEquals("Say hello.", card.contexts.single().sentence)
        assertEquals("capture-one", card.contexts.single().source)
        assertTrue(ReviewStore.imageFile(activity, card.contexts.single().image).exists())
        assertTrue(image.isRecycled)
    }

    @Test @Config(sdk=[28]) fun homeStartsTodayDirectlyWithoutTheSetupScreen() {
        WordStore.add(activity,"hello","你好")
        activity.window.decorView.findViewWithTag<android.view.View>("review_today").performClick();awaitReview()
        assertNotNull(latest().window!!.decorView.findViewWithTag<android.widget.TextView>("review_question"))
        assertNull(latest().window!!.decorView.findViewWithTag<android.widget.Spinner>("review_scope"))
    }
    @Test @Config(sdk=[28]) fun manualCollectionUsesOneEditorAndKeepsExtrasCollapsed() {
        activity.window.decorView.findViewWithTag<android.view.View>("word_add").performClick()
        val dialog=latest();val root=dialog.window!!.decorView
        assertFalse(root.findViewWithTag<EditText>("word_context").isShown)
        assertFalse(root.findViewWithTag<android.widget.CheckBox>("word_save_image").isChecked)
        val editor=root.findViewWithTag<EditText>("word_input")
        checkNotNull(editor.onCreateInputConnection(android.view.inputmethod.EditorInfo())).commitText("hello",1)
        shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(350));awaitWork()
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).performClick();awaitWork()
        assertEquals(listOf(WordEntry("hello","你好")),WordStore.allEntries(activity))
    }
    @Test @Config(sdk=[28]) fun completeBackupFilePickerAndRestoreKeepAllUserData() {
        WordStore.add(activity,"hello","你好");ReviewStore.setPhonetic(activity,"hello","/h/");ReviewStore.markSeen(activity,"hello")
        activity.window.decorView.findViewWithTag<android.view.View>("backup_open").performClick()
        click("backup_full_export")
        val request=shadowOf(activity).nextStartedActivityForResult
        assertEquals("application/zip",request.intent.type)
        val output=File(activity.cacheDir,"complete.zip")
        val result=MainActivity::class.java.getDeclaredMethod("onActivityResult",Int::class.javaPrimitiveType,Int::class.javaPrimitiveType,Intent::class.java).apply { isAccessible=true }
        result.invoke(activity,request.requestCode,Activity.RESULT_OK,Intent().setData(android.net.Uri.fromFile(output)));awaitWork()
        assertTrue(output.length()>0)
        WordStore.replaceAll(activity,listOf(WordEntry("different","不同")))
        result.invoke(activity,4108,Activity.RESULT_OK,Intent().setData(android.net.Uri.fromFile(output)));awaitWork()
        latest().getButton(AlertDialog.BUTTON_POSITIVE).performClick();awaitWork();awaitWork()
        assertEquals(listOf(WordEntry("hello","你好")),WordStore.allEntries(activity))
        assertEquals(1,ReviewStore.seenCount(activity,"hello"));assertEquals("/h/",ReviewStore.profile(activity,"hello").phonetic)
    }
    @After fun finish() {
        if (::controller.isInitialized) controller.pause().stop().destroy()
        if (::executor.isInitialized) executor.awaitTermination(10, TimeUnit.SECONDS)
        shadowOf(Looper.getMainLooper()).idle()
    }
    private fun showSelection(source: String): AlertDialog {
        val file = File(activity.cacheDir, "test-preview.png")
        val bitmap = Bitmap.createBitmap(200, 100, Bitmap.Config.ARGB_8888)
        file.outputStream().use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }; bitmap.recycle()
        val sourceClass = Class.forName("com.pocketwords.app.LookupActivity\$ImageSource")
        val value = sourceClass.enumConstants!!.first { (it as Enum<*>).name == source }
        LookupActivity::class.java.getDeclaredMethod("showWordSelection", String::class.java, String::class.java,
            String::class.java, Int::class.javaPrimitiveType, Int::class.javaPrimitiveType, sourceClass).apply { isAccessible = true }
            .invoke(activity, "hello", file.path, "[]", 200, 100, value)
        return ShadowAlertDialog.getLatestAlertDialog()
    }
    @Test @Config(sdk = [28]) fun fullTextTranslationSkipsLinePickerAndMergesWrappedLines() {
        val selection = showSelection("SCREEN")
        selection.window!!.decorView.findViewWithTag<android.view.View>("ocr_translate_all").performClick()
        val dialog = ShadowAlertDialog.getLatestAlertDialog()
        assertEquals("hello", dialog.window!!.decorView.findViewWithTag<EditText>("sentence_input").text.toString())
        dialog.dismiss(); selection.dismiss()
    }

    @Test @Config(sdk = [28]) fun overlayLifecycleUpdatesHomeWithoutResumingActivity() {
        val button = activity.window.decorView.findViewWithTag<LinearLayout>("screen_lookup")
        val service = Robolectric.buildService(OverlayService::class.java).create()
        shadowOf(Looper.getMainLooper()).idle()
        assertEquals("关闭屏幕取词", (button.getChildAt(1) as android.widget.TextView).text.toString())
        service.destroy()
        shadowOf(Looper.getMainLooper()).idle()
        assertEquals("开启屏幕取词", (button.getChildAt(1) as android.widget.TextView).text.toString())
    }
    @Test fun homeOffersSentenceTranslationWithoutStartingDownload() {
        activity.window.decorView.findViewWithTag<android.view.View>("sentence_translate").performClick()
        val dialog = ShadowAlertDialog.getLatestAlertDialog()
        assertEquals("", dialog.window!!.decorView.findViewWithTag<EditText>("sentence_input").text.toString())
        assertNotNull(dialog.window!!.decorView.findViewWithTag<android.view.View>("model_status"))
        dialog.dismiss()
    }
    @Test fun ocrTranslationPreservesRecognizedText() {
        val selection = showSelection("SCREEN")
        selection.window!!.decorView.findViewWithTag<android.view.View>("ocr_more").performClick()
        org.robolectric.shadows.ShadowPopupMenu.getLatestPopupMenu().menu.performIdentifierAction(3,0)
        val lines = ShadowAlertDialog.getLatestAlertDialog()
        lines.getButton(AlertDialog.BUTTON_NEUTRAL).performClick()
        lines.getButton(AlertDialog.BUTTON_POSITIVE).performClick()
        val dialog = ShadowAlertDialog.getLatestAlertDialog()
        assertEquals("hello", dialog.window!!.decorView.findViewWithTag<EditText>("sentence_input").text.toString())
        dialog.dismiss(); selection.dismiss()
    }
    @Test fun photoRetryOpensCameraInsteadOfScreenCapture() {
        val camera = ResolveInfo().apply { activityInfo = ActivityInfo().apply { packageName = "camera.test"; name = "Camera" } }
        shadowOf(activity.packageManager).addResolveInfoForIntent(Intent(MediaStore.ACTION_IMAGE_CAPTURE), camera)
        val dialog = showSelection("PHOTO")
        assertEquals("重新拍照", dialog.getButton(AlertDialog.BUTTON_NEUTRAL).text.toString())
        dialog.getButton(AlertDialog.BUTTON_NEUTRAL).performClick()
        assertEquals(MediaStore.ACTION_IMAGE_CAPTURE, shadowOf(activity).nextStartedActivityForResult.intent.action)
    }
    @Test fun screenResultOffersScreenRetry() {
        assertEquals("重新截屏", showSelection("SCREEN").getButton(AlertDialog.BUTTON_NEUTRAL).text.toString())
    }
    @Test fun cancelingPhotoOrScreenConsentDoesNotStartCapture() {
        val result = MainActivity::class.java.getDeclaredMethod("onActivityResult",
            Int::class.javaPrimitiveType, Int::class.javaPrimitiveType, Intent::class.java).apply { isAccessible = true }
        result.invoke(activity, 4103, Activity.RESULT_CANCELED, null)
        result.invoke(activity, 4102, Activity.RESULT_CANCELED, null)
        assertNull(shadowOf(activity).nextStartedService)
        assertNull(shadowOf(activity).nextStartedActivityForResult)
    }
    @Test @Config(sdk = [35]) fun savingBackupOpensAFileDestinationWithChineseFilename() {
        activity.window.decorView.findViewWithTag<android.view.View>("backup_open").performClick()
        ShadowAlertDialog.getLatestAlertDialog().window!!.decorView.findViewWithTag<android.view.View>("backup_export").performClick()
        val launched = shadowOf(activity).nextStartedActivityForResult.intent
        assertEquals(Intent.ACTION_CREATE_DOCUMENT, launched.action)
        assertEquals("text/csv", launched.type)
        assertTrue(launched.getStringExtra(Intent.EXTRA_TITLE)!!.contains("词表"))
    }
    @Test @Config(sdk = [35]) fun restoringBackupOpensTheCsvFilePicker() {
        activity.window.decorView.findViewWithTag<android.view.View>("backup_open").performClick()
        ShadowAlertDialog.getLatestAlertDialog().window!!.decorView.findViewWithTag<android.view.View>("backup_import").performClick()
        val launched = shadowOf(activity).nextStartedActivityForResult.intent
        assertEquals(Intent.ACTION_OPEN_DOCUMENT, launched.action)
        assertTrue(launched.getStringArrayExtra(Intent.EXTRA_MIME_TYPES)!!.contains("text/csv"))
    }
    @Test fun correctingWordRefreshesMeaningWithoutOverwritingManualEdits() {
        LookupActivity::class.java.getDeclaredMethod("showSelectedWordDialog", String::class.java).apply { isAccessible = true }.invoke(activity, "hello")
        val dialog = ShadowAlertDialog.getLatestAlertDialog()
        awaitWork()
        val inputs = dialog.window!!.decorView
        val word = inputs.findViewWithTag<EditText>("word_input")
        val meaning = inputs.findViewWithTag<EditText>("meaning_input")
        assertEquals("你好", meaning.text.toString())
        word.setText("world")
        shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(350))
        meaning.setText("我的释义")
        awaitWork()
        assertEquals("我的释义", meaning.text.toString())
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).performClick()
        awaitWork()
        assertEquals(WordEntry("world", "我的释义"), WordStore.allEntries(activity).single())
    }
}

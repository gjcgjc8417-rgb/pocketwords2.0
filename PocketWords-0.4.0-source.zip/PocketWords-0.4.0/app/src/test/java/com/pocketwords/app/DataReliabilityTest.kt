package com.pocketwords.app

import android.content.Context
import android.graphics.Bitmap
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28])
class DataReliabilityTest {
    private lateinit var context: Context
    @Before fun setup() {
        context = RuntimeEnvironment.getApplication()
        context.deleteDatabase("pocketwords_review.db")
        context.getSharedPreferences("pocket_words", Context.MODE_PRIVATE).edit().clear().commit()
    }
    @Test fun aFailedCollectionRollsBackVocabularyAndEncounterTogether() {
        assertThrows(IllegalStateException::class.java) {
            ReviewStore.atomic(context) {
                WordStore.add(context, "hello", "你好")
                ReviewStore.recordEncounter(context, "hello", "Say hello.", "note", "source")
                error("simulated storage failure")
            }
        }
        assertTrue(WordStore.allEntries(context).isEmpty())
        assertTrue(ReviewStore.cards(context, listOf(WordEntry("hello", "你好"))).single().contexts.isEmpty())
    }
    @Test fun legacyVocabularyMigratesOnceAndNeverResurrectsDeletedWords() {
        context.getSharedPreferences("pocket_words", Context.MODE_PRIVATE).edit().putString("words", "[\"old\"]").commit()
        assertEquals("old", WordStore.allEntries(context).single().word)
        WordStore.delete(context, "old")
        assertTrue(WordStore.allEntries(context).isEmpty())
    }
    @Test fun pinnedContextSurvivesNewRecordsAndExplicitDeletionRemovesOnlyThatContext() {
        repeat(7) { ReviewStore.recordEncounter(context, "hello", "hello $it", "", "") }
        val before = ReviewStore.cards(context, listOf(WordEntry("hello", "你好"))).single()
        val oldest = before.contexts.last()
        ReviewStore.pinContext(context, "hello", oldest.id, true)
        ReviewStore.recordEncounter(context, "hello", "hello new", "", "")
        val after = ReviewStore.cards(context, listOf(before.entry)).single()
        assertEquals(8, after.contexts.size); assertEquals(oldest.id, after.contexts.first().id)
        assertTrue(after.contexts.first().pinned)
        ReviewStore.deleteContext(context, "hello", oldest.id)
        assertEquals(7, ReviewStore.cards(context, listOf(before.entry)).single().contexts.size)
    }
    @Test fun staleTemporaryFilesAreRemovedButCurrentPreviewsAndUserImagesRemain() {
        val now = System.currentTimeMillis()
        val stale = File(context.cacheDir, "screen-stale.png").apply { writeText("old"); setLastModified(now - 2 * 86_400_000) }
        val current = File(context.cacheDir, "lookup-current.png").apply { writeText("current") }
        val user = File(context.filesDir, "reading_contexts/kept.jpg").apply { parentFile!!.mkdirs(); writeText("kept") }
        TemporaryFiles.cleanup(context, now)
        assertFalse(stale.exists()); assertTrue(current.exists()); assertTrue(user.exists())
    }
}

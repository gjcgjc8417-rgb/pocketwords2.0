package com.pocketwords.app

import org.junit.Assert.*
import org.junit.Test

class PhraseDictionaryTest {
    @Test fun commonPhrasesHaveTheirOwnMeaningRatherThanAWordByWordTranslation() {
        assertEquals("期待；盼望（后接名词或动名词）", PhraseDictionary.lookup("look forward to"))
        assertEquals("尽管；不顾", PhraseDictionary.lookup("in spite of"))
        assertEquals("把……考虑在内", PhraseDictionary.lookup("take into account"))
        assertTrue(PhraseDictionary.meanings.size >= 180)
    }
    @Test fun inflectedVerbsAndPossessivesStillFindThePhrase() {
        assertEquals(PhraseDictionary.lookup("look forward to"), PhraseDictionary.lookup("LOOKING   FORWARD TO!"))
        assertEquals(PhraseDictionary.lookup("take care of"), PhraseDictionary.lookup("took care of"))
        assertEquals(PhraseDictionary.lookup("make up one's mind"), PhraseDictionary.lookup("made up my mind"))
        assertEquals(PhraseDictionary.lookup("on one's own"), PhraseDictionary.lookup("on her own"))
        assertEquals(PhraseDictionary.lookup("make up one's mind"), PhraseDictionary.lookup("make up one’s mind"))
    }
    @Test fun unknownOrPartialPhrasesDoNotInventAMeaning() {
        assertNull(PhraseDictionary.lookup("look forward"))
        assertNull(PhraseDictionary.lookup("hello imaginary phrase"))
        assertNull(PhraseDictionary.lookup("unknown"))
    }
    @Test fun ocrPhraseSelectionPreservesOrderAndReadingContext() {
        val words = listOf(WordBox("look",0,0,1,1,"I look forward to it."), WordBox("forward",0,0,1,1,"I look forward to it."), WordBox("to,",0,0,1,1,"I look forward to it."))
        assertEquals("look forward to" to "I look forward to it.", PhraseSelectionDialog.phrase(words,listOf(2,0,1)))
        assertThrows(IllegalArgumentException::class.java) { PhraseSelectionDialog.phrase(words,listOf(0,2)) }
        assertThrows(IllegalArgumentException::class.java) { PhraseSelectionDialog.phrase(words,listOf(0)) }
    }
}

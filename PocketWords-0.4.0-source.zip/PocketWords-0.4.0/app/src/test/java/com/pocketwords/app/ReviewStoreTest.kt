package com.pocketwords.app

import android.content.Context
import android.graphics.Bitmap
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28])
class ReviewStoreTest {
    private lateinit var context: Context
    @Before fun clear() {
        context = RuntimeEnvironment.getApplication()
        context.deleteDatabase("pocketwords_review.db")
        context.getSharedPreferences("pocket_words", Context.MODE_PRIVATE).edit().clear().commit()
    }
    @Test fun progressAndSessionAreCommittedTogetherAndSurviveReload() {
        WordStore.add(context, "hello", "你好")
        val run = ReviewRun(mutableListOf(ReviewTask("hello", QuizKind.RECALL), ReviewTask("hello", QuizKind.SPELL)))
        run.pendingRevealed = true; run.pendingTyped = "hel"
        ReviewStore.saveRun(context, run)
        assertTrue(ReviewStore.loadRun(context)!!.pendingRevealed)
        assertEquals("hel", ReviewStore.loadRun(context)!!.pendingTyped)
        val (next, p) = ReviewStore.answer(context, run, 2, 1_000_000)
        assertEquals(1, next.index); assertEquals(1, p.meaning.level); assertEquals(0, p.spelling.level)
        assertEquals(1, ReviewStore.loadRun(context)!!.index)
        assertFalse(ReviewStore.loadRun(context)!!.pendingRevealed)
        ReviewStore.saveRun(context, run) // An old screen must not overwrite committed answers.
        assertEquals(1, ReviewStore.loadRun(context)!!.index)
        assertThrows(IllegalStateException::class.java) { ReviewStore.answer(context, run, 2) }
        assertEquals(listOf(WordEntry("hello", "你好")), WordStore.allEntries(context))
    }
    @Test fun aNewSessionCannotBeOverwrittenByAnOldDialogClosing() {
        val first = ReviewRun(mutableListOf(ReviewTask("one", QuizKind.RECALL)))
        val second = ReviewRun(mutableListOf(ReviewTask("two", QuizKind.RECALL)))
        ReviewStore.saveRun(context, first)
        ReviewStore.saveRun(context, second, replace = true)
        ReviewStore.saveRun(context, first)
        assertEquals(second.id, ReviewStore.loadRun(context)!!.id)
    }
    @Test fun savedHintsStillPreventMasteryAfterResuming() {
        val run = ReviewRun(mutableListOf(ReviewTask("hello", QuizKind.SPELL)), pendingHinted = true)
        ReviewStore.saveRun(context, run)
        val resumed = ReviewStore.loadRun(context)!!
        val (next, p) = ReviewStore.answer(context, resumed, 2)
        assertEquals(0, p.spelling.level); assertEquals(0, next.correct)
        assertFalse(next.pendingHinted)
    }
    @Test fun contextsAreBoundedImagesArePrivateAndOldFilesAreCleaned() {
        val bitmap = Bitmap.createBitmap(100, 100, Bitmap.Config.ARGB_8888)
        repeat(7) { ReviewStore.recordEncounter(context, "hello", "Say hello $it.", "note $it", "source", bitmap) }
        ReviewStore.setPhonetic(context, "hello", "/test/")
        val card = ReviewStore.cards(context, listOf(WordEntry("hello", "你好"))).single()
        assertEquals(5, card.contexts.size)
        assertEquals("Say hello 6.", card.contexts.first().sentence)
        assertEquals("/test/", card.phonetic)
        assertEquals(5, java.io.File(context.filesDir, "reading_contexts").listFiles()!!.size)
        assertTrue(card.contexts.all { ReviewStore.imageFile(context, it.image).exists() })
        assertThrows(IllegalArgumentException::class.java) { ReviewStore.imageFile(context, "../outside.jpg") }
        ReviewStore.delete(context, "hello")
        assertEquals(0, java.io.File(context.filesDir, "reading_contexts").listFiles()!!.size)
        bitmap.recycle()
    }
    @Test fun encounterAndPausedFlagDoNotRaiseMasteryAndGroupsPreserveWords() {
        WordStore.add(context, "hello", "你好"); WordStore.add(context, "world", "世界")
        ReviewStore.markSeen(context, "hello")
        ReviewStore.setPaused(context, "hello", true)
        val p = ReviewStore.profile(context, "hello")
        assertTrue(p.paused); assertEquals(0, p.meaning.level); assertEquals(0, p.spelling.level)
        ReviewStore.saveGroup(context, "pair", "区别", listOf("hello", "world"))
        val group = ReviewStore.groups(context).single()
        assertEquals("区别", group.note)
        ReviewStore.deleteGroup(context, group.id)
        assertEquals(2, WordStore.allEntries(context).size)
    }
}

package com.pocketwords.app

import android.content.Context
import android.graphics.Bitmap
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[28])
class FullBackupTest {
    private lateinit var context: Context
    @Before fun clear() {
        context=RuntimeEnvironment.getApplication()
        context.deleteDatabase("pocketwords_review.db")
        context.getSharedPreferences("pocket_words",Context.MODE_PRIVATE).edit().clear().commit()
        File(context.filesDir,"reading_contexts").deleteRecursively()
        File(context.noBackupFilesDir,"restore-journal").deleteRecursively()
    }
    private fun seed() {
        WordStore.add(context,"hello","你好"); WordStore.add(context,"world","世界")
        ReviewStore.setPhonetic(context,"hello","/hello/")
        val bitmap=Bitmap.createBitmap(100,100,Bitmap.Config.ARGB_8888)
        ReviewStore.recordEncounter(context,"hello","Say hello.","note","source",bitmap); bitmap.recycle()
        ReviewStore.markSeen(context,"hello")
        ReviewStore.saveGroup(context,"pair","difference",listOf("hello","world"))
        val run=ReviewRun(mutableListOf(ReviewTask("hello",QuizKind.RECALL)))
        ReviewStore.saveRun(context,run); ReviewStore.answer(context,run,2)
    }
    private fun bytes() = ByteArrayOutputStream().also { FullBackup.write(context,it) }.toByteArray()
    @Test fun completeBackupRestoresWordsProgressImagesGroupsSeenAndHistory() {
        seed(); val backup=bytes(); val before=ReviewStore.loadRun(context)!!
        WordStore.replaceAll(context,listOf(WordEntry("different","不同")))
        ReviewStore.delete(context,"hello")
        FullBackup.read(context,ByteArrayInputStream(backup)).use { FullBackup.restore(context,it) }
        assertEquals(setOf("hello","world"),WordStore.allEntries(context).map { it.word }.toSet())
        val card=ReviewStore.cards(context,WordStore.allEntries(context).filter { it.word=="hello" }).single()
        assertEquals(1,card.profile.meaning.level); assertEquals("/hello/",card.phonetic)
        assertEquals("Say hello.",card.contexts.single().sentence)
        assertTrue(ReviewStore.imageFile(context,card.contexts.single().image).isFile)
        assertEquals(1,ReviewStore.seenCount(context,"hello")); assertEquals("difference",ReviewStore.groups(context).single().note)
        val after=ReviewStore.loadRun(context)!!
        assertEquals(before.index,after.index); assertNotEquals(before.id,after.id)
        assertEquals(1,ReviewStore.statistics(context).single().answers)
        assertFalse(File(context.noBackupFilesDir,"restore-journal").exists())
    }
    @Test fun malformedOrTraversingArchiveLeavesExistingDataUntouched() {
        seed()
        val out=ByteArrayOutputStream()
        ZipOutputStream(out).use { it.putNextEntry(ZipEntry("../outside")); it.write(byteArrayOf(1)); it.closeEntry() }
        assertThrows(IllegalArgumentException::class.java) { FullBackup.read(context,ByteArrayInputStream(out.toByteArray())) }
        assertEquals(2,WordStore.allEntries(context).size)
        assertEquals(1,ReviewStore.seenCount(context,"hello"))
        assertFalse(File(context.cacheDir.parentFile,"outside").exists())
    }
    @Test fun failedRestoreRollsBackWordsAndOriginalPictures() {
        seed(); val original=ReviewStore.cards(context,WordStore.allEntries(context).filter { it.word=="hello" }).single().contexts.single().image
        val prepared=FullBackup.read(context,ByteArrayInputStream(bytes()))
        // Simulate an invalid snapshot discovered after image-directory replacement.
        val rows=prepared.review.getJSONArray("encounters"); rows.put(JSONObject(rows.getJSONObject(0).toString()))
        assertThrows(IllegalStateException::class.java) { FullBackup.restore(context,prepared) }
        assertEquals(2,WordStore.allEntries(context).size)
        assertTrue(ReviewStore.imageFile(context,original).exists())
        assertEquals(1,ReviewStore.seenCount(context,"hello")); prepared.close()
    }
    @Test fun anInterruptedReplacementIsRecoveredAtNextStartup() {
        seed()
        val previous=ReviewStore.snapshot(context) { JSONObject().put("review",it).put("words",JSONArray().apply {
            WordStore.allEntries(context).forEach { put(JSONObject().put("word",it.word).put("meaning",it.meaning)) }
        }).put("hadImages",true) }
        val journal=File(context.noBackupFilesDir,"restore-journal").apply { mkdirs() }
        File(journal,"previous.json").writeText(previous.toString()); File(journal,"ready").writeText("1")
        val pictures=File(context.filesDir,"reading_contexts")
        check(pictures.renameTo(File(journal,"previous_images")))
        pictures.mkdirs(); File(pictures,"unclaimed.jpg").writeBytes(byteArrayOf(1))
        WordStore.replaceAll(context,listOf(WordEntry("temporary","临时")))
        FullBackup.recover(context); FullBackup.recover(context)
        assertEquals(setOf("hello","world"),WordStore.allEntries(context).map { it.word }.toSet())
        assertFalse(File(pictures,"unclaimed.jpg").exists()); assertFalse(journal.exists())
    }    @Test fun rescueBackupPreservesTextAndMarksMissingPicturesWithoutChangingTheSource() {
        seed()
        val card = ReviewStore.cards(context, WordStore.allEntries(context).filter { it.word == "hello" }).single()
        ReviewStore.imageFile(context, card.contexts.single().image).delete()
        assertThrows(IllegalStateException::class.java) { bytes() }
        val rescued = ByteArrayOutputStream().also { FullBackup.write(context, it, rescue = true) }.toByteArray()
        assertTrue(ReviewStore.cards(context, listOf(card.entry)).single().contexts.single().image.isNotBlank())
        FullBackup.read(context, ByteArrayInputStream(rescued)).use { prepared ->
            assertEquals(1, prepared.missingImages)
            FullBackup.restore(context, prepared)
        }
        assertEquals("Say hello.", ReviewStore.cards(context, listOf(card.entry)).single().contexts.single().sentence)
        assertEquals("", ReviewStore.cards(context, listOf(card.entry)).single().contexts.single().image)
    }
    @Test fun versionOneBackupWithoutPinsRemainsReadable() {
        seed()
        val review = ReviewStore.snapshot(context) { JSONObject(it.toString()) }
        val rows = review.getJSONArray("encounters")
        for (i in 0 until rows.length()) rows.getJSONObject(i).remove("pinned")
        ReviewStore.validateSnapshot(review)
        assertEquals(0, rows.getJSONObject(0).getInt("pinned"))
    }

}

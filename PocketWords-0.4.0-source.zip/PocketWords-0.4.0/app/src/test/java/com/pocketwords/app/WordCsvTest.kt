package com.pocketwords.app

import org.junit.Assert.*
import org.junit.Test
import java.io.StringReader
import java.io.StringWriter

class WordCsvTest {
    @Test fun roundTripPreservesChineseCommasQuotesAndNewlines() {
        val entries = listOf(WordEntry("hello", "你好，世界"), WordEntry("say", "说, \"你好\"\n第二行"))
        val output = StringWriter(); WordCsv.write(entries, output)
        assertEquals(entries, WordCsv.read(StringReader(output.toString())))
    }
    @Test fun importsBomCrLfAndEmptyMeaning() {
        assertEquals(listOf(WordEntry("hello", "")), WordCsv.read(StringReader("\uFEFFword,meaning\r\nhello,\r\n")))
    }
    @Test(expected = IllegalArgumentException::class) fun rejectsUnclosedQuotes() {
        WordCsv.read(StringReader("word,meaning\nhello,\"broken"))
    }
    @Test(expected = IllegalArgumentException::class) fun rejectsExtraColumns() {
        WordCsv.read(StringReader("word,meaning\na,b,c"))
    }
    @Test(expected = IllegalArgumentException::class) fun rejectsMissingWord() {
        WordCsv.read(StringReader("word,meaning\n,释义"))
    }
    @Test(expected = IllegalArgumentException::class) fun rejectsWrongHeader() {
        WordCsv.read(StringReader("hello,你好"))
    }
    @Test(expected = IllegalArgumentException::class) fun rejectsOversizedInput() {
        WordCsv.read(StringReader("word,meaning\n" + "x".repeat(WordCsv.MAX_CHARS)))
    }
}

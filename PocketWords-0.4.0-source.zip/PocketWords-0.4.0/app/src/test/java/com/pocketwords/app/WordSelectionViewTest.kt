package com.pocketwords.app

import android.graphics.Bitmap
import android.graphics.Color
import android.os.Looper
import android.os.SystemClock
import android.view.MotionEvent
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import java.time.Duration

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28])
class WordSelectionViewTest {
    @Test fun doubleTapZoomCropsOriginalCoordinatesAndKeepsTapAlignment() {
        val bitmap = Bitmap.createBitmap(400, 200, Bitmap.Config.ARGB_8888)
        var selected = ""
        val view = WordSelectionView(RuntimeEnvironment.getApplication(), bitmap,
            listOf(WordBox("center", 180, 80, 220, 120)), 400, 200) { selected = it }
        view.layout(0, 0, 200, 200)
        fun tap() {
            val time = SystemClock.uptimeMillis()
            for (action in listOf(MotionEvent.ACTION_DOWN, MotionEvent.ACTION_UP)) {
                val event = MotionEvent.obtain(time, SystemClock.uptimeMillis(), action, 100f, 100f, 0)
                view.onTouchEvent(event); event.recycle()
                shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(20))
            }
        }
        tap(); shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(60)); tap()
        val crop = view.cropVisible()
        assertTrue(crop.width in 132..135); assertTrue(crop.height in 132..135)
        assertEquals("", selected)
        shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(400))
        tap(); shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(400))
        assertEquals("center", selected)
        crop.recycle(); bitmap.recycle()
    }

    @Test fun cropUsesImagePixelsWithoutPreviewBoxes() {
        val bitmap = Bitmap.createBitmap(200, 100, Bitmap.Config.ARGB_8888).apply { eraseColor(Color.BLUE) }
        val view = WordSelectionView(RuntimeEnvironment.getApplication(), bitmap, listOf(WordBox("blue", 0, 0, 200, 100)), 200, 100) {}
        view.layout(0, 0, 300, 300)
        val crop = view.cropVisible()
        assertEquals(200, crop.width); assertEquals(100, crop.height)
        assertEquals(Color.BLUE, crop.getPixel(100, 50))
        assertNotSame(bitmap, crop)
        crop.recycle(); bitmap.recycle()
    }

    @Test fun tappingScaledPreviewSelectsTheRightWord() {
        val bitmap = Bitmap.createBitmap(400, 200, Bitmap.Config.ARGB_8888)
        var selected = ""
        val view = WordSelectionView(RuntimeEnvironment.getApplication(), bitmap,
            listOf(WordBox("left", 0, 0, 100, 100), WordBox("right", 200, 0, 300, 100)), 400, 200) { selected = it }
        view.layout(0, 0, 200, 200)
        val time = SystemClock.uptimeMillis()
        fun event(action: Int, offset: Long) {
            val event = MotionEvent.obtain(time, time + offset, action, 125f, 75f, 0)
            view.onTouchEvent(event); event.recycle()
        }
        event(MotionEvent.ACTION_DOWN, 0); event(MotionEvent.ACTION_UP, 20)
        shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(400))
        assertEquals("right", selected)
        bitmap.recycle()
    }
}

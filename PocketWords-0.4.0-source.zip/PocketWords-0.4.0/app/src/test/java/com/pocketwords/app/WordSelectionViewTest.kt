package com.pocketwords.app

import android.graphics.Bitmap
import android.graphics.Color
import android.os.Looper
import android.os.SystemClock
import android.view.MotionEvent
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import java.time.Duration

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28])
class WordSelectionViewTest {
    @Test fun contextCropUsesTheActualTappedOccurrenceAndKeepsOriginalPixels() {
        val bitmap = Bitmap.createBitmap(400, 200, Bitmap.Config.ARGB_8888).apply { eraseColor(Color.BLUE) }
        val view = WordSelectionView(RuntimeEnvironment.getApplication(), bitmap, listOf(
            WordBox("hello", 20, 20, 60, 40, "Say hello."),
            WordBox("hello", 200, 120, 250, 140, "Another hello.")
        ), 400, 200) {}
        view.layout(0, 0, 400, 200)
        val time = SystemClock.uptimeMillis()
        for (action in listOf(MotionEvent.ACTION_DOWN, MotionEvent.ACTION_UP)) {
            val event = MotionEvent.obtain(time, time, action, 225f, 130f, 0)
            view.onTouchEvent(event); event.recycle()
        }
        shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(400))
        assertEquals("Another hello.", view.selectedBox!!.context)
        val crop = checkNotNull(view.cropContext())
        assertEquals(90, crop.width); assertEquals(60, crop.height)
        assertEquals(Color.BLUE, crop.getPixel(0, 0))
        crop.recycle(); bitmap.recycle()
    }
    @Test fun regionCropWorksInReverseDragAndDoesNotSelectAWord() {
        val bitmap = Bitmap.createBitmap(400, 200, Bitmap.Config.ARGB_8888).apply { eraseColor(Color.BLUE) }
        var selected = ""
        val view = WordSelectionView(RuntimeEnvironment.getApplication(), bitmap,
            listOf(WordBox("word", 0, 0, 400, 200)), 400, 200) { selected = it }
        view.layout(0, 0, 200, 200)
        view.setRegionSelectionEnabled(true)
        assertNull(view.cropSelection())
        val time = SystemClock.uptimeMillis()
        for ((index, action) in listOf(MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE, MotionEvent.ACTION_UP).withIndex()) {
            val event = MotionEvent.obtain(time, time + index * 20L, action,
                if (index == 0) 150f else 50f, if (index == 0) 125f else 75f, 0)
            view.onTouchEvent(event); event.recycle()
        }
        val crop = checkNotNull(view.cropSelection())
        assertEquals(200, crop.width); assertEquals(100, crop.height)
        assertEquals(Color.BLUE, crop.getPixel(0, 0))
        shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(400))
        assertEquals("", selected)
        view.zoomBy(1.5f); assertNull(view.cropSelection())
        crop.recycle(); bitmap.recycle()
    }

    @Test fun fitWidthPreservesTallScreenshotPixelsAndStartsAtTop() {
        val bitmap = Bitmap.createBitmap(200, 1000, Bitmap.Config.ARGB_8888)
        val view = WordSelectionView(RuntimeEnvironment.getApplication(), bitmap, emptyList(), 200, 1000) {}
        view.layout(0, 0, 200, 400)
        view.fitWidth()
        val crop = view.cropVisible()
        assertEquals(200, crop.width); assertEquals(400, crop.height)
        view.fitImage()
        val all = view.cropVisible()
        assertEquals(200, all.width); assertEquals(1000, all.height)
        crop.recycle(); all.recycle(); bitmap.recycle()
    }

    @Test fun nearbyTapSelectsNearestWordButDistantTapDoesNot() {
        val bitmap = Bitmap.createBitmap(200, 200, Bitmap.Config.ARGB_8888)
        var selected = ""
        val view = WordSelectionView(RuntimeEnvironment.getApplication(), bitmap,
            listOf(WordBox("near", 90, 90, 100, 100), WordBox("other", 125, 90, 135, 100)), 200, 200) { selected = it }
        view.layout(0, 0, 200, 200)
        fun tap(x: Float, y: Float) {
            val time = SystemClock.uptimeMillis()
            for (action in listOf(MotionEvent.ACTION_DOWN, MotionEvent.ACTION_UP)) {
                val event = MotionEvent.obtain(time, time, action, x, y, 0)
                view.onTouchEvent(event); event.recycle()
            }
            shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(400))
        }
        tap(104f, 95f); assertEquals("near", selected)
        selected = ""; tap(180f, 180f); assertEquals("", selected)
        bitmap.recycle()
    }

    @Test fun doubleTapZoomCropsOriginalCoordinatesAndKeepsTapAlignment() {
        val bitmap = Bitmap.createBitmap(400, 200, Bitmap.Config.ARGB_8888)
        var selected = ""
        val view = WordSelectionView(RuntimeEnvironment.getApplication(), bitmap,
            listOf(WordBox("center", 180, 80, 220, 120)), 400, 200) { selected = it }
        view.layout(0, 0, 200, 200)
        fun tap() {
            val time = SystemClock.uptimeMillis()
            for (action in listOf(MotionEvent.ACTION_DOWN, MotionEvent.ACTION_UP)) {
                val event = MotionEvent.obtain(time, SystemClock.uptimeMillis(), action, 100f, 100f, 0)
                view.onTouchEvent(event); event.recycle()
                shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(20))
            }
        }
        tap(); shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(60)); tap()
        val crop = view.cropVisible()
        assertTrue(crop.width in 132..135); assertTrue(crop.height in 132..135)
        assertEquals("", selected)
        shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(400))
        tap(); shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(400))
        assertEquals("center", selected)
        crop.recycle(); bitmap.recycle()
    }

    @Test fun cropUsesImagePixelsWithoutPreviewBoxes() {
        val bitmap = Bitmap.createBitmap(200, 100, Bitmap.Config.ARGB_8888).apply { eraseColor(Color.BLUE) }
        val view = WordSelectionView(RuntimeEnvironment.getApplication(), bitmap, listOf(WordBox("blue", 0, 0, 200, 100)), 200, 100) {}
        view.layout(0, 0, 300, 300)
        val crop = view.cropVisible()
        assertEquals(200, crop.width); assertEquals(100, crop.height)
        assertEquals(Color.BLUE, crop.getPixel(100, 50))
        assertNotSame(bitmap, crop)
        crop.recycle(); bitmap.recycle()
    }

    @Test fun tappingScaledPreviewSelectsTheRightWord() {
        val bitmap = Bitmap.createBitmap(400, 200, Bitmap.Config.ARGB_8888)
        var selected = ""
        val view = WordSelectionView(RuntimeEnvironment.getApplication(), bitmap,
            listOf(WordBox("left", 0, 0, 100, 100), WordBox("right", 200, 0, 300, 100)), 400, 200) { selected = it }
        view.layout(0, 0, 200, 200)
        val time = SystemClock.uptimeMillis()
        fun event(action: Int, offset: Long) {
            val event = MotionEvent.obtain(time, time + offset, action, 125f, 75f, 0)
            view.onTouchEvent(event); event.recycle()
        }
        event(MotionEvent.ACTION_DOWN, 0); event(MotionEvent.ACTION_UP, 20)
        shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(400))
        assertEquals("right", selected)
        bitmap.recycle()
    }    @Test fun restoringZoomAndSelectionKeepsTheSameSourceArea() {
        val bitmap = Bitmap.createBitmap(400, 200, Bitmap.Config.ARGB_8888)
        val first = WordSelectionView(RuntimeEnvironment.getApplication(), bitmap, emptyList(), 400, 200) {}
        first.layout(0,0,200,200); first.zoomBy(2f); first.setRegionSelectionEnabled(true)
        val time = SystemClock.uptimeMillis()
        for ((action, position) in listOf(MotionEvent.ACTION_DOWN to 50f, MotionEvent.ACTION_UP to 140f)) {
            val event = MotionEvent.obtain(time,time,action,position,position,0)
            first.onTouchEvent(event); event.recycle()
        }
        val area = first.selectionArea()!!
        val second = WordSelectionView(RuntimeEnvironment.getApplication(), bitmap, emptyList(), 400, 200) {}
        second.layout(0,0,200,200); second.setRegionSelectionEnabled(true); second.restore(first.state())
        assertEquals(area, second.selectionArea())
        assertEquals(first.visibleArea(), second.visibleArea())
        bitmap.recycle()
    }

}

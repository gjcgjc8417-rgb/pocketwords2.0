package com.pocketwords.app

import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File
import java.io.IOException
import java.io.InputStream

class DictionaryInstallerTest {
    @get:Rule val folder = TemporaryFolder()

    @Test fun oldFullDictionaryIsReplacedWhenAssetVersionChanges() {
        val db = folder.newFile("dictionary.db").apply { writeText("old-full") }
        val marker = folder.newFile("version").apply { writeText("old") }
        val installer = DictionaryInstaller(db, marker)
        assertTrue(installer.needsInstall("compact-v1"))
        installer.install("compact-v1", { "compact".byteInputStream() }) { assertEquals("compact", it.readText()) }
        assertEquals("compact", db.readText())
        assertFalse(installer.needsInstall("compact-v1"))
    }

    @Test fun failedCopyKeepsOldDictionaryAndVersion() {
        val db = folder.newFile("dictionary.db").apply { writeText("old") }
        val marker = folder.newFile("version").apply { writeText("v0") }
        val installer = DictionaryInstaller(db, marker)
        val broken = object : InputStream() {
            var count = 0
            override fun read(): Int { if (count++ == 2) throw IOException("interrupted"); return 'x'.code }
            override fun read(bytes: ByteArray, offset: Int, length: Int): Int = read().let { bytes[offset] = it.toByte(); 1 }
        }
        assertTrue(runCatching { installer.install("v1", { broken }) { fail("Partial database should not be validated") } }.isFailure)
        assertEquals("old", db.readText()); assertEquals("v0", marker.readText())
        assertFalse(File(folder.root, "dictionary.db.tmp").exists())
    }

    @Test fun failedValidationKeepsOldDictionaryAndVersion() {
        val db = folder.newFile("dictionary.db").apply { writeText("old") }
        val marker = folder.newFile("version").apply { writeText("v0") }
        val installer = DictionaryInstaller(db, marker)
        assertTrue(runCatching { installer.install("v1", { "invalid".byteInputStream() }) { error("corrupted") } }.isFailure)
        assertEquals("old", db.readText()); assertEquals("v0", marker.readText())
        assertTrue(installer.needsInstall("v1"))
    }
}

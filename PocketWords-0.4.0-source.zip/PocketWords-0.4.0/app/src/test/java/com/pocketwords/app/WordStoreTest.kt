package com.pocketwords.app

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28])
class WordStoreTest {
    private lateinit var context: Context
    @Before fun prepare() {
        context = RuntimeEnvironment.getApplication()
        context.getSharedPreferences("pocket_words", Context.MODE_PRIVATE).edit().clear().commit()
        val field = WordStore::class.java.getDeclaredField("dictionary").apply { isAccessible = true }
        (field.get(WordStore) as? SQLiteDatabase)?.close(); field.set(WordStore, null)
        File(context.filesDir, "pocketwords_dictionary.version").writeText(
            context.assets.open("dictionary.version").bufferedReader().use { it.readText().trim() })
        val file = File(context.filesDir, "pocketwords_dictionary.db")
        file.delete()
        SQLiteDatabase.openOrCreateDatabase(file, null).use {
            it.execSQL("CREATE TABLE stardict (word TEXT, translation TEXT)")
            it.execSQL("INSERT INTO stardict VALUES ('synthesize', '合成')")
        }
    }
    @Test fun inflectedWordQueriesSqliteDictionary() {
        assertEquals("合成", WordStore.lookupMeaning(context, "SYNTHESIZING!"))
    }
    @Test fun importingMergesWithoutOverwritingExistingMeanings() {
        WordStore.add(context, "Hello", "原释义")
        val result = WordStore.importEntries(context, listOf(WordEntry("hello", "新释义"), WordEntry("world", "世界"), WordEntry("WORLD", "重复")))
        assertEquals(ImportResult(1, 2), result)
        assertEquals(listOf(WordEntry("world", "世界"), WordEntry("Hello", "原释义")), WordStore.allEntries(context))
    }
    @Test fun legacyStringEntriesSurviveSavingAnotherWord() {
        context.getSharedPreferences("pocket_words", Context.MODE_PRIVATE).edit().putString("words", "[\"legacy\"]").commit()
        WordStore.add(context, "new", "新")
        assertEquals(listOf("new", "legacy"), WordStore.allEntries(context).map { it.word })
    }
    @Test fun damagedStorageIsNeverSilentlyOverwritten() {
        val prefs = context.getSharedPreferences("pocket_words", Context.MODE_PRIVATE)
        prefs.edit().putString("words", "{broken").commit()
        assertTrue(runCatching { WordStore.add(context, "new", "新") }.isFailure)
        assertEquals("{broken", prefs.getString("words", null))
    }
    @Test fun upgradingDictionaryPreservesUserWordsAndMeanings() {
        WordStore.add(context, "my-word", "我的自定义释义")
        File(context.filesDir, "pocketwords_dictionary.version").writeText("legacy-full-db")
        WordStore.prepareDictionary(context)
        assertEquals(listOf(WordEntry("my-word", "我的自定义释义")), WordStore.allEntries(context))
        assertEquals(context.assets.open("dictionary.version").bufferedReader().use { it.readText().trim() },
            File(context.filesDir, "pocketwords_dictionary.version").readText())
        assertTrue(File(context.filesDir, "pocketwords_dictionary.db").length() > 1000000)
    }
}

package com.pocketwords.app

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import java.io.File
import java.util.Locale

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28])
class PronunciationAudioTest {
    private lateinit var context: Context
    private val json = """[{"phonetics":[
        {"audio":"https://api.dictionaryapi.dev/media/hello-uk.mp3","sourceUrl":"https://commons.wikimedia.org/wiki/File:Hello-uk.ogg","license":{"name":"CC BY-SA 4.0","url":"https://creativecommons.org/licenses/by-sa/4.0/"}},
        {"audio":"https://api.dictionaryapi.dev/media/hello-us.mp3","sourceUrl":"https://commons.wikimedia.org/wiki/File:Hello-us.ogg","license":{"name":"CC BY-SA 4.0","url":"https://creativecommons.org/licenses/by-sa/4.0/"}},
        {"audio":"https://evil.example/fake.mp3","sourceUrl":"https://evil.example"}
    ]}]"""
    @Before fun setup() { context = RuntimeEnvironment.getApplication(); File(context.cacheDir,"pronunciation").deleteRecursively() }
    @Test fun recordingChoiceUsesAccentAndPreservesAttribution() {
        val us = PronunciationAudio.recordings(json,"us")
        assertEquals(2,us.size); assertTrue(us.first().url.endsWith("-us.mp3"))
        assertEquals("CC BY-SA 4.0",us.first().license)
        assertTrue(PronunciationAudio.recordings(json,"uk").first().url.endsWith("-uk.mp3"))
    }
    @Test fun aCachedRecordingCanBePlayedWithoutRequestingItAgain() {
        val requests = mutableListOf<String>()
        val repository = PronunciationAudio(context) { url, _ -> requests.add(url); if (url.contains("/entries/")) json.toByteArray() else byteArrayOf(1,2,3) }
        val first = checkNotNull(repository.load("hello","us") { false })
        assertEquals(2,requests.size); assertTrue(first.source.contains("录音")); assertEquals("CC BY-SA 4.0",first.license)
        val cached = PronunciationAudio(context) { _, _ -> error("Must not use the network") }.load("HELLO","us") { false }
        assertEquals(first,cached)
    }
    @Test fun unavailableRecordingFallsBackToAnHonestlyLabelledDictionaryVoice() {
        val requests = mutableListOf<String>()
        val repository = PronunciationAudio(context) { url, _ ->
            requests.add(url)
            if (!url.contains("dict.youdao.com")) error("unavailable") else byteArrayOf(4,5)
        }
        val clip = checkNotNull(repository.load("take care of","uk") { false })
        assertTrue(clip.source.contains("合成语音")); assertTrue(requests.single().contains("type=1"))
        assertTrue(requests.single().contains("take+care+of"))
    }
    @Test fun cancellationAndUnavailableNetworkDoNotCreateABogusCache() {
        val repository = PronunciationAudio(context) { _, _ -> error("offline") }
        assertNull(repository.load("hello","us") { true })
        assertNull(repository.load("hello","us") { false })
        assertTrue(File(context.cacheDir,"pronunciation").listFiles().orEmpty().isEmpty())
    }
    @Test fun audioUrlsMustUseSupportedHttpsHosts() {
        assertTrue(PronunciationAudio.allowed("https://api.dictionaryapi.dev/media/test.mp3"))
        for (url in listOf("http://api.dictionaryapi.dev/test", "file:///private/data", "https://evil.example/test", "https://api.dictionaryapi.dev.evil.example/test", "https://user@dict.youdao.com/test", "https://dict.youdao.com:8080/test")) assertFalse(url,PronunciationAudio.allowed(url))
    }
    @Test fun automaticSystemVoiceSelectionPrefersQualityAndExcludesUninstalledVoices() {
        val standard = Voice("standard-us",Locale.US,Voice.QUALITY_NORMAL,Voice.LATENCY_NORMAL,false,emptySet())
        val natural = Voice("natural-uk",Locale.UK,Voice.QUALITY_VERY_HIGH,Voice.LATENCY_NORMAL,false,emptySet())
        val network = Voice("network-us",Locale.US,Voice.QUALITY_VERY_HIGH,Voice.LATENCY_NORMAL,true,emptySet())
        val missing = Voice("missing",Locale.US,Voice.QUALITY_VERY_HIGH,Voice.LATENCY_NORMAL,false,setOf(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED))
        assertEquals(listOf(natural,standard), SpeechVoices.rank(setOf(standard,natural,network,missing),false,"us"))
        assertEquals(network,SpeechVoices.rank(setOf(standard,natural,network,missing),true,"us").first())
    }
}

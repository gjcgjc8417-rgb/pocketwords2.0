# 折页取词 — PocketWords launcher identity

深墨绿底色（#102D2B），米白折页口袋（#F4EEDF），浅柠绿单词块（#D1E58A）。斜向留白表示书页折入口袋，两条短线表示阅读内容，右上角脱离纸面的方块表示选中并收进词本的单词。

图像生成用于探索构图，应用内采用重新绘制的 Android VectorDrawable，以保持小尺寸边缘清晰、纯色一致和负形透明。

- `pocketwords-icon.svg`：圆角方形预览与 PNG 输出源。
- `pocketwords-icon-circle.svg`：圆形预览与 PNG 输出源。
- `pocketwords-icon-themed.svg`：单色主题图标预览。
- `app/src/main/res/drawable/ic_launcher_foreground.xml`：自适应图标前景。
- `app/src/main/res/drawable/ic_launcher_monochrome.xml`：Android 13+ 主题图标蒙版。

自适应图标使用 108 × 108 viewport，主体整体缩放到安全范围，圆形裁切不会遮住单词块或口袋。48、72、96、144、192px PNG 与自适应图标使用同一几何形状。

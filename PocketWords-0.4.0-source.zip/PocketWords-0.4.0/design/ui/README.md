# 0.5.1 原生界面预览

这些预览由 Android 原生控件在 Robolectric Native Graphics 中渲染，不含真实系统状态栏，也不代表真机权限、厂商后台限制或实际屏幕捕获已完成验证。示例词仅用于预览，不会预置到用户单词本。

- home-empty.png：空单词本；主取词按钮为浅绿色，其他配色保留。
- home-words.png：单词卡片列表。
- backup-dialog.png：中文的保存备份、恢复与格式说明入口。
- floating-button.png：墨绿取词胶囊。

主界面整体可滚动；“备份与恢复”入口也在单词本标题右侧，避免单词很多时需要一直翻到底部。

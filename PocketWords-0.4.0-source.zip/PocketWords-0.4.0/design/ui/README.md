# 界面预览

`home-0.9.1.png` 是当前首页代码的 Robolectric Native Graphics 预览，360 dp 宽，包含示例词表。右上角已替换为更多，不再显示词典状态标签或搜索框下的重复工具栏。不含手机通知栏与手势栏，不是实机截图。

复现：`./gradlew testDebugUnitTest --tests '*LookupUiTest.renderHomePreview'`，输出 `app/build/outputs/previews/home-360dp.png`。

0.9.0 和 0.8.1 图片保留为历史参考。验收范围见 TESTING.md。

# 界面预览

`home-0.9.0.png` 为当前首页代码的 Robolectric Native Graphics 预览，360 dp 宽，包含示例词表与筛选入口。不含真实手机通知栏和手势栏，不是实机截图。

复现：`./gradlew testDebugUnitTest --tests '*LookupUiTest.renderHomePreview'`，输出 `app/build/outputs/previews/home-360dp.png`。

`home-0.8.1.png` 保留为历史参考。行为与验收状态见根目录 README.md、TESTING.md 和 docs/CHANGES-0.9.0.md。

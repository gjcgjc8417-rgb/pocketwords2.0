# 界面预览归档

旧 0.5.1 原生控件预览已独立交付为 PocketWords-legacy-previews.zip，属于历史设计参考，不代表 0.8.0 当前界面。

当前源码包保留图标设计，界面行为与验证状态见根目录 README.md、TESTING.md 和 docs/CHANGES-0.8.md。

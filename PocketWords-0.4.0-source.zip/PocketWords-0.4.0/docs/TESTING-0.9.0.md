# 0.9.0 验证记录

本次构建环境：JDK 17、Gradle 8.10.2、Android SDK Platform 35。没有连接 Android 手机，/dev/kvm 不存在。

## 自动检查

2026-10-27 执行结果：

| 检查 | 结果 |
| --- | --- |
| Python 工具测试 | 5 项通过 |
| Android 单元/模拟框架检查 | 172 项通过，0 失败、0 跳过 |
| lintDebug | 通过，0 错误、27 警告 |
| compileDebugAndroidTestKotlin | 通过；设备测试代码编译完成 |
| git diff --check | 通过 |

共 177 项自动测试通过。lint 警告包含依赖更新提示、既有 ExifInterface/自绘视图/资源/国际化等建议，不将其记作错误或设备通过记录。

复现命令：

```sh
python3 -m unittest discover -s tools -p 'test_*.py' -v
./gradlew testDebugUnitTest lintDebug compileDebugAndroidTestKotlin
```

检查覆盖：自动翻译、首次明确下载后的自动继续、下载期间改文取消旧请求、已完成译文恢复、旧词表一次迁移、迁移失败保留源资料、收藏事务回滚、主动保存图片失败不留下半条词、阅读记录超过五条保留、固定和主动删除、完整/救援备份、旧备份兼容、过期缓存清理、筛选排序、记词草稿及缩放选区恢复、中间重识别阶段原图文件保留。

首页预览由 Robolectric Native Graphics 渲染；不能代替手机截屏或 OCR 准确率验证。既有 Robolectric BitmapRegionDecoder 的像素局限继续存在，新增 DeviceSmokeTest 使用真实 Android 解码器检查像素。

## 设备测试（未执行）

新增 `app/src/androidTest/.../DeviceSmokeTest.kt`：检查真实区域解码的选区像素与数据库事务回滚。设备测试代码可以编译，但本次没有设备运行结果。

接入设备并恢复原测试签名后运行 `./gradlew connectedDebugAndroidTest`，或在 GitHub 手动触发 Android device checks（API 28/35，需配置原签名 secret）。

以下流程仍需真机验收：

| 流程 | 验收要点 | 本次状态 |
| --- | --- | --- |
| 原版本覆盖升级 | 使用原签名，迁移后词表/原句/图片/旧进度完整；删词后不因旧偏好数据复活 | 未执行 |
| 连续屏幕取词 | 静止/滚动/切应用各至少 10 次，关闭回原应用，撤权与超时能重新授权 | 未执行 |
| 框选直接翻译 | 选区确认后直接看到中文；模型未下载时主动下载，完成后直接出译文 | 未执行 |
| 相机与多次裁剪 | 横竖拍、EXIF 镜像、小字和连续局部识别，词框/原图对齐 | 未执行 |
| 键盘与转屏 | 复习输入不失焦，记词草稿/译文/图片缩放选区可恢复 | 未执行 |
| 系统离线发音 | 已安装英文语音时断网播放，无语音时提示安装，不后台下载 | 未执行 |
| 大字体与深色 | 系统 1.3/1.5/2 倍字体、深色/浅色/系统模式、TalkBack 识别词列表 | 未执行 |
| 备份与低空间 | 大文件状态提示、缺图救援、取消确认、恢复中断、磁盘不足保留原资料 | 未执行 |
| 厂商后台策略 | 主流厂商锁屏、切后台后的悬浮按钮和共享会话行为 | 未执行 |

## 签名

本次交付源码；未使用替代签名密钥，未生成可覆盖安装的签名 APK。按 SIGNING.md 配置所有者原测试密钥后，可通过既有构建工作流生成 APK。

历史检查见 docs/TESTING-HISTORY.md。

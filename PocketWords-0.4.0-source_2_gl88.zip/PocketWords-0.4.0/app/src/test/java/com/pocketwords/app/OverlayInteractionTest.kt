package com.pocketwords.app

import android.os.Looper
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf
import org.robolectric.android.controller.ServiceController
import org.robolectric.annotation.Config
import java.time.Duration

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28, 35])
class OverlayInteractionTest {
    private lateinit var controller: ServiceController<OverlayService>
    private lateinit var service: OverlayService
    private lateinit var bubble: View
    @Before fun create() {
        controller = Robolectric.buildService(OverlayService::class.java).create()
        service = controller.get()
        bubble = OverlayService::class.java.getDeclaredField("bubble").apply { isAccessible = true }.get(service) as View
    }
    @After fun destroy() { controller.destroy(); shadowOf(Looper.getMainLooper()).idle() }
    private fun touch(action: Int, x: Float, y: Float) {
        val time = SystemClock.uptimeMillis()
        val event = MotionEvent.obtain(time, time, action, x, y, 0)
        bubble.dispatchTouchEvent(event); event.recycle()
    }
    @Test fun tapStartsScreenLookup() {
        touch(MotionEvent.ACTION_DOWN, 20f, 20f); touch(MotionEvent.ACTION_UP, 20f, 20f)
        assertEquals(OverlayService.ACTION_CAPTURE, shadowOf(service).nextStartedActivity.action)
    }
    @Test fun draggingStaysOnScreenAndDoesNotTriggerLookup() {
        touch(MotionEvent.ACTION_DOWN, 20f, 20f)
        touch(MotionEvent.ACTION_MOVE, 100000f, 100000f)
        touch(MotionEvent.ACTION_UP, 100000f, 100000f)
        shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(250))
        val params = OverlayService::class.java.getDeclaredField("params").apply { isAccessible = true }.get(service) as WindowManager.LayoutParams
        val metrics = service.resources.displayMetrics
        assertTrue(params.x >= metrics.widthPixels / 2)
        assertTrue(params.y >= 0)
        assertTrue(params.x + params.width <= metrics.widthPixels)
        assertTrue(params.y + params.height <= metrics.heightPixels)
        assertNull(shadowOf(service).nextStartedActivity)
    }
    @Test fun longPressClosesWithoutStartingLookup() {
        touch(MotionEvent.ACTION_DOWN, 20f, 20f)
        shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(ViewConfiguration.getLongPressTimeout().toLong() + 50))
        touch(MotionEvent.ACTION_UP, 20f, 20f)
        assertTrue(shadowOf(service).isStoppedBySelf)
        assertNull(shadowOf(service).nextStartedActivity)
    }
}

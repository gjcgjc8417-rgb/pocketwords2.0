package com.pocketwords.app

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/** Shared palette and small native view primitives for the app and overlay. */
object BrandUi {
    val Forest = 0xFF102D2B.toInt()
    val Paper = 0xFFF4EEDF.toInt()
    val Citron = 0xFFD1E58A.toInt()
    val SoftGreen = 0xFFDCE9DE.toInt()
    val Cream = 0xFFFFFCF5.toInt()
    val Muted = 0xFF63746C.toInt()
    val Line = 0xFFE0DCCD.toInt()
    val Tint = 0xFFE8EDD9.toInt()

    fun dp(context: Context, value: Int) = (value * context.resources.displayMetrics.density).toInt()
    fun shape(context: Context, color: Int, radius: Int = 18, border: Int? = null) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(context, radius).toFloat()
        border?.let { setStroke(dp(context, 1).coerceAtLeast(1), it) }
    }
    fun ripple(context: Context, color: Int, radius: Int = 18, border: Int? = null) = RippleDrawable(
        ColorStateList.valueOf(if (color == Forest) 0x33F4EEDF else 0x22102D2B), shape(context, color, radius, border), shape(context, -1, radius)
    )
    fun label(context: Context, text: String, size: Float = 14f, color: Int = Forest, bold: Boolean = false) = TextView(context).apply {
        this.text = text; textSize = size; setTextColor(color)
        typeface = Typeface.create(if (bold) "sans-serif-medium" else "sans-serif", Typeface.NORMAL)
        includeFontPadding = false
        setLineSpacing(dp(context, 3).toFloat(), 1f)
    }
    fun icon(context: Context, resource: Int, color: Int = Forest) = ImageView(context).apply {
        setImageResource(resource); setColorFilter(color); importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
    }
    fun action(context: Context, title: String, resource: Int, color: Int = Forest, foreground: Int = Paper): LinearLayout =
        LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            minimumHeight = dp(context, 52); setPadding(dp(context, 16), dp(context, 12), dp(context, 16), dp(context, 12))
            background = ripple(context, color, 16); isClickable = true; isFocusable = true
            contentDescription = title
            addView(icon(context, resource, foreground), LinearLayout.LayoutParams(dp(context, 21), dp(context, 21)).apply { marginEnd = dp(context, 9) })
            addView(label(context, title, 15f, foreground, true).apply { gravity = Gravity.CENTER },
                LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        }
    fun field(context: Context, hint: String, singleLine: Boolean = true) = EditText(context).apply {
        this.hint = hint; setTextColor(Forest); setHintTextColor(Muted); textSize = 15f
        setSingleLine(singleLine); minimumHeight = dp(context, 50)
        setPadding(dp(context, 14), dp(context, 12), dp(context, 14), dp(context, 12))
        background = shape(context, Cream, 14, Line)
        inputType = if (singleLine) InputType.TYPE_CLASS_TEXT else InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
    }
}
